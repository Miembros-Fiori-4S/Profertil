Configurar parámetros en manifest.json de acuerdo al script que proporciona SAP CAI
```html
<script
src="https://profertildev.sapcai.eu10.hana.ondemand.com/resources/public/webclient/bootstrap.js"
data-channel-id="xxxxx"
data-token="xxxxx"
data-expander-type="CAI"
data-expander-preferences="xxxxx"
id="cai-webclient-custom">
</script>
```

```json
 "parameters": {
        "CHANNEL_ID": {
            "defaultValue": {
                "value": "xxxx"
            }
        },
        "TOKEN": {
            "defaultValue": {
                "value": "xxxx"
            }
        },
        "API_ROOT": {
            "defaultValue": {
                "value": "https://profertildev.sapcai.eu10.hana.ondemand.com/public/api"
            }
        },
        "SRC": {
            "defaultValue": {
                "value": "https://profertildev.sapcai.eu10.hana.ondemand.com/resources/public/webclient/bootstrap.js"
            }
        },
        "PREFERENCES": {
            "defaultValue": {
                "value": "xxxxx"
            }
        }
    },
```