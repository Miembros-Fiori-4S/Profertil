sap.ui.define(["profertil/preciosAdmin/controller/BaseController"], function (Controller) {
    "use strict";

    return Controller.extend("profertil.preciosAdmin.controller.MainView", {});
});
