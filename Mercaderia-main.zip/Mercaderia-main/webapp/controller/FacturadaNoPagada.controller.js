sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller, formatter) {
        "use strict";

        return Controller.extend("profertil.mercaderia.controller.FacturadaNoPagada", {
            formatter: formatter,
            onInit: function () {

            },
            onNavBack: function () {
                var oRouter = this.getOwnerComponent().getRouter();
                oRouter.navTo("");
            },
            onBeforeExport: function (oEvent) {
                /* Deshabilitar export worker */
                oEvent.getParameter("exportSettings").worker = false;
            }
        });
    });
