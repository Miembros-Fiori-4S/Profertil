sap.ui.define([
	"profertil/mercaderia/test/unit/controller/App.controller"
], function () {
	"use strict";
});
