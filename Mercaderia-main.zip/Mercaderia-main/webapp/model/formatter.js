sap.ui.define([], function () {
    "use strict";
    return {

        usd: function (val1) {
            var oNumberFormat = sap.ui.core.format.NumberFormat.getFloatInstance({
                maxFractionDigits: 2,
                groupingEnabled: true,
                groupingSeparator: ".",
                decimalSeparator: ","
            });
            parseFloat(val1).toFixed(2);

            return oNumberFormat.format(val1);
        },
        tn: function (val1) {
            return parseFloat(val1).toFixed(2);
        },
        // usd: function (val1) {
        //     return parseFloat(val1).toFixed(2);
        // },
        // tn: function (val1) {
        //     return parseFloat(val1).toFixed(2);
        // },
        colorFechaVencimiento: function (fecha) {
            var hoy = new Date();
            if (fecha < hoy) {
                return sap.ui.core.ValueState.Error;
            }
            return sap.ui.core.ValueState.Success;
        },
        colorHighlight: function (fecha) {
            var hoy = new Date();
            if (fecha < hoy) {
                return sap.ui.core.MessageType.Error;
            }
            return sap.ui.core.MessageType.Success;
        }

    };
});
