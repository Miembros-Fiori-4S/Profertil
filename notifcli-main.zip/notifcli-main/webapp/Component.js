sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/m/MessageBox"
], function (UIComponent, JSONModel, Filter, MessageBox) {
	"use strict";

	return UIComponent.extend("profertil.notifcli.Component", {

		metadata: {
			manifest: "json"
		},

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
		init: function () {
			// call the base component's init function
			//UIComponent.prototype.init.apply(this, arguments);

			// enable routing
			//this.getRouter().initialize();

			// set the device model
            //this.setModel(models.createDeviceModel(), "device");

            var rendererPromise = this._getRenderer();
            var that = this; 

            var aFilter = [];
            aFilter = this._buildFilter();
            var that = this;
            this.readDataPromise(aFilter).then(function (oData) {
                var oModel = new JSONModel();
                oModel.setData(oData.results);
                sap.ui.getCore().setModel(oModel, "Notificaciones");
                //var iCounter = oData.results.length;
                var iCounter = that.getCounter(oData.results);
                rendererPromise.then(function (oRenderer) { 
                    oRenderer.addHeaderEndItem({
                        id: "alertaID",
                        icon: "sap-icon://bell",
                        text: "Mis Novedades",
                        tooltip: "Mis Novedades",
                        floatingNumber: iCounter,
                        press: function (oEvent) {
                            that.fnPopoverDisplay(oEvent);
                        }
                    }, true).toggleStyleClass("bell", true);

                }).catch(function(sError) {
                    console.warn(sError);
                });
            });    
            
            var aFilter2 = [];
            aFilter2 = this._buildFilter2();
            this.readDataPromise(aFilter2).then(function (oData) {
                var oModel = new JSONModel();
                oModel.setData(oData.results);
                sap.ui.getCore().setModel(oModel, "Semaforos");
                //var iCounter = oData.results.length;
                var iCounter = that.getCounterSemaforo(oData.results);
                rendererPromise.then(function (oRenderer) {                    
                    oRenderer.addHeaderEndItem({
                        id: "semaforoID",
                        icon: "sap-icon://marketing-campaign",
                        text: "Mensajes Importantes",
                        tooltip: "Mensajes Importantes",
                        floatingNumber: iCounter,
                        press: function (oEvent) {
                            that.semaforoDisplay();
                        }
                    }, true);

                    that.semaforoDisplay();

                }).catch(function(sError) {
                    console.warn(sError);
                });
            });
            


        },  // init

        //*
        // Dialogs display
        //*

        // semaforo
        semaforoDisplay: function () {
            this.onPressRefreshSemaforo();
            var iNumber = sap.ui.getCore().getModel("Semaforos").getData().length;
            if (typeof iNumber === 'undefined' || iNumber === 0) {
                return; // no tiene semaforos
            }
            this._getDialog2().open();
        },

        // campanita
        fnPopoverDisplay: function (oEvent) {
            this.onPressRefresh();
            sap.ui.getCore().byId("alertaID").toggleStyleClass("bell", false);
            var iNumber = sap.ui.getCore().getModel("Notificaciones").getData().length;
            //var iNumber = sap.ui.getCore().byId("alertaID").getFloatingNumber();
            if (typeof iNumber === 'undefined' || iNumber === 0) {
                return; // no tiene notificaciones
            }

            if (this._getDialog().isOpen()) {
                this._getDialog().close();
            } else {
                this._getDialog().openBy(oEvent.getSource());
            }
            
        },


        /**
         * Button events
         * @param {event} oEvent 
         */

        onPressVerTodas: function (oEvent) {
            this.navigateToApp("NotifView-display");
        },
        
        // boton cerra en la notificacion
        onPressClose: function (oEvent) {
            var that = this;
            var oItem = oEvent.getSource().getBindingContext("Notificaciones");
            MessageBox.warning(
                "Desea Eliminar la notificacion?. \nSolo la podrá ver presionando \"Ver todas\".", {
                    icon: MessageBox.Icon.INFORMATION,
                    title: "Eliminar Notificacion",
                    actions: ["Eliminar Notificacion", "Cancelar"],
                    
                    initialFocus: "Cancelar",
                    onClose: function (oAction) { 
                        if (oAction === "Eliminar Notificacion") {
                            that.cerrarNotificacion(oItem);
                        } 
                    }
                }
            );
             
        },

        // no se muestra mas en la "campanita"
        cerrarNotificacion: function (oItem) {
            var sKunnr = oItem.getProperty("kunnr");
            var sPosicion = oItem.getProperty("posicion");
            var oData = {
                kunnr: sKunnr,
                posicion: sPosicion,
                cerrada: "S"
            };
            var that = this;
            this.updateData(oData).then(function () {
                that.onPressRefresh();
            });
        },
        
        
        suspenderNotificacion: function (oItem) {
            //var oItem = oEvent.getSource().getBindingContext("Notificaciones");
            var sKunnr = oItem.getProperty("kunnr");
            var sPosicion = oItem.getProperty("posicion");
            var oData = {
                kunnr: sKunnr,
                posicion: sPosicion,
                suspendida: "S"
            };
            var that = this;
            this.updateData(oData).then(function () {
                that.onPressRefresh();
            });

        },

        onPressItem: function (oEvent) {  
            //this.onPressAccept(oEvent); // Leida/No Leida
            //this.onPressDetail(oEvent); // Accion a realizar
        },

        onPressDetail: function (oEvent) {
            this.marcarComoLeido(oEvent);  // lo marca como leido
            var oItem = oEvent.getSource().getBindingContext("Notificaciones");
            this.executeAction(oItem);

        },

        marcarComoLeido: function(oEvent) {
            var oItem = oEvent.getSource().getBindingContext("Notificaciones");
            var sKunnr = oItem.getProperty("kunnr");
            var sPosicion = oItem.getProperty("posicion");
            var sLeido = oItem.getProperty("leido");
            if (sLeido === "S") {
                return; // ya esta leido
            } else {
                sLeido = "S";
            }

            var oData = {
                kunnr: sKunnr,
                posicion: sPosicion,
                leido: sLeido
            };
            var that = this;
            this.updateData(oData).then(function () {
                that.onPressRefresh();
            });



        },

        onPressAccept: function(oEvent) {
            var oItem = oEvent.getSource().getBindingContext("Notificaciones");
            var sKunnr = oItem.getProperty("kunnr");
            var sPosicion = oItem.getProperty("posicion");
            var sLeido = oItem.getProperty("leido");
            if (sLeido === "S") {
                sLeido = "N";
            } else {
                sLeido = "S";
            }
            var oData = {
                kunnr: sKunnr,
                posicion: sPosicion,
                leido: sLeido
            };
            var that = this;
            this.updateData(oData).then(function () {
                that.onPressRefresh();
            });

        },

        onPressRefresh: function (oEvent) {
            sap.ui.getCore().byId("alertaID").setBusy(true);
            var aFilter = this._buildFilter();
            var that = this;
            this.readDataPromise(aFilter).then(function (oData) {
                var oModel = new JSONModel();
                oModel.setData(oData.results);
                sap.ui.getCore().setModel(oModel,"Notificaciones");
                //sap.ui.getCore().byId("alertaID").setFloatingNumber(oData.results.length);
                var iCounter = that.getCounter(oData.results);
                sap.ui.getCore().byId("alertaID").setFloatingNumber(iCounter);
                sap.ui.getCore().byId("alertaID").setBusy(false);
            });

        },

        onPressRefreshSemaforo: function (oEvent) {
            sap.ui.getCore().byId("semaforoID").setBusy(true);
            var aFilter = this._buildFilter2();
            var that = this;
            this.readDataPromise(aFilter).then(function (oData) {
                var oModel = new JSONModel();
                oModel.setData(oData.results);
                sap.ui.getCore().setModel(oModel,"Semaforos");
                var iCounter = that.getCounterSemaforo(oData.results);
                sap.ui.getCore().byId("semaforoID").setFloatingNumber(iCounter);
                sap.ui.getCore().byId("semaforoID").setBusy(false);
            });

        },

        onPressSemaforo: function (oEvent) {
            var oContext = oEvent.getSource().getBindingContext("Semaforos");
            this.executeAction(oContext);

        },

        onPressCerrarSemaforos: function () {
            this._getDialog2().close();
        },

        onPressCerrarText: function () {
            this._getDialog3().close();
        },

        executeAction: function (oItem) {
            //var sKunnr = oItem.getProperty("kunnr");
            //var sPosicion = oItem.getProperty("posicion");
            var sTitulo = oItem.getProperty("titulo");
            var sLinkApp = oItem.getProperty("linkapp");
            var sLink = oItem.getProperty("link");
            var sLinkRepo = oItem.getProperty("linkrepo");
            var sLinkPdf = oItem.getProperty("linkpdf");
            var sLinkHtml = oItem.getProperty("linkhtml");

            if (sLink) {
                this.navigateToExternalLink(sLink);
            }
            if (sLinkApp) {
                this.navigateToApp(sLinkApp);
            }
            if (sLinkRepo) {
                this.repoFileDownload(sLinkRepo);
            }
            if (sLinkPdf) {
                this.pdfOdataDownload(sLinkPdf);
            }
            if (sLinkHtml) {
                this.displayFormattedText(sTitulo, sLinkHtml);
            }

            if (sLinkApp === "" && sLink === "" && sLinkRepo === "" && sLinkPdf === "" && sLinkHtml === "") {
                //sap.m.MessageToast.show("No hay mas detalles disponibles");
                var sLinkHtml = "<h5>No hay mas detalles disponibles.</h5><p>Gracias.</p>";
                this.displayFormattedText("Notificacion", sLinkHtml);
            }

        },

        
        /**
         * Acciones de la Notificacion
         * @param {Links navigations} sLinkApp 
         */
        navigateToApp: function (sLinkApp) {
            //sLinkkApp = "Orden-Display"
            var aLink = sLinkApp.split("-");  
            if (aLink.length !== 2) {
                return;
            }
            var sSemanticObject = aLink[0];
            var sAction = aLink[1];

            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); 
            var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                target: {
                    semanticObject: sSemanticObject,
                    action: sAction
                }
            })) || ""; 

            oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
            }); 

        },

        navigateToExternalLink: function (sLink) {
            sap.m.URLHelper.redirect(sLink, true);
        },

        pdfOdataDownload: function (sLink) {
            var sUrlPdf = this.getRelativeUrl(sLink);
            sap.m.URLHelper.redirect(sUrlPdf, true);
        },

        repoFileDownload: function (sTextoExt) {
            var aFile = [];
            aFile = sTextoExt.split("/");
            var sRepo = aFile[0];
            var sFile = aFile[1];
            this.setRepoUrl(sRepo, sFile);
            sap.m.MessageToast.show("Descarga de archivo iniciada....");

        },

        displayFormattedText: function (sTitulo, sLinkText) {
            var oModel = new JSONModel({
                titulo: sTitulo,
                HTML: sLinkText
            });
            sap.ui.getCore().setModel(oModel, "FormattedText");
            this._getDialog3().open();
        },



        /**
         * Formatters
         * @param {*} sValue 
         */
        formatAuthor: function (sValue) {
            if (sValue === "") {
                sValue = "Profertil";
            }
            return sValue;
        },

        formatTitulo: function (sValue, sTitulo) {
            if(sValue === 'N') {
                sTitulo = "* " + sTitulo;
            } else {

            }
            return sTitulo;

        },
        
        formatImgSemaforo: function (sValue) {
            if(sValue === '1') {
                return this.getRelativeUrl("/img/red.png");
            } else if (sValue === '2') {
                return this.getRelativeUrl("/img/yellow.png");
            } else if (sValue === '3') {
                return this.getRelativeUrl("/img/green.png");
            }
            return this.getRelativeUrl("/img/green.png");

        },

        formatCloseBtn: function (sValue) {
            if (sValue === 'S' || sValue === 'X') {
                return true;
            }
            return false;

        },

        formatPriority: function (sValue) {
            if(sValue === '1') {
                return 'High';
            } else if (sValue === '2') {
                return 'Medium';
            } else if (sValue === '3') {
                return 'Low';
            }
            return 'None';

        },

        formatBtnType: function (sValue) {
            if(sValue === '1') {
                return 'Reject';
            } else if (sValue === '2') {
                return 'Accept';
            } else if (sValue === '3') {
                return 'Accept';
            }
            return 'Default';
        },

        formatState: function (sValue) {
            if(sValue === '1') {
                return 'Error';
            } else if (sValue === '2') {
                return 'Warning';
            } else if (sValue === '3') {
                return 'Success';
            }
            return 'Information';

        },

        formatIcon: function (sValue) {
            if(sValue === '1') {
                return 'sap-icon://status-error';
            } else if (sValue === '2') {
                return 'sap-icon://alert';
            } else if (sValue === '3') {
                return 'sap-icon://message-success';
            }
            return 'sap-icon://information';
        },

        formatUnread: function (sValue) {
            if (sValue === 'S' || sValue === 'X') {
                return false;
            }
            return true;

        },

        formatHighLight: function (sValue) {
            if(sValue === '1') {
                return "Error"
            }
            if(sValue === '2') {
                return "Warning"
            }
            if(sValue === '3') {
                return "Success"
            }
            return "Information";
        },

        formatInfo: function (sValue) {
            if(sValue === '1') {
                return "Requiere Atencion"
            }
            if(sValue === '2') {
                return "Validar"
            }
            if(sValue === '3') {
                return "Esta Validado"
            }
            return "Information";
        },



        /**
         * Read data
         * 
         */
        readDataPromise: function (aFilter) {
            var that = this;
            return new Promise( function (resolve, reject) {
                var sServiceUrl = that.getModel().sServiceUrl;
                var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, true);
                var sPath = "/NotificacioncliSet";                             
                oModel.read(sPath, {
                    success: function (oData, oResponse) {
                        resolve(oData);
                    },
                    error: function (oError) {
                        console.log("--->>>Error leyendo datos");
                        reject();
                    },
                    filters: aFilter
                });
            });

        }, // readDataPromise

        updateData: function (oData) {
            var that = this;
            return new Promise( function (resolve, reject) {
                var sServiceUrl = that.getModel().sServiceUrl;
                var oModel = new sap.ui.model.odata.v2.ODataModel(sServiceUrl, true);
                oModel.setUseBatch(false);
                var sPath = "/NotificacionSet(kunnr='" + oData.kunnr + "',posicion='" + oData.posicion + "')";
                oModel.update(sPath, oData, {
                    success: function (oData, oResponse) {
                        resolve();
                    },
                    error: function (oError) {
                        console.log("--->>>Error actualizando datos");
                        reject();
                    }
                });
            });

        },




        /**
         * private methods
         */

        // cuenta los no leidos
        getCounter: function (aData) {
            var iCounter = 0;
            for ( var i=0; i < aData.length; i++) {
                if (aData[i].leido === "N") {
                    iCounter += 1;
                }
            }
            return iCounter;

        },

        // cuenta rojos y amarillos
        getCounterSemaforo: function (aData) {
            var iCounter = 0;
            for ( var i=0; i < aData.length; i++) {
                if (aData[i].prioridad !== "3") {
                    iCounter += 1;
                }
            }
            return iCounter;

        },


        //-----
        getRelativeUrl: function (sPath) {
            var sComponent = "profertil.notifcli";
            return jQuery.sap.getModulePath(sComponent) + sPath;
        },

        getDMSUrl: function (sPath) {
            //var sComponent = this.getOwnerComponent().getManifest()["sap.app"]["id"];
            var sComponent = "profertil.notifcli";
            return jQuery.sap.getModulePath(sComponent) + sPath;
        },

        getData: function (path) {
            var url = this.getDMSUrl("/SDM_API/browser");
            var fullUrl = path ? url + "/" + path : url;

            return $.get({ 
                url: fullUrl
            });
        },

        windowOpen: function (sUrl, sObject, sName) {
            var sObjectUri = sUrl + "?objectId=" + sObject + "&cmisSelector=content&download=attachment&filename=" + sName;
            this.navigateToExternalLink(sObjectUri);

        },

        getObjectId: function (oResponse, objectName) {
            for (var i = 0; i < oResponse.objects.length; i++) {
                var oFolderContent = {};
                oFolderContent = oResponse.objects[i].object.properties;
                if (oFolderContent["cmis:name"].value === objectName) {
                    return oFolderContent["cmis:objectId"].value;
                }
            }
            return "";
        },

        readRepository: function (sUrl) {
            return $.get({
                url: sUrl
            });
        },

        repoReadData: function (sUrl, sFileName) {
            var that = this;
            this.readRepository(sUrl).then(response => {
                var objectId = "";
                objectId = that.getObjectId(response, sFileName);
                that.windowOpen(sUrl, objectId, sFileName);
            });

        },

	    setRepoUrl: function (sRepoName, sFileName) {
            var that = this;
            this.getData("")
                .then(response => {
                    var repos = Object.keys(response).filter(repo => response[repo].repositoryName == sRepoName);
                    var root = repos[0] + "/root"
                    var url = this.getDMSUrl("/SDM_API/browser/" + root);
                    that.repoReadData(url, sFileName);

                });
        },

        //-----
        

        _getDialog: function () {
            if (!this._oDialog) {
                this._oDialog = sap.ui.xmlfragment("profertil.notifcli.view.Notificaciones", this);
                sap.ui.getCore().byId("alertaID").addDependent(this._oDialog);  
            }           
            return this._oDialog;
        },

        _getDialog2: function () {
            if (!this._oDialog2) {
                this._oDialog2 = sap.ui.xmlfragment("profertil.notifcli.view.Semaforos", this);
            }           
            return this._oDialog2;
        },

        _getDialog3: function () {
            if (!this._oDialog3) {
                this._oDialog3 = sap.ui.xmlfragment("profertil.notifcli.view.FormattedText", this);
            }           
            return this._oDialog3;
        },

        // filtro de notificaciones manuales
        _buildFilter: function () {           
            var aFilter = [];
            //var sMail = this._getMail();
            //aFilter.push(new Filter("usermail", "EQ", sMail));
            aFilter.push(new Filter("soloactivas", "EQ", "X"));
            aFilter.push(new Filter("tipo", "EQ", "1")); // novedad
            aFilter.push(new Filter("tipo", "EQ", "2")); // circular
            aFilter.push(new Filter("tipo", "EQ", "3")); // procedimiento
            //aFilter.push(new Filter("tipo", "EQ", "4")); // alerta (va en semaforo)
            aFilter.push(new Filter("tipo", "EQ", "5")); // mensaje
            aFilter.push(new Filter("tipo", "EQ", "6")); // automaticas
            //aFilter.push(new Filter("tipo", "EQ", "7")); // template no ven
            //aFilter.push(new Filter("tipo", "EQ", "8")); // semaforo (va en semaforo)
            aFilter.push(new Filter("cerrada", "NE", "S")); // el usuario no la cerro
            return aFilter;
        },

        // filtro de semaforos
        _buildFilter2: function () {           
            var aFilter = [];
            aFilter.push(new Filter("soloactivas", "EQ", "X"));
            aFilter.push(new Filter("tipo", "EQ", "8")); // Semaforo (siempre es uno solo)
            aFilter.push(new Filter("tipo", "EQ", "4")); // Alerta (se puede repetir)
            return aFilter;
        },

        _getMail: function () {
            var sMail = "";
            var oUserInfo = null;
            if (typeof sap.ushell !== 'undefined') {
                oUserInfo = sap.ushell.Container.getService("UserInfo");
                sMail = oUserInfo.getEmail();
            }
            if (typeof sMail === "undefined" || sMail === "") {
                sMail = "";
            }
            return sMail;

        },

        _getRenderer: function () {            
            var that = this;
            var oDeferred = new jQuery.Deferred();
            var oRenderer;
            that._oShellContainer = jQuery.sap.getObject("sap.ushell.Container");

            if (!that._oShellContainer) {
                oDeferred.reject("Shell container not available. Este componente necesita shell container ");
            } else {
                //oRenderer = that._oShellContainer.getRenderer();
                oRenderer = sap.ushell.Container.getRenderer("fiori2");
                if (oRenderer) {
                    oDeferred.resolve(oRenderer);
                } else {
                    // todavia no se inicializo el container, esperamos el evento rendererCreated
                    that._onRendererCreated = function (oEvent) {
                        oRenderer = oEvent.getParameter("renderer");
                        if (oRenderer) {
                            oDeferred.resolve(oRenderer);
                        } else {
                            oDeferred.reject("shell renderer not available after rendererLoadedEvent");
                        }
                    };
                    that._oShellContainer.attachRendererCreatedEvent(that._onRendererCreated);
                }
            }
            return oDeferred.promise();
                
        } // _getRenderer



	});
});



/**
 * 
  messageDisplay: function () {
            var that = this;
            var sTitle = "Notificaciones Importantes";
            var sButtonText1 = "Ver Notificaciones";
            var sButtonText2 = "Las vere Luego";
            MessageBox.show("Tiene Notificaciones importantes. \n Puede verlas en Mis Notificaciones.", {
                icon: MessageBox.Icon.WARNING,
                title: sTitle,
                actions: [sButtonText1, sButtonText2],
                emphasizedAction: sButtonText1,
                initialFocus: sButtonText1,
                onClose: function (oAction) {
                    if (oAction === sButtonText1) {
                        var sLinkApp = "PendientedeLiquidacion-cliente";
                        that.navigateToApp(sLinkApp);
                    }
                }

            });

        },
 */
