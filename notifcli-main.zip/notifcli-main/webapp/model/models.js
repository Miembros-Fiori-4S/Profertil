sap.ui.define([
	"sap/ui/model/json/JSONModel",
	"sap/ui/Device"
], function (JSONModel, Device) {
	"use strict";

	return {

		createDeviceModel: function () {
			var oModel = new JSONModel(Device);
			oModel.setDefaultBindingMode("OneWay");
			return oModel;
        },
        
        createPluginModel: function () {
            var oModel = new JSONModel({
                "counter": 0,
                "mail": ""
            });
            oModel.setDefaultBindingMode("TwoWay");
            return oModel;
        },  

        createMessageModel: function () {
            return new JSONModel();
        }

	};
});