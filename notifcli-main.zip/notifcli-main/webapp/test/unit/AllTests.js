sap.ui.define([
	"profertil/notifcli/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
