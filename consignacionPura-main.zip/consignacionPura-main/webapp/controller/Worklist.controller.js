sap.ui.define([
    "./BaseController",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator, Fragment) {
    "use strict";

    return BaseController.extend("profertil.pendliq1.pendliq1.controller.Worklist", {

        formatter: formatter,

        /* =========================================================== */
        /* lifecycle methods                                           */
        /* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
        onInit: function () {            
            var oViewModel = null;
            oViewModel = new JSONModel({
                isAdmin: this._isAdmin(),
                kunnr: "", //this.readKunnr(),
                name1: ""
            });
            this.getView().setModel(oViewModel, "viewModel");
            
            this.setInitialSortOrder();
            this.setPersonalization();
            this.setName();
            
            //this._getDialogInit();
            this.getRouter().getRoute("worklist").attachPatternMatched(this._onObjectMatched, this);
            
        },

        setPersonalization: function () {
            var oSmartTable = this.getView().byId("table"); 
            if (this._isAdmin()) {
                // admin
                oSmartTable.setIgnoreFromPersonalisation("bsark,bsarktxt,kondm,bzirk");
            } else {
                // cliente
                oSmartTable.setIgnoreFromPersonalisation("kunnr,bsark,bsarktxt,kondm,bzirk,bztxt");
            }

        },

        setInitialSortOrder: function() {
			var oSmartTable = this.getView().byId("table");            
			oSmartTable.applyVariant({
				sort: {
					sortItems: [{ 
						columnKey: "vencpago", 
						operation:"Descending"
					}]
				}
            });            
        },

        setName: function () {
            if (this._isAdmin()) {
                
            } else {
                var sPath = "/getClientData";
                var oModel = this.getOwnerComponent().getModel();
                var that = this;
                oModel.read(sPath, {
                    success: function (oData, oResponse) {
                        that.getView().getModel("viewModel").setProperty("/kunnr", oData.kunnr);
                        that.getView().getModel("viewModel").setProperty("/name1", oData.name1);
                    },
                    error: function (oError) {
                        console.log("--->>>error reading getClientData");
                    }
                });
                
            }

        },

        /*
        _getUserId: function () {
            if ( typeof sap.ushell !== 'undefined') {
                return sap.ushell.Container.getService("UserInfo").getUser().getId();
            }
            return "";
        },

        readKunnr: function () {
            if (!this._isAdmin()) {
                return this._getUserId();
            } 
            // si es admin no deberia traer nada
            return "0000000000";
        },

        getKunnr: function () {
            return this.getView().getModel("viewModel").getProperty("/kunnr");
        },

        setKunnr: function (sKunnr) {
            this.getView().getModel("viewModel").setProperty("/kunnr", sKunnr);
        },
        */

        onBeforeRebindTable: function (oEvent) {           
            var oBindingParams = oEvent.getParameter("bindingParams");

            // filtro kunnr
            if(!this._isAdmin()) {
                var sKunnr = this.getModel("viewModel").getProperty("/kunnr");
                oBindingParams.filters.push(new Filter("kunnr", "EQ", sKunnr));
            }

            // filtro bzirk zona
            var oSmartFilter = this.getView().byId("auxiliarDataFilterBar");
            var oSelect = oSmartFilter.getControlByKey("bzirk");
            var aSelectedKeys = oSelect.getSelectedKeys();
            for (var i = 0; i < aSelectedKeys.length ; i++ ){
                var newFilter = new Filter("bzirk", sap.ui.model.FilterOperator.EQ, aSelectedKeys[i] );            
                oBindingParams.filters.push(newFilter);
            }
            var oKunnr = oSmartFilter.getControlByKey("kunnr");

        },
        
        cargarModelos: function () {
			var oTable = this.byId("pendliqTable");
			var itemsTable = oTable.getItems();
            var aData = [];
            var sKunnr = "";
            var sName1 = "";

            if (itemsTable.length > 0) {
                sKunnr = itemsTable[0].getBindingContext().getProperty("kunnr");
                sName1 = itemsTable[0].getBindingContext().getProperty("name1");
                this.getView().getModel("viewModel").setProperty("/kunnr", sKunnr);
                this.getView().getModel("viewModel").setProperty("/name1", sName1);
                
            }

            if (oTable.getBinding("items").aSorters.length) {
                var sorter = oTable.getBinding("items").aSorters[0].sPath;
            } else {
                return;
            }

			itemsTable.forEach((item2) => {
			  // Se obtienen todas las filas de la tabla
			  if (!(item2 instanceof sap.m.GroupHeaderListItem)) {
				aData.push(item2.getBindingContext().getObject());
			  }
			});
            
			itemsTable.forEach((item) => {
			  // Se toman todas las cabeceras de los grupos
			  if (item instanceof sap.m.GroupHeaderListItem) {
				var valorAgrupado = item.getTitle().split(":")[1].trim(); // para el grouping de smarttable

				var sum = 0;
	  
				aData.forEach((valor) => {  
				  // se controla que el item seleccionado pertenece al grupo en el que se esta trabajando
				  if (valor[sorter] === valorAgrupado) {
					// Se suma al valor total del campo seleccionado (en este caso, saldo)
					sum += parseFloat(valor.tnpend);
				  }
				});
	  
				// se setea en la cabecera del grupo el titulo junto al subtotal de los campos seleccionados
				item.setTitle(item.getTitle() + " - TN Pendiente: " + sum.toFixed(2) + " tn");
			  }

			});

		},

        getTableFilter: function (sKeyValue) {
            var aFilters = [];
            var oFilterData = this.byId(this.byId("table").getSmartFilterId()).getFilterData();
            if (sKeyValue === "kunnr"){
                if (typeof oFilterData.kunnr !== 'undefined') {
                    aFilters = oFilterData.kunnr.ranges;
                }
            }       
            return aFilters;

        },

        getTableItems: function (sKeyValue) {
            var aFilters = [];
            var oFilterData = this.byId(this.byId("table").getSmartFilterId()).getFilterData();
            if (sKeyValue === "kunnr"){
                if (typeof oFilterData.kunnr !== 'undefined') {
                    aFilters = oFilterData.kunnr.items;
                }
            }        
            return aFilters;

        },

        onNavBack: function () {
            // eslint-disable-next-line sap-no-history-manipulation
            history.go(-1);
        },

        /*
        _getDialog: function () {
            
            var oView = this.getView();
            var that = this;
            this._oDialog = Fragment.load({
                id: oView.getId(),
                name: "profertil.pendliq1.pendliq1.view.Resumen",
                controller: this
            }).then(function (oDialog) {
                that._oDialog = oDialog;
                oView.addDependent(that._oDialog);
                that._oDialog.open();
            });

        },

        _getDialogInit: function () {
            
            var oView = this.getView();
            var that = this;
            this._oDialog = Fragment.load({
                id: oView.getId(),
                name: "profertil.pendliq1.pendliq1.view.Resumen",
                controller: this
            }).then(function (oDialog) {
                that._oDialog = oDialog;
                oView.addDependent(that._oDialog);
                //that._oDialog.open();
            });

        },
        */

        _isAdmin: function () {
            return !window.location.href.includes("-display");
        },

        _onObjectMatched: function (oEvent) {

        }
        


    });
});