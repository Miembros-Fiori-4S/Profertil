sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("profertil.recalmosview.controller.Kpi", {

        onInit : function () {

            this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

        },



        _onObjectMatched : function (oEvent) {
			
		}

    });

});