sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter"
], function (BaseController, JSONModel, History, formatter) {
	"use strict";

	return BaseController.extend("profertil.recalmosview.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {
			var	oViewModel = new JSONModel({
					busy : true,
					delay : 0
                });
                
            var oAdjuntosModel = new JSONModel();
            this.getView().setModel(oAdjuntosModel, "adjuntosModel");

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function () {
					// Restore original busy indicator delay for the object view
					//oViewModel.setProperty("/delay", iOriginalBusyDelay);
				}
            );

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */


		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack : function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
        },

        onChangeIdExterno: function (oEvent) {
            var oForm = this.byId("reclamoForm");
			var sPath = oForm.getBindingContext().getPath();
            var that = this;
            var oDataNew = {};
            oDataNew.id_externo = this.byId("externoID").getValue();
            this.updateModel(sPath, oDataNew).then(function (oData) {
                sap.m.MessageToast.show("ID Externo actualizado");
                that.onNavBack();
            }).catch(function (oError){
                sap.m.MessageToast.show("Error al actualizar ID Externo");
            });
            
        },

        updateModel: function (sPath, oData) {
            var that = this;
            return new Promise(function (resolve, reject) {
                var oModel = that.getView().getModel();
                oModel.setUseBatch(false);
                oModel.update(sPath, oData, {
                    success: function (oData) {        
                        oModel.setUseBatch(true);
                        resolve(oData);
                    },
                    error: function (oError) {
                        oModel.setUseBatch(true);
                        reject(oError);
                    }
                });

            });
            

        },
        
        onPressPDF: function (oEvent) {
            var oForm = this.byId("reclamoForm");
            var oData = oForm.getBindingContext().getObject();
            var sServiceUrl = this.getView().getModel().sServiceUrl;
            var sUrl = sServiceUrl + "/PDF_ReclamosSet('" + oData.id  + "')/$value";
            try {
                    sap.m.URLHelper.redirect(sUrl, false)
                }
                catch(oError) {
                    console.log("Error al generar el PDF");
                }

        },

        onPressAttachment: function (oEvent) {
            var oReclamo = this.getView().getBindingContext().getObject();
            var sCliente = oReclamo.cliente;
            var sReclamo = oReclamo.id;           
            var oData = this.getManifestModel("AppModel").getData();
            var sUrlFolder = oData.repoId + "/root" + "/" + sCliente;
            var that = this;
            this.getData(sUrlFolder)
                .then(response => {
                    var sObjectId = that.getObjectId(response, sReclamo);
                    if (sObjectId === "") {
                        that.navigateWithParameters(oData.repoId, oData.rootId);
                    } else {
                        that.navigateWithParameters(oData.repoId, sObjectId);
                    }
                    
                })
                .catch(function () {
                    that.navigateWithParameters(oData.repoId, oData.rootId);
                });

        },

        navigateWithParameters: function (sRepoId, sFolderId) {            
            if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
                var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation"); 
                oCrossAppNav.toExternal({
                    target : { "semanticObject" : "reclrepo", "action" : "display" },
                    params : { "repoId" : sRepoId, "objectId": sFolderId }
                })
            }

        },

        onPressAdjuntoList: function (oEvent) {
            var sUrl = oEvent.getParameter("item").getBindingContext("adjuntosModel").getProperty("url");
            if (sUrl !== "") {
                window.open(sUrl, "_blank");
            }
            
        },

        getObjectId: function (oJsonFolders, sValue) {            
            for(var i=0; i < oJsonFolders.objects.length; i++) {
                var oFolder = {};
                oFolder = oJsonFolders.objects[i].object.properties;
                if (oFolder["cmis:name"].value === sValue) {
                    return oFolder["cmis:objectId"].value;
                }
            }
            return "";

        },

        setStatusAdjuntos: function (aAdjuntos) {
            if (aAdjuntos.length) {
                this.byId("attachmentId").setText(aAdjuntos.length.toString());
                this.byId("attachmentId").setState("Success");
            } else {
                this.byId("attachmentId").setText(aAdjuntos.length.toString());
                this.byId("attachmentId").setState("Error");
            }

        },

        getAdjuntos: function (oResponse) {
            var aAdjuntos = [];
            for(var i=0; i < oResponse.objects.length; i++) {
                var oFolderContent = {};
                oFolderContent = oResponse.objects[i].object.properties;
                var oAdjunto = {};
                oAdjunto = this.getAdjuntoProperties(oFolderContent);                
                aAdjuntos.push(oAdjunto);
            }
            return aAdjuntos;

        },

        getAdjuntoProperties: function (oFolderContent) {
            var oAdjunto = {};
            oAdjunto.objectId = oFolderContent["cmis:objectId"].value;
            oAdjunto.filename = oFolderContent["cmis:name"].value;
            oAdjunto.url = this.getDMSUrl("/SDM_API/browser") + "/" + this.getManifestModel("AppModel").getData().repoId + "/root" + "?objectId=" + oAdjunto.objectId + "&cmisSelector=content&download=attachment&filename=" + oAdjunto.filename;
            return oAdjunto;

        },

        readAttachments: function () {
            var oReclamo = this.getView().getBindingContext().getObject();
            var sReclamo = oReclamo.id;
            var sCliente = oReclamo.cliente;
            var aAdjuntos = [];
            var oModel = this.getManifestModel("AppModel"); 
            var oData = oModel.getData();
            var sUrlFolder = "";
            if (sCliente !== "") {
                sUrlFolder = oData.repoId + "/root" + "/" + sCliente + "/" + sReclamo;
            } else {
                sUrlFolder = oData.repoId + "/root" + "/" + sReclamo;
            }
            var that = this;
            this.getData(sUrlFolder)
                .then(response => {
                    aAdjuntos = that.getAdjuntos(response);
                    that.setStatusAdjuntos(aAdjuntos);
                    if (aAdjuntos.length === 0) {
                        aAdjuntos = [{"filename": "No se encontraron Adjuntos", "url": "", "objectId": ""}];
                    }
                    that.getView().getModel("adjuntosModel").setProperty("/adjuntos", aAdjuntos);
                }).catch(oError => {
                    that.setStatusAdjuntos(aAdjuntos);
                    aAdjuntos = [{"filename": "No se encontraron Adjuntos", "url": "", "objectId": ""}];
                    that.getView().getModel("adjuntosModel").setProperty("/adjuntos", aAdjuntos);
                });

        },


        

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched : function (oEvent) {
			var sObjectId =  oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then( function() {
				var sObjectPath = this.getModel().createKey("ReclamosSet", {
					id :  sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView : function (sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();
            var that = this;
			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange : function () {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}

            oViewModel.setProperty("/busy", false);
            this.readAttachments();

		}

	});

});