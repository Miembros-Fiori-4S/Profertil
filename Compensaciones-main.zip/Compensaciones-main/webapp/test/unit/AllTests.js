sap.ui.define([
	"profertil/compensacionesv2/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
