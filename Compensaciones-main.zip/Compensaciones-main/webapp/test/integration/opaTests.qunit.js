/* global QUnit */

sap.ui.require(["profertil/compensacionesv2/test/integration/AllJourneys"
], function () {
	QUnit.config.autostart = false;
	QUnit.start();
});
