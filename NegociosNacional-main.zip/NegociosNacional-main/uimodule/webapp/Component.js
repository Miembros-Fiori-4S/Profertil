jQuery.Acuerdos = {
	registerExternalLib: function(oShim) {
		if (sap.ui.loader && sap.ui.loader.config) {
			// official API since 1.56
			sap.ui.loader.config({
				shim: oShim
			});
		} else {
			// internal API before 1.56
			jQuery.sap.registerModuleShims(oShim);
		}
	}
};

jQuery.Acuerdos.registerExternalLib({
	"Acuerdos/libs/moment": {
		"amd": true,
		"export": "moment"
	}
});

sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/Device",
  "profertil/historialAcuerdosApp/model/models"
], function(UIComponent, Device, models) {
  "use strict";

  return UIComponent.extend("profertil.historialAcuerdosApp.Component", {

    metadata: {
      manifest: "json"
    },

    /**
     * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
     * @public
     * @override
     */
    init: function() {
      // call the base component's init function
      UIComponent.prototype.init.apply(this, arguments);

      // enable routing
      this.getRouter().initialize();

      // set the device model
      this.setModel(models.createDeviceModel(), "device");
    }
  });
});
