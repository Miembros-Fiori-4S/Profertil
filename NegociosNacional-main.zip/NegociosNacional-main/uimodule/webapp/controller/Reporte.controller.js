/* global moment:true */

sap.ui.define([
  "profertil/historialAcuerdosApp/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  'sap/m/ColumnListItem',
  'sap/m/Label',
  'sap/m/Token',
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "../libs/moment"
], function (Controller, JSONModel, ColumnListItem, Label, Token, Filter, FilterOperator) {
  "use strict";

  return Controller.extend("profertil.historialAcuerdosApp.controller.Reporte", {
    onInit: function () {
      var isUser = this._isUser();

      var jsonModel = new JSONModel({
        showAdminUI: !isUser,
        isUser: isUser,
        isPhone: sap.ui.Device.system.phone
      });

      // // setear el ID de cliente en header from
      // sap._sesionProfertil = { cliente: "0000100606" };
      // var o = XMLHttpRequest.prototype.open;
      // XMLHttpRequest.prototype.open = function () {
      //   var r = o.apply(this, arguments);
      //   if (arguments[1].indexOf("sap/opu/odata/sap") > -1) {
      //     this.setRequestHeader("from", sap._sesionProfertil.cliente);
      //   }
      //   return r;
      // };

      this.getView().setModel(jsonModel, "AdminUI");
    },

    onFBInit: function () {
      var maxDate = new Date();
      var minDate = new Date();

      minDate.setFullYear(maxDate.getFullYear() - 2);

      var filterData = {
        "Fecha": {
          "conditionTypeInfo": {
            "name": "sap.ui.comp.config.condition.DateRangeType",
            "data": {
              "operation": "DATERANGE",
              "key": "Fecha",
              "value1": minDate,
              "value2": maxDate,
              "calendarType": "Gregorian"
            },
            "ranges": [
              {
                "operation": "BT",
                "value1": minDate,
                "value2": minDate,
                "exclude": false,
                "keyField": "Fecha"
              }
            ]
          }
        },
        "Estado": {
          "items": [
            {
              "key": "Abierto",
              "text": "Abierto"
            }
          ]
        }
      }

      this.byId("smartFilterBar").setFilterData(filterData);
    },

    onPress: function (oEvent) {
      // if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
      //   var item = oEvent.getParameter("listItem").getBindingContext().getProperty("Negocio");

      //   var navigationService = sap.ushell.Container.getService('CrossApplicationNavigation');

      //   var hash = navigationService.hrefForExternal({

      //   target: {shellHash: "DocumentosRel-display?&/Documento/CON," + item},

      //   });

      //   var url = window.location.href.replace("sap-ui-app-id=profertil.historialAcuerdosApp", "sap-ui-app-id=profertil.RelatedsDocs").split("#")[0] + hash;

      //   sap.m.URLHelper.redirect(url, true);
      // }

      if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
        var item = oEvent.getParameter("listItem").getBindingContext().getProperty("Negocio");
        var sPath = "DocumentosRel-display?&/Documento/CON," + item;
        var hash = sap.ushell.Container.getService("CrossApplicationNavigation").hrefForExternal({
          target: {
            shellHash: sPath
          }
        });
        var id = window.location.href.substring(window.location.href.indexOf("true&") + 5, window.location.href.lastIndexOf("&sap-startup"));
        var url = window.location.href.replace(id, "sap-ui-app-id=profertil.RelatedsDocs").split("#")[0] + hash;
        //var url = urlH.replace("cp.portal/ui5appruntime.html", "site");
        sap.m.URLHelper.redirect(url, true);
      }
    },

    onBeforeRebindTable: function (oEvent) {

      if (this._isUser()) return;

      var mBindingParams = oEvent.getParameter("bindingParams");

      var filters = this.byId("smartFilterBar").getAllFiltersWithValues();

      var negFilter = filters.filter(item => item.getName() === "Negocio");
      // var dateFilter = filters.filter(item => item.getName() === "Fecha")[0];

      if (negFilter.length > 0) return;

      try {
        var fecha1 = this.byId("smartFilterBar").getFilterData().Fecha.ranges[0].value1;
        var fecha2 = this.byId("smartFilterBar").getFilterData().Fecha.ranges[0].value2;
        if (this._differenceInDays(fecha2, fecha1) > 732) {
          mBindingParams.preventTableBind = true;

          sap.m.MessageBox.error("Por favor, seleccione un periodo de fechas menor a dos años.");
          return;
        }
      } catch (e) {

      };

      // if (!dateFilter) {
      //   mBindingParams.preventTableBind = true;

      //   return sap.m.MessageBox.error("Por favor, seleccione un periodo de fechas menor a dos años.");
      // }

      // var dateControl = dateFilter.getControl();

      // var dates = dateControl.getValue().slice(dateControl.getValue().indexOf("(") + 1, dateControl.getValue().indexOf(")")).split(" - ").map(item => {
      //   var date = item.replace("ene.", "jan.").replace("abr.", "apr.").replace("ago.", "aug.").replace("dic.", "dec.");

      //   return new Date(date)
      // });

      // if (this._differenceInDays(dates[1], dates[0]) > 731) {
      //   mBindingParams.preventTableBind = true;

      //   return sap.m.MessageBox.error("Por favor, seleccione un periodo de fechas menor a dos años.");
      // }

    },

    formatDate: function (date) {
      var oDate = new Date(date);

      let day = oDate.getUTCDate();
      let month = oDate.getUTCMonth() + 1;
      let year = oDate.getUTCFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    formatRowHighlight: function (date) {
      if (!date) return "Error";

      var state = "Error";

      if (moment().isBefore(date)) {
        var a = moment();
        var b = moment(date);

        if (Math.abs(a.diff(b, 'days')) < 8) {
          state = "Warning"
        } else {
          state = "Success";
        }
      }

      return state;
    },

    formatPrice: function (price) {
      var num = parseFloat(price);
      return num.toFixed(2);
    },

    formatBalanceStatus: function (balance) {
      var state = "Error";

      if (balance > 0 && balance <= 150) state = "Warning";
      else if (balance > 150) state = "None";

      return state;
    },

    formatBalance: function (balance) {
      if (balance < 0) {
        return (balance - balance).toFixed(2);
      }

      return balance;
    },

    formatMaterial: function (matnr) {
      return parseInt(matnr);
    },

    formatStatus: function (status) {
      if (!status) return;

      var state = "Error";

      if (status.toLowerCase() == "abierto") state = "Success";

      return state;
    },

    onGroupButtonPressed: function () {
      if (!this._oDialog) {
        this._oDialog = sap.ui.xmlfragment("profertil.historialAcuerdosApp.view.GroupingDialog");
        this.getView().addDependent(this._oDialog);
      }
      this._oDialog.attachConfirm(this.onGroupDialogConfirm);
      this._oDialog.open();
    },

    onGroupDialogConfirm: function (oEvent) {
      var
        oController = this.getParent(),
        oTable = oController.byId("tablaNegocios"),
        mParams = oEvent.getParameters();

      oController.getController().handleSortDialogConfirmWork(oTable, mParams);
    },

    handleSortDialogConfirmWork: function (oTable, mParams) {
      var
        sPath,
        bDescending,
        aSorters = [],
        oBinding = oTable.getBinding("items");

      sPath = mParams.sortItem.getKey();
      bDescending = mParams.sortDescending;

      aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, function (oContext) {
        var name = oContext.getProperty(sPath);
        return {
          key: name,
          text: name
        };
      }));

      oBinding.sort(aSorters);
    },

    cargarModelos: function () {
      var oTable = this.byId("tablaNegocios");

      var itemsTable = oTable.getItems();
      var aData = [];

      itemsTable.forEach((item2) => {
        // Se obtienen todas las filas de la tabla
        if (!(item2 instanceof sap.m.GroupHeaderListItem)) {
          aData.push(item2.getBindingContext().getObject());
        }
      });

      itemsTable.forEach((item) => {
        // Se toman todas las cabeceras de los grupos
        if (item instanceof sap.m.GroupHeaderListItem) {
          // valorAgrupado = Titulo de la cabecera
          var valorAgrupado = item.getTitle();

          var sum = 0;

          aData.forEach((valor) => {
            var sorter = oTable.getBinding("items").sSortParams.replace("$orderby=", '').replace(/%(.*)/g, '');

            // se controla que el item seleccionado pertenece al grupo en el que se esta trabajando
            if (valor[sorter] === valorAgrupado) {
              // Se suma al valor total del campo seleccionado (en este caso, saldo)
              sum += parseFloat(valor.Saldo);
            }
          });

          // se setea en la cabecera del grupo el titulo junto al subtotal de los campos seleccionados
          item.setTitle(valorAgrupado + " - Saldo Total: " + sum.toFixed(2));
        }
      });
    },

    onDocumentDownload: function (oEvent) {
      var negocio = oEvent.oSource.getBindingContext().getObject().Negocio;

      var oModel = this.getView().getModel("relatedDocs");
      var sServiceUrl = oModel.sServiceUrl;
      var sSource = sServiceUrl + "/PrinterSet(TipoDoc='CON',Documento='" + negocio + "')/$value";

      var w = window.open(sSource, '_blank');
      if (w == null) {
        sap.m.MessageBox.warning(oBundle.getText("Error.PopUpBloqued"));
      }
    },

    _isUser: function () {
      var oHashObject = new sap.ui.core.routing.HashChanger();
      return oHashObject.getHash().includes("-display");
    },

    _differenceInDays: function (date1, date2) {
      var difference = Math.abs(date1.getTime() - date2.getTime());

      return difference / (1000 * 60 * 60 * 24);
    }
  });
});

