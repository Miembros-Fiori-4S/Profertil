sap.ui.define([
    "profertil/MantDocImpositiva/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/m/MessageBox"
], function (Controller, JSONModel, Filter, FilterOperator, MessageBox) {
    "use strict";

    var oController;

    return Controller.extend("profertil.MantDocImpositiva.controller.Appview", {

        onInit: function () {
            var oViewModel;
            oController = this;

            oViewModel = new JSONModel({
                isAdmin: oController._isAdmin(),
                askDelete: false,
                tableMode: "None",
                tableType: "Inactive",
                busy: false
            });

            this.setRepoUrl();

            this.setModel(oViewModel, "ImpoView");

            if ((this.getModel("ImpoView").getProperty("/isAdmin")) === true) {
                oController.getModel("ImpoView").setProperty("/tableMode", "Delete");
                oController.getModel("ImpoView").setProperty("/tableType", "Detail");
            }

            this.addHistoryEntry(
                {
                    title: this.getResourceBundle().getText("LegajoViewTitle"),
                    icon: "sap-icon://table-view",
                    intent: `#legajo-${oController._isAdmin() ? "admin" : "display"}`,
                },
                true
            );

            this.initFragments();

        },

        onBeforeRebindTable: function (oEvent) {
            var mBindingParams = oEvent.getParameter("bindingParams");
            //var oSmtFilter = this.getView().byId("smartfilterId");
            var aFilters = [];
            var aFilters = mBindingParams.filters;
            var dDate = this.byId("filterDate").getDateValue();

            if (dDate) {
                var oDateDesde = new Filter("FechaDesde", FilterOperator.LE, dDate);
                aFilters.push(oDateDesde);
                var oDateHasta = new Filter("FechaHasta", FilterOperator.GE, dDate);
                aFilters.push(oDateHasta);
            }

            if (aFilters.length) {
                mBindingParams.filters = aFilters;
            }

        },

        onAdd: function () {
            this.openFragment(
                "CrearCertificado",
                null,
                true,
                this.onFragmentCallback, {
                title: "Añadir Certificado"
            });
        },

        onEditar: function (oEvent) {
            // Shorctur - para que se entienda mejor
            var oBinding = oEvent.getSource().getBindingContext();

            // Guardo los datos en el controlador
            this.oData = {
                New: false,
                Id: oBinding.getProperty("Id"),
                Impuesto: oBinding.getProperty("Impuesto"),
                Jurisdiccion: oBinding.getProperty("Jurisdiccion"),
                Mexclusion: oBinding.getProperty("Mexclusion"),
                Norma: oBinding.getProperty("Norma"),
                FechaDesde: oBinding.getProperty("FechaDesde"),
                FechaHasta: oBinding.getProperty("FechaHasta"),
                FileName: oBinding.getProperty("FileName"),
                Binding: oBinding.getPath(),
                sValue: "none"
            };

            this.openFragment(
                "EditarCertificado",
                null,
                true,
                this.onFragmentCallback,
                this.oData
            );
        },


        onDeleteRow: function (oEvent) {
            var oList = oEvent.getSource(),
                oItem = oEvent.getParameter("listItem"),
                sPath = oItem.getBindingContext().getPath(),
                sFileName = oItem.getBindingContext().getProperty("FileName");

            // after deletion put the focus back to the list
            oList.attachEventOnce("updateFinished", oList.focus, oList);
            var that = this;
            if (this.getModel("ImpoView").getProperty("/askDelete")) {
                this.setBatchFalse();
                oController.getModel().remove(sPath);
                that.deleteCertificadoRepo(sFileName);
            } else {
                sap.m.MessageBox.warning(oController.readFromI18n("deleteConfirm"), {
                    title: oController.readFromI18n("confirmDeleteTitle"),
                    styleClass: "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer", // respomsive padding
                    actions: [sap.m.MessageBox.Action.DELETE,
                    sap.m.MessageBox.Action.CANCEL,
                    oController.readFromI18n("deleteAndDontAskAgain")
                    ], // default
                    emphasizedAction: sap.m.MessageBox.Action.DELETE, // default
                    initialFocus: null, // default
                    textDirection: sap.ui.core.TextDirection.Inherit,
                    onClose: function (oAction) {
                        if (oAction === sap.m.MessageBox.Action.DELETE) {
                            that.setBatchFalse();
                            oController.getModel().remove(sPath);
                            that.deleteCertificadoRepo(sFileName);
                        } else if (oAction !== sap.m.MessageBox.Action.CANCEL) {
                            that.setBatchFalse();
                            oController.getModel().remove(sPath);
                            oController.getModel("ImpoView").setProperty("/askDelete", true);
                        }
                    }
                });
            }

        },

        deleteCertificadoRepo: function (sFileName) {
            var that = this;
            this.readRepository()
                .then(response => {
                    var objectId = "";
                    objectId = that.getObjectId(response, sFileName);
                    that.deleteDocumentFile(objectId).then(function () {
                    }).catch(function () {
                        MessageBox.error("Se produjo un error al eliminar el certificado.\nPor favor, intente mas tarde");
                    });
                });
        },

        deleteDocumentFile: function (sObjectId) {
            var data = new FormData();
            var dataObject = {
                "cmisaction": "delete",
                "objectId": sObjectId
            };

            var keys = Object.keys(dataObject);

            for (var key of keys) {
                data.append(key, dataObject[key]);
            }

            var sDmsUrl = this._dmsUrl;
            return $.ajax({
                url: sDmsUrl,
                type: "POST",
                data: data,
                contentType: false,
                processData: false
            });

        },

        setBatchFalse: function () {
            oController.getModel().setUseBatch(false);
        },

        setBatchTrue: function () {
            oController.getModel().setUseBatch(true);
        },

        getVersion: function () {
            return "";
            //agrega version al nombre del archivo <version>_<nombre_de_archivo>
            //return new Date().getTime() + "_";
        },

        getOriginalFileName: function (sFileName) {
            var sFile = "";
            if (isNaN(parseInt(sFileName.split("_")[0]))) {
                sFile = sFileName; // archivo sin versionado
            } else {
                sFile = sFileName.substring(sFileName.indexOf('_') + 1);
                if (sFile === "") {
                    sFile = sFileName;
                }
            }
            return sFile;

        },

        getDMSUrl: function (sPath) {
            var sComponent = this.getOwnerComponent().getManifest()["sap.app"]["id"]
            return jQuery.sap.getModulePath(sComponent) + sPath;
        },

        getData: function (path) {
            var url = this.getDMSUrl("/SDM_API/browser");
            var fullUrl = path ? url + "/" + path : url;

            return $.get({
                url: fullUrl
            });
        },

        readRepository: function () {
            return $.get({
                url: this._dmsUrl
            });
        },

        setRepoUrl: function () {
            this.getData("")
                .then(response => {
                    var repos = Object.keys(response).filter(repo => response[repo].repositoryName == "DOC_IMPOSITIVA");

                    var root = repos[0] + "/root"

                    var url = this.getDMSUrl("/SDM_API/browser/" + root);

                    this._dmsUrl = url;
                });
        },

        //------------------------------------------ PARA MATIAS --------------------------------------------------
        //La accion del botoncito para poder descargar el archivo que cargaste
        onDownloadCertificado: function (oEvent) {
            var path = oEvent.getSource().getBindingContext().getPath();
            var oModel = this.getView().getModel();

            oModel.read(path + "/FileName", {
                success: function (result) {
                    window.open(this._dmsUrl + "/" + result.FileName);
                }.bind(this),
                error: function (err) {
                    console.log(err);
                }
            })
        },

        onDownloadCertificado2: function (oEvent) {
            var sFileName = oEvent.getSource().getBindingContext().getProperty("FileName");
            var sUrlFolder = this._dmsUrl;

            var that = this;
            this.readRepository()
                .then(response => {
                    var objectId = "";
                    objectId = that.getObjectId(response, sFileName);
                    that.downloadFile(sUrlFolder, objectId, sFileName);
                });

        },

        getObjectId: function (oResponse, objectName) {
            for (var i = 0; i < oResponse.objects.length; i++) {
                var oFolderContent = {};
                oFolderContent = oResponse.objects[i].object.properties;
                if (oFolderContent["cmis:name"].value === objectName) {
                    return oFolderContent["cmis:objectId"].value;
                }
            }
            return "";
        },

        downloadFile: function (sUrl, sObject, sName) {
            var sOriginalName = this.getOriginalFileName(sName);
            var sObjectUri = sUrl + "?objectId=" + sObject + "&cmisSelector=content&download=attachment&filename=" + sOriginalName;
            sap.m.URLHelper.redirect(sObjectUri, true); 
            
        },

        onFragmentCallback: function () {
            return;
        },
        
        _isAdmin: function () {
            return window.location.href.toLowerCase().includes("-admin");
        },


    });
});
