sap.ui.define([
    "../BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
], function (BaseController, JSONModel, MessageBox) {
    "use strict";
    // .bind(this) short cut
    var oController;
    var sResponsivePaddingClasses = "sapUiResponsivePadding--header sapUiResponsivePadding--content sapUiResponsivePadding--footer";
    return BaseController.extend(
        "com.profertil.MantDocImpositiva.controller.fragments.CrearCertificado",
        {
            onBeforeShow: function (parent, fragment, callback, data) {
                oController = this;
                this.parent = parent;
                this.fragment = fragment;
                this.callback = callback;
                this.data = data;
            },

            /**
             * Triggered when close button is pressed.
             * Closes dialog and executes callback function.
             * @function
             * @public
             */
            onClose: function () {
                this._clear();
                oController.fragment.close();
                if (oController.callback)
                    oController.callback.call(oController.parent);
            },

            onChangeImpuesto: function () {
                if (this.fragmentById(this.parent, "_impuesto").getSelectedKey() === "OTR") {
                    this.fragmentById(this.parent, "_impuestoOtro").setVisible(true);
                    this.fragmentById(this.parent, "_cancelarOtro").setVisible(true);
                    this.fragmentById(this.parent, "_impuesto").setVisible(false);
                }
                else {
                    this.fragmentById(this.parent, "_impuestoOtro").setVisible(false);
                    this.fragmentById(this.parent, "_cancelarOtro").setVisible(false);
                }
            },
            onCheckTimeValueDesde: function () {
                if ((this.fragmentById(this.parent, "_FechaHasta").getValue()) !== "") {
                    if ((this.fragmentById(this.parent, "_FechaDesde").getDateValue() > (this.fragmentById(this.parent, "_FechaHasta").getDateValue()))) {
                        sap.m.MessageBox.information("La Fecha hasta no tiene que ser mayor a la Fecha Desde");
                        this.fragmentById(this.parent, "_FechaHasta").setValue("");
                    }
                }
            },
            onCheckTimeValueHasta: function () {
                if ((this.fragmentById(this.parent, "_FechaDesde").getDateValue() > (this.fragmentById(this.parent, "_FechaHasta").getDateValue()))) {
                    sap.m.MessageBox.information("La Fecha hasta no tiene que ser mayor a la Fecha Desde");
                    this.fragmentById(this.parent, "_FechaHasta").setValue("");
                }
            },

            onFileChange: function (oEvent) {
                //var oController = this;
                //var reader = new FileReader();
                var file = oEvent.getParameter("files")[0];
                this._fileName = file.name;
                this._file = oEvent.getParameter("files")[0];

            },

            visibleButton: function () {
                this.fragmentById(this.parent, "_impuesto").setVisible(true);
                this.fragmentById(this.parent, "_impuestoOtro").setVisible(false);
                this.fragmentById(this.parent, "_cancelarOtro").setVisible(false);
            },

            onCrearCertificado: function () {
                // verifica nombre de archivo
                var vFileName = this.fragmentById(this.parent, "fileUploader").getValue();
                var that = this;
                var oModel = this.parent.getModel();
                oModel.read("/LegajoSet", { 
                    success: function (oData) {
                        var aData = [];
                        var sRepetido = "N";
                        aData = oData.results;
                        aData.forEach(function (item) {
                            if (item.FileName === vFileName) {
                               sRepetido = "S";
                            }
                        });
                        if (sRepetido === "S") {
                            MessageBox.error("El nombre del archivo ya existe.\nFavor de elegir otro nombre de archivo");
                        } else {
                            that.onCrearCertificado_OK();
                        }
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show("Error al Verificar los Certificados");
                    }
                });

            },


            onCrearCertificado_OK: function () {
                var vImpuesto;
                if (this.fragmentById(this.parent, "_impuesto").getSelectedKey() === "OTR") {
                    vImpuesto = this.fragmentById(this.parent, "_impuestoOtro").getValue();
                }
                else {
                    vImpuesto = this.fragmentById(this.parent, "_impuesto").getValue();
                }
                var vJurisdiccion = this.fragmentById(this.parent, "_jurisdiccion").getValue();
                var vMExclusion = this.fragmentById(this.parent, "_mexclusion").getValue();
                var vNorma = this.fragmentById(this.parent, "_norma").getValue();
                var vFechaD = this.fragmentById(this.parent, "_FechaDesde").getValue();
                var vFechaH = this.fragmentById(this.parent, "_FechaHasta").getValue();
                var vFileName = this.fragmentById(this.parent, "fileUploader").getValue();

                var aInputs = [oController.fragmentById(oController.parent, "_impuesto"),
                oController.fragmentById(oController.parent, "_jurisdiccion"),
                oController.fragmentById(oController.parent, "_mexclusion"),
                oController.fragmentById(oController.parent, "_norma"),
                oController.fragmentById(oController.parent, "_FechaDesde"),
                oController.fragmentById(oController.parent, "_FechaHasta"),
                oController.fragmentById(oController.parent, "fileUploader")];

                var bValidationError = false;

                // Validate all inputs
                aInputs.forEach(function (oInput) {
                    bValidationError = oController.validateInput(oInput) || bValidationError;
                }, oController);

                //if not errors then create and toggle buttons
                if (!bValidationError) {
                    sap.m.MessageBox.confirm(
                        "Creando certificado:\n\n\nImpuesto: " + vImpuesto +
                        "\n\nJurisdiccion: " + vJurisdiccion +
                        "\n\nMotivo de Exclusion: " + vMExclusion +
                        "\n\nNorma Legal: " + vNorma +
                        "\n\nFecha Desde: " + vFechaD +
                        "\n\nFecha Hasta: " + vFechaH +
                        "\n\nArchivo de Certificado: " + vFileName +
                        "\n\n\nConfirmar y crear certificado?",
                        {
                            onClose: function (oAction) {
                                if (oAction === sap.m.MessageBox.Action.OK) {

                                    var oCertificado = oController.createCertificadoRegister();

                                    if (oController.fragmentById(oController.parent, "_impuesto").getSelectedKey() === "OTR") {
                                        oCertificado.Impuesto = oController.fragmentById(oController.parent, "_impuestoOtro").getValue();
                                    }
                                    else {
                                        oCertificado.Impuesto = oController.fragmentById(oController.parent, "_impuesto").getValue();
                                    }

                                    oCertificado.Jurisdiccion = oController.fragmentById(oController.parent, "_jurisdiccion").getSelectedKey();

                                    oCertificado.Mexclusion = oController.fragmentById(oController.parent, "_mexclusion").getValue();

                                    oCertificado.Norma = oController.fragmentById(oController.parent, "_norma").getValue();

                                    oCertificado.FechaDesde = oController.fragmentById(oController.parent, "_FechaDesde").getDateValue();

                                    oCertificado.FechaHasta = oController.fragmentById(oController.parent, "_FechaHasta").getDateValue();

                                    //------------------------------------------ PARA MATIAS --------------------------------------------------
                                    // Aca lo que hice es SOLO cargar el nombre del archivo. No carga nada de informacion.
                                    // Si buscas el FileName esta en BaseController
                                    oCertificado.FileName = oController.fragmentById(oController.parent, "fileUploader").getValue();


                                    if (oController.type === "New")
                                        oController._addCertificado(oCertificado);
                                    else
                                        oController._addCertificado2(oCertificado);
                                }

                            }
                        });
                }
                else {
                    sap.m.MessageBox.error(oController.parent.readFromI18n("inputErrorMssg"));
                }
            },

            _addCertificado: function (oCertificado) {

                var oModel = this.parent.getModel("Nuevo"),
                    aCertificados = oModel.getProperty("/Legajo");

                aCertificados.push(oCertificado);

                oModel.setProperty("/Legajo", aCertificados);
                this.onClose();
            },

            _addCertificado2: function (oCertificado) {
                oController = this;
                oController.parent = this.parent;

                var oModel = this.parent.getModel();
                var oView = this.parent.getView();
                oView.setBusy(true);
                oModel.setUseBatch(false);

                // agrega la version al nombre de archivo
                var sVersion = this.parent.getVersion();
                oCertificado.FileName = sVersion + oCertificado.FileName;
                this._fileName = oCertificado.FileName;

                oModel.create("/LegajoSet", oCertificado, {
                    success: function (result) {
                        oView.setBusy(false);
                        oController.onClose();
                        this._uploadFile();
                    }.bind(this),
                    error: function (error) {
                        sap.m.MessageToast.show("Surgieron errores al crear el registro");
                        oView.setBusy(false);
                    }
                });
            },

            _uploadFile: function () {
                var data = new FormData();
                var dataObject = {
                    "cmisaction": "createDocument",
                    "propertyId[0]": "cmis:name",
                    "propertyId[1]": "cmis:objectTypeId",
                    "propertyValue[0]": this._fileName,
                    "propertyValue[1]": "cmis:document",
                    "media": this._file,
                }

                var keys = Object.keys(dataObject);

                for (var key of keys) {
                    data.append(key, dataObject[key]);
                }

                $.ajax({
                    url: this.parent._dmsUrl,
                    type: "POST",
                    data: data,
                    contentType: false,
                    processData: false,
                    success: function (oData) {
                        //sap.m.MessageToast.show("Documento Agregado");
                    },
                    error: function (oError) {
                        if (oError.status === 409) {
                            MessageBox.alert("Ya existe un archivo con el mismo nombre.\nNo se subio el archivo.\nSe usara el archivo ya existente para esos impuestos");
                        } else {
                            sap.m.MessageToast.show("Surgieron errores al subir el archivo");
                        }
                        
                    }
                });

            },

            _clear: function () {
                this.fragmentById(this.parent, "fileUploader").setValue("");
                this.fragmentById(this.parent, "_impuesto").setVisible(true);
                this.fragmentById(this.parent, "_impuestoOtro").setVisible(false);
                this.fragmentById(this.parent, "_cancelarOtro").setVisible(false);
                this.fragmentById(this.parent, "_impuesto").setValue("");
                this.fragmentById(this.parent, "_impuestoOtro").setValue("");
                this.fragmentById(this.parent, "_jurisdiccion").setValue("");
                this.fragmentById(this.parent, "_mexclusion").setValue("");
                this.fragmentById(this.parent, "_norma").setValue("");
                this.fragmentById(this.parent, "_FechaDesde").setValue("");
                this.fragmentById(this.parent, "_FechaHasta").setValue("");

                this.fragmentById(this.parent, "fileUploader").setValueState("None");
                this.fragmentById(this.parent, "_impuesto").setValueState("None");
                this.fragmentById(this.parent, "_impuestoOtro").setValueState("None");
                this.fragmentById(this.parent, "_jurisdiccion").setValueState("None");
                this.fragmentById(this.parent, "_mexclusion").setValueState("None");
                this.fragmentById(this.parent, "_norma").setValueState("None");
                this.fragmentById(this.parent, "_FechaDesde").setValueState("None");
                this.fragmentById(this.parent, "_FechaHasta").setValueState("None");
            },
        }
    );
});