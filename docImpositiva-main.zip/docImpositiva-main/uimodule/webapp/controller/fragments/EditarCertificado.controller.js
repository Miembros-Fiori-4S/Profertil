sap.ui.define([
    "../BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox"
], function (BaseController, JSONModel, MessageToast, MessageBox) {
    "use strict";
    var oController;
    var oInputs = [];
    var aInputs = [];

    return BaseController.extend("com.profertil.MantDocImpositiva.controller.fragments.EditarCertificado", {

        onBeforeShow: function (parent, fragment, callback, data) {

            oController = this;

            this.parent = parent;
            this.fragment = fragment;
            this.callback = callback;
            this.data = data;

            var modelJSON = new sap.ui.model.json.JSONModel({
                busy: false,
                delay: 0
            });

            aInputs = [
                this.fragmentById(this.parent, "_impuesto"),
                this.fragmentById(this.parent, "_impuestoOtro"),
                this.fragmentById(this.parent, "_jurisdiccion"),
                this.fragmentById(this.parent, "_mexclusion"),
                this.fragmentById(this.parent, "_norma"),
                this.fragmentById(this.parent, "_FechaDesde"),
                this.fragmentById(this.parent, "_FechaHasta"),
                this.fragmentById(this.parent, "fileUploader"),
            ];
            aInputs.forEach(function (oInput) {
                oInput.setValue(oController.data.sValue);
            });

            this.fragment.attachBeforeOpen(this._onObjectMatched, this);
        },

        _onObjectMatched: function () {
            this.parent
                .getView()
                .getModel()
                .metadataLoaded()
                .then(
                    function () {
                        this._bindView(this.parent.oData.Binding);
                    }.bind(this)
                );
        },

        formatFileName: function (sValue) {
            //return this.getOriginalFileName(sValue);
        },       

        visibleButton: function () {
            this.fragmentById(this.parent, "_impuesto").setVisible(true);
            this.fragmentById(this.parent, "_impuestoOtro").setVisible(false);
            this.fragmentById(this.parent, "_cancelarOtro").setVisible(false);
        },

        onChangeImpuesto: function () {
            if (this.fragmentById(this.parent, "_impuesto").getSelectedKey() === "OTR" || this.fragmentById(this.parent, "_impuesto").getValue() === "Otro") {
                this.fragmentById(this.parent, "_impuestoOtro").setVisible(true);
                this.fragmentById(this.parent, "_cancelarOtro").setVisible(true);
                this.fragmentById(this.parent, "_impuesto").setVisible(false);
            }
            else if (this.fragmentById(this.parent, "_impuesto").getSelectedKey() !== "OTR" || this.fragmentById(this.parent, "_impuesto").getValue() !== "Otro") {
                this.fragmentById(this.parent, "_impuestoOtro").setVisible(false);
                this.fragmentById(this.parent, "_cancelarOtro").setVisible(false);
            }
        },
        onCheckTimeValueDesde: function () {
            if ((this.fragmentById(this.parent, "_FechaHasta").getValue()) !== "") {
                if ((this.fragmentById(this.parent, "_FechaDesde").getDateValue() > (this.fragmentById(this.parent, "_FechaHasta").getDateValue()))) {
                    sap.m.MessageBox.information("La Fecha hasta no tiene que ser mayor a la Fecha Desde");
                    this.fragmentById(this.parent, "_FechaDesde").setValue("");
                }
            }
        },
        onCheckTimeValueHasta: function () {
            if ((this.fragmentById(this.parent, "_FechaDesde").getDateValue() > (this.fragmentById(this.parent, "_FechaHasta").getDateValue()))) {
                sap.m.MessageBox.information("La Fecha hasta no tiene que ser mayor a la Fecha Desde");
                this.fragmentById(this.parent, "_FechaHasta").setValue("");
            }
        },

        onClose: function () {
            this._clear();
            this.fragment.close();
            if (this.callback) this.callback.call(this.parent);
        },

        onActualizarCertificado: function () {
            var vImpuesto = "";
            var vJurisdiccion = "";
            var vMExclusion = "";
            var vNorma = "";
            var vFechaD = "";
            var vFechaH = "";
            var vFileName = "";

            var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ UTC: true });
            var oFechaDesde = dateFormat.format(this.parent.oData.FechaDesde);
            var oFechaHasta = dateFormat.format(this.parent.oData.FechaHasta);
            var JurisFormat = this.parent.formatter.formatProvincias(this.parent.oData.Jurisdiccion);

            var cImpuesto = this.parent.oData.Impuesto;
            var cJurisdiccion = JurisFormat;
            var cMExclusion = this.parent.oData.Mexclusion;
            var cNorma = this.parent.oData.Norma;
            var cFechaD = oFechaDesde;
            var cFechaH = oFechaHasta;
            var cFileName = this.Archivo;

            if (this.fragmentById(this.parent, "_impuesto").getValue() !== cImpuesto) {
                if (this.fragmentById(this.parent, "_impuesto").getSelectedKey() === "OTR") {
                    vImpuesto = " -> " + this.fragmentById(this.parent, "_impuestoOtro").getValue();
                }
                else {
                    vImpuesto = " -> " + this.fragmentById(this.parent, "_impuesto").getValue();
                }
            }
            if (this.fragmentById(this.parent, "_jurisdiccion").getValue() !== cJurisdiccion) {
                vJurisdiccion = " -> " + this.fragmentById(this.parent, "_jurisdiccion").getValue();
            }
            if (this.fragmentById(this.parent, "_mexclusion").getValue() !== cMExclusion) {
                vMExclusion = " -> " + this.fragmentById(this.parent, "_mexclusion").getValue();
            }
            if (this.fragmentById(this.parent, "_norma").getValue() !== cNorma) {
                vNorma = " -> " + this.fragmentById(this.parent, "_norma").getValue();
            }
            if (this.fragmentById(this.parent, "_FechaDesde").getValue() !== cFechaD) {
                vFechaD = " -> " + this.fragmentById(this.parent, "_FechaDesde").getValue();
            }
            if (this.fragmentById(this.parent, "_FechaHasta").getValue() !== cFechaH) {
                vFechaH = " -> " + this.fragmentById(this.parent, "_FechaHasta").getValue();
            }
            if (this.fragmentById(this.parent, "fileUploader").getValue() !== cFileName) {
                vFileName = " -> " + this.fragmentById(this.parent, "fileUploader").getValue();
            }

            var bValidationError = false;
            var bChanges = this._verifyChanges();

            // Validate all inputs
            aInputs.forEach(function (oInput) {
                bValidationError = oController.validateInput(oInput) || bValidationError;
            }, oController);

            var sMessage = this.parent.getView().getModel("i18n").getResourceBundle().getText("format");
            var formattedText = new sap.m.FormattedText();
            var m = formattedText.setHtmlText(sMessage);
            if (bValidationError) {
                return;
            } else if (bChanges) {
                this.onClose();
            } else {
                MessageBox.confirm(
                    "Editando certificado:\n\n\nImpuesto: " + cImpuesto + vImpuesto +
                    "\n\nJurisdiccion: " + cJurisdiccion + vJurisdiccion +
                    "\n\nMotivo de Exclusion: " + cMExclusion + vMExclusion +
                    "\n\nNorma Legal: " + cNorma + vNorma +
                    "\n\nFecha Desde: " + cFechaD + vFechaD +
                    "\n\nFecha Hasta: " + cFechaH + vFechaH +
                    "\n\nArchivo de Certificado: " + cFileName + vFileName +
                    "\n\n\nConfirmar y editar el certificado?",
                    {
                        onClose: function (oAction) {
                            if (oAction === sap.m.MessageBox.Action.OK) {
                                oController._updateMaterial();
                            }
                        }
                    });
            }

            return;
        },
        /* =========================================================== */
        /* internal methods                                            */
        /* =========================================================== */

        _updateMaterial: function () {
            var vImpuesto;
            if (this.fragmentById(this.parent, "_impuesto").getSelectedKey() === "OTR") {
                vImpuesto = aInputs[1].getValue();
            }
            else {
                vImpuesto = aInputs[0].getValue();
            }
            var oEntity = {
                Impuesto: vImpuesto,
                Jurisdiccion: aInputs[2].getSelectedKey(),
                Mexclusion: aInputs[3].getValue(),
                Norma: aInputs[4].getValue(),
                FechaDesde: aInputs[5].getDateValue(),
                FechaHasta: aInputs[6].getDateValue(),
                //------------------------------------------ PARA MATIAS --------------------------------------------------
                // Aca como el Crear Certificado, solo agarra el nombre esto hay que cambiarlo
                FileName: aInputs[7].getValue()
            };
            oController = this;
            var oModel = this.parent.getView().getModel();
            this.fragment.setBusy(true);

            oModel.setUseBatch(false);

            if (this.data.FileName !== oEntity.FileName) {
                // agrego version al archivo
                var sVersion = this.parent.getVersion();
                oEntity.FileName = sVersion + oEntity.FileName;
                this._fileName = oEntity.FileName;
                this.fragmentById(this.parent, "fileUploader").setValue(oEntity.FileName);
            }
            
            oModel.update(this.parent.oData.Binding, oEntity, {
                success: function (resultado) {
                    oController.fragment.setBusy(false);
                    oController.fragment.close();
                    oController._uploadFile();
                },
                error: function (error) {
                    MessageToast.show(oController.readFromI18n("Error"));
                    oController.fragment.setBusy(false);
                }
                
            });
        },

        _uploadFile: function () {
            var data = new FormData();
            var dataObject = {
                "cmisaction": "createDocument",
                "propertyId[0]": "cmis:name",
                "propertyId[1]": "cmis:objectTypeId",
                "propertyValue[0]": this._fileName,
                "propertyValue[1]": "cmis:document",
                "media": this._file,
            }

            var keys = Object.keys(dataObject);

            for (var key of keys) {
                data.append(key, dataObject[key]);
            }

            $.ajax({
                url: this.parent._dmsUrl,
                type: "POST",
                data: data,
                contentType: false,
                processData: false
            });
        },

        onFileChange: function (oEvent) {
            var file = oEvent.getParameter("files")[0];
            this._fileName = file.name;
            this._file = oEvent.getParameter("files")[0];
        },

        _verifyChanges: function () {
            var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ UTC: true });
            var oFechaDesde = dateFormat.format(this.parent.oData.FechaDesde);
            var oFechaHasta = dateFormat.format(this.parent.oData.FechaHasta);
            var Impuestos;
            var eInputs = [
                this.parent.oData.Impuesto,
                this.parent.oData.Jurisdiccion,
                this.parent.oData.Mexclusion,
                this.parent.oData.Norma,
                oFechaDesde,
                oFechaHasta,
                this.Archivo
            ];
            if (this.fragmentById(this.parent, "_impuesto").getSelectedKey() === "OTR") {
                Impuestos = this.fragmentById(this.parent, "_impuestoOtro").getValue();
            }
            else {
                Impuestos = this.fragmentById(this.parent, "_impuesto").getValue();
            }
            var Inputs = [
                Impuestos,
                this.fragmentById(this.parent, "_jurisdiccion").getSelectedKey(),
                this.fragmentById(this.parent, "_mexclusion").getValue(),
                this.fragmentById(this.parent, "_norma").getValue(),
                this.fragmentById(this.parent, "_FechaDesde").getValue(),
                this.fragmentById(this.parent, "_FechaHasta").getValue(),
                this.fragmentById(this.parent, "fileUploader").getValue(),
            ];

            return eInputs[0] === Inputs[0]
                && eInputs[1] === Inputs[1]
                && eInputs[2] === Inputs[2]
                && eInputs[3] === Inputs[3]
                && eInputs[4] === Inputs[4]
                && eInputs[5] === Inputs[5]
                && eInputs[6] === Inputs[6];
        },

        _clear: function () {
            var dateFormat = sap.ui.core.format.DateFormat.getDateInstance({ UTC: true });
            var oFechaDesde = dateFormat.format(this.parent.oData.FechaDesde);
            var oFechaHasta = dateFormat.format(this.parent.oData.FechaHasta);
            this.fragmentById(this.parent, "_impuesto").setVisible(true);
            this.fragmentById(this.parent, "_impuesto").setValue(this.parent.oData.Impuesto);
            this.fragmentById(this.parent, "_cancelarOtro").setVisible(false);
            this.fragmentById(this.parent, "_impuestoOtro").setVisible(false);
            this.fragmentById(this.parent, "_impuestoOtro").setValue(this.parent.oData.Impuesto);
            this.fragmentById(this.parent, "_jurisdiccion").setSelectedKey(this.parent.oData.Jurisdiccion);
            this.fragmentById(this.parent, "_mexclusion").setValue(this.parent.oData.Mexclusion);
            this.fragmentById(this.parent, "_norma").setValue(this.parent.oData.Norma);
            this.fragmentById(this.parent, "_FechaDesde").setValue(oFechaDesde);
            this.fragmentById(this.parent, "_FechaHasta").setValue(oFechaHasta);
            this.fragmentById(this.parent, "fileUploader").setValue(this.Archivo);

            this.fragmentById(this.parent, "fileUploader").setValueState("None");
            this.fragmentById(this.parent, "_impuesto").setValueState("None");
            this.fragmentById(this.parent, "_impuestoOtro").setValueState("None");
            this.fragmentById(this.parent, "_jurisdiccion").setValueState("None");
            this.fragmentById(this.parent, "_mexclusion").setValueState("None");
            this.fragmentById(this.parent, "_norma").setValueState("None");
            this.fragmentById(this.parent, "_FechaDesde").setValueState("None");
            this.fragmentById(this.parent, "_FechaHasta").setValueState("None");
        },

		/**
		 * Binds the view to the object path. Makes sure that detail view displays
		 * a busy indicator while data for the corresponding element binding is loaded.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound to the view.
		 * @private
		 */
        _bindView: function (Binding) {
            var oDataModel = this.parent.getModel();
            var oViewModel = this.parent.getModel("ImpoView");

            this.parent.getView().bindElement({
                path: Binding,
                events: {
                    change: this._onBindingChange.bind(this),
                    dataRequested: function () {
                        oDataModel.metadataLoaded().then(function () {
                            oViewModel.setProperty("/busy", true);
                        });
                    },
                    dataReceived: function () {
                        oViewModel.setProperty("/busy", false);
                    },
                    change: function () {
                        //------------------------------------------ PARA MATIAS --------------------------------------------------
                        // Esto cuando completes tenes que sacarlo solo este codigo
                        oController.Archivo = oController.fragmentById(oController.parent, "fileUploader").getValue();
                        // ---------------------------------------------------------------------------------------------
                        var impuesto = oController.fragmentById(oController.parent, "_impuesto").getValue();
                        if (impuesto !== "Ganancias" && impuesto !== "Impuesto al Valor Agregado" && impuesto !== "Ingresos Brutos" && impuesto !== "Sistema Unico de la Seguridad Social") {
                            oController.fragmentById(oController.parent, "_impuestoOtro").setVisible(true);
                            oController.fragmentById(oController.parent, "_cancelarOtro").setVisible(true);
                            oController.fragmentById(oController.parent, "_impuesto").setVisible(false);
                        }
                    }
                }
            });
        },

        _onBindingChange: function () {
            var oView = this.parent.getView(),
                oElementBinding = oView.getElementBinding();

            // No data for the binding
            if (!oElementBinding.getBoundContext()) {
                this.parent.getRouter().getTargets().display("objectNotFound");
                return;
            }
        }

        
    });
});