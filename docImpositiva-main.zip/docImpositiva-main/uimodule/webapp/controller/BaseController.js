var _fragments = [];
sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "sap/ui/core/UIComponent",
    "profertil/MantDocImpositiva/model/formatter"
], function (Controller, History, UIComponent, formatter) {
    "use strict";
    return Controller.extend("profertil.MantDocImpositiva.controller.BaseController", {

        formatter: formatter,

        /**
         * Convenience method for getting the view model by name in every controller of the application.
         * @public
         * @param {string} sName the model name
         * @returns {sap.ui.model.Model} the model instance
         */
        getModel: function (sName) {
            return this.getView().getModel(sName);
        },

        //------------------------------------------ PARA MATIAS --------------------------------------------------
        // Aca esta para cargar los datos del certificado
        createCertificadoRegister: function () {
            return {
                Impuesto: "",
                Jurisdiccion: "",
                Mexclusion: "",
                Norma: "",
                FechaDesde: "",
                FechaHasta: "",
                FileName: ""
            };
        },

        readFromI18n: function (sKey) {
            return this.getResourceBundle().getText(sKey);
        },

        validateInput: function (oInput) {
            var sValueState = "None";
            var bValidationError = false;
            var oString;

            try {
                oString = oInput.getDOMValue();

                if (oString.length === 0) {
                    bValidationError = true;
                    sValueState = "Error";
                }
            } catch (err) {
                oString = oInput.getValue();

                if (oString.length === 0) {
                    bValidationError = true;
                    sValueState = "Error";
                }
            } finally {
                oInput.setValueState(sValueState);
                return bValidationError;
            }
        },

        /**
         * Convenience method for setting the view model in every controller of the application.
         * @public
         * @param {sap.ui.model.Model} oModel the model instance
         * @param {string} sName the model name
         * @returns {sap.ui.mvc.View} the view instance
         */
        setModel: function (oModel, sName) {
            return this.getView().setModel(oModel, sName);
        },

        /**
         * Convenience method for getting the resource bundle.
         * @public
         * @returns {sap.ui.model.resource.ResourceModel} the resourceModel of the component
         */
        getResourceBundle: function () {
            return this.getOwnerComponent().getModel("i18n").getResourceBundle();
        },

        /**
         * Method for navigation to specific view
         * @public
         * @param {string} psTarget Parameter containing the string for the target navigation
         * @param {Object.<string, string>} pmParameters? Parameters for navigation
         * @param {boolean} pbReplace? Defines if the hash should be replaced (no browser history entry) or set (browser history entry)
         */
        navTo: function (psTarget, pmParameters, pbReplace) {
            this.getRouter().navTo(psTarget, pmParameters, pbReplace);
        },

        getRouter: function () {
            return UIComponent.getRouterFor(this);
        },

        onNavBack: function () {
            var sPreviousHash = History.getInstance().getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.back();
            } else {
                this.getRouter().navTo("appHome", {}, true /*no history*/);
            }
        },

        addHistoryEntry: (function () {
            var aHistoryEntries = [];

            return function (oEntry, bReset) {
                if (bReset) {
                    aHistoryEntries = [];
                }

                var bInHistory = aHistoryEntries.some(function (oHistoryEntry) {
                    return oHistoryEntry.intent === oEntry.intent;
                });

                if (!bInHistory) {
                    aHistoryEntries.push(oEntry);
                    this.getOwnerComponent()
                        .getService("ShellUIService")
                        .then(function (oService) {
                            oService.setHierarchy(aHistoryEntries);
                        });
                }
            };

        })(),

        openFragment: function (sName, model, updateModelAlways, callback, data) {
            if (sName.indexOf(".") > 0) {
                var aViewName = sName.split(".");
                sName = sName.substr(sName.lastIndexOf(".") + 1);
            } else { //current folder
                // eslint-disable-next-line block-scoped-var
                aViewName = this.getView().getViewName().split("."); // view.login.Login
            }
            // eslint-disable-next-line block-scoped-var
            aViewName.pop();
            // eslint-disable-next-line block-scoped-var
            var sViewPath = aViewName.join("."); // view.login

            if (sViewPath.toLowerCase().indexOf("fragments") > 0) {
                sViewPath += ".";
            } else {
                sViewPath += ".fragments.";
            }

            var id = this.getView().getId() + "-" + sName;
            if (!_fragments[id]) {
                //create controller
                var sControllerPath = sViewPath.replace("view", "controller");
                try {
                    var controller = sap.ui.controller(sControllerPath + sName);
                } catch (ex) {
                    controller = this;
                }
                _fragments[id] = {
                    fragment: (sap.ui.require([
                        "sap/ui/core/Fragment"
                    ], function (Fragment) {
                        Fragment.load({
                            id: id,
                            name: sViewPath + sName,
                            controller: controller
                        }).then(function (oFragment) {
                            // version >= 1.20.x
                            _fragments[id].fragment = oFragment;
                            this.getView().addDependent(oFragment);
                            var fragment = oFragment;

                            if (model && updateModelAlways) {
                                fragment.setModel(model);
                            }
                            if (_fragments[id].controller && _fragments[id].controller !== this) {
                                _fragments[id].controller.onBeforeShow(this, fragment, callback, data);
                            }

                            setTimeout(function () {
                                fragment.open();
                            }, 100);
                        }.bind(this));
                    }.bind(this))),
                    controller: controller
                };

            } else
                _fragments[id].fragment.open();

        },
    	/**
		 * Convenince method for getting a control from in the fragment
		 * @public
		 * @param {sap.ui.mvc.parent}
		 * @param {string} id of control
		 * Use example:
		 *	var oButton = this.fragmentById(this.parent,"button0");
		 */
        fragmentById: function (parent, id) {
            var latest = this.getMetadata().getName().split(".")[this.getMetadata().getName().split(".").length - 1];
            return sap.ui.getCore().byId(parent.getView().getId() + "-" + latest + "--" + id);
        },

        closeFragments: function () {
            for (var f in _fragments) {
                if (_fragments[f]["fragment"] && _fragments[f].fragment["isOpen"] && _fragments[f].fragment.isOpen()) {
                    _fragments[f].fragment.close();
                }
            }
        },

		/**
		 * Convenince method for getting an specific fragment
		 * @public
		 * @param {string} fragment name
		 */
        getFragment: function (fragment) {
            return _fragments[this.getView().getId() + "-" + fragment];
        },

        initFragments: function () {
            //console.warn("initilizing fragments...");
            _fragments = [];
        },



    });

});
