sap.ui.define([], function () {
	"use strict";
	return {
  dateFormat: (dDate) => {
  return dDate ? dDate.toLocaleDateString() : "";
  },
  formatProvincias: (dProvincia) => {
        if (dProvincia === "NAC"){
          return "Nacional";
        }
        else if (dProvincia === "BAS"){
          return "Buenos Aires";
        }
        else if (dProvincia === "CAT"){
          return "Catamarca";
        }
        else if (dProvincia === "CHA"){
          return "Chaco";
        }
        else if (dProvincia === "CHU"){
          return "Chubut";
        }
        else if (dProvincia === "CORD"){
          return "Córdoba";
        }
        else if (dProvincia === "CORR"){
          return "Corrientes";
        }
        else if (dProvincia === "ENR"){
          return "Entre Ríos";
        }
        else if (dProvincia === "FOR"){
          return "Formosa";
        }
        else if (dProvincia === "JUJ"){
          return "Jujuy";
        }
        else if (dProvincia === "PAM"){
          return "La Pampa";
        }
        else if (dProvincia === "RIO"){
          return "La Rioja";
        }
        else if (dProvincia === "MEN"){
          return "Mendoza";
        }
        else if (dProvincia === "MIS"){
          return "Misiones";
        }
        else if (dProvincia === "NEU"){
          return "Neuquén";
        }
        else if (dProvincia === "RIN"){
          return "Río Negro";
        }
        else if (dProvincia === "SAL"){
          return "Salta";
        }
        else if (dProvincia === "SANJ"){
          return "San Juan";
        }
        else if (dProvincia === "SANL"){
          return "San Luis";
        }
        else if (dProvincia === "SANC"){
          return "Santa Cruz";
        }
        else if (dProvincia === "SANF"){
          return "Santa Fe";
        }
        else if (dProvincia === "STE"){
          return "Santiago del Estero";
        }
        else if (dProvincia === "TF"){
          return "Tierra del Fuego";
        }
        else if (dProvincia === "TU"){
          return "Tucumán";
        }
      },
  };
});
