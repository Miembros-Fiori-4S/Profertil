# Mis Entregas Dealers

Mis Entregas allows a customer to visualize theirs shipment documents and download associated tickets and related documents.

See [Chengelog](./CHANGELOG.md).
If you continue the development please, follow [standard-version](https://github.com/conventional-changelog/standard-version).

## Credits
This project has been generated with 💙 and [easy-ui5](https://github.com/SAP)
Initial release by [Tomas Sanchez](https://github.com/tomasanchez). @Softtek - Feb 2021.
