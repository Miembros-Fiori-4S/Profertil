sap.ui.define([
    "profertil/AppReclamos/Reclamos/controller/BaseController",
    'sap/ui/model/json/JSONModel',
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/library",
    "sap/ui/core/Fragment"
], function (Controller, JSONModel, MessageToast, MessageBox, Filter, FilterOperator, CoreLibrary, Fragment) {
    "use strict";
    var oController;

    return Controller.extend("profertil.AppReclamos.Reclamos.controller.MainView", {
        onInit: function () {

            oController = this;

            this.getView().setModel(new JSONModel({
                backButtonVisible: false,
                nextButtonVisible: false,
                backButtonEnabled: true,
                finishButtonVisible: false,
                maxDate: new Date()
            }), "view");

            this._oWizard = this.byId("Wizard01");

            this.setRepoUrl();
        },

        onAfterRendering: function () {

            setTimeout(function () {
                this._oWizard = this.byId("Wizard01");
                this.handleButtonsVisibility();
            }.bind(this), 50);
        },

        handleButtonsVisibility: function () {

            var oModel = this.getView().getModel("view");

            switch (this._oWizard.getProgress()) {
                case 1:
                    oModel.setProperty("/nextButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", false);
                    oModel.setProperty("/backButtonVisible", false);
                    oModel.setProperty("/finishButtonVisible", false);
                    break;
                case 2:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", false);
                    break;
                case 3:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonVisible", true);
                    break;
                case 4:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", false);
                    break;
                case 5:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", true);
                    break;
                case 6:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonVisible", false);
                    oModel.setProperty("/finishButtonVisible", false);
                    break;
                default: break;
            }
        },

        handleButtonsVisibilityBack: function () {

            var oModel = this.getView().getModel("view");

            switch (this._oWizard.getProgress()) {
                case 1:
                    oModel.setProperty("/nextButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", true);
                    oModel.setProperty("/backButtonVisible", false);
                    oModel.setProperty("/finishButtonVisible", false);
                    break;
                case 2:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", true);
                    break;
                case 3:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", true);
                    break;
                case 4:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", true);
                    break;
                case 5:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonVisible", true);
                    oModel.setProperty("/nextButtonEnabled", true);
                    break;
                case 6:
                    oModel.setProperty("/backButtonVisible", true);
                    oModel.setProperty("/nextButtonVisible", false);
                    oModel.setProperty("/finishButtonVisible", false);
                    break;
                default: break;
            }
        },

        onNextButton: function () {

            if (this._oWizard.getProgressStep().getValidated()) {
                this._oWizard.nextStep();
            }

            this.handleButtonsVisibility();
        },

        onBackButton: function () {

            this._oWizard.previousStep();
            this.handleButtonsVisibilityBack();
        },

        onObtenerCupo: function (oEvent) {
            var oFilters = [],
                oValue = oEvent.oSource.getValue(),
                oModel = this.getView().getModel();

            if (oValue) {
                oFilters.push(new sap.ui.model.Filter("Cupo", sap.ui.model.FilterOperator.EQ, oValue));
            }
            oModel.read("/CuposSet", {
                filters: oFilters,
                success: function (resultado) {
                    this.getView().setModel(new JSONModel(resultado.results), "cupo");
                }.bind(this),
                error: function (e) {

                }.bind(this)
            });

            if (!this._oDialog) {
                this._oDialog = sap.ui.xmlfragment("profertil.AppReclamos.Reclamos.view.Cupo", this);
                this.getView().addDependent(this._oDialog);
                this._oDialog.setModel((this.getView().getModel("cupo"), "cupo"));
            }

            if (oValue == "") {

            } else {
                this._oDialog.open();
            }
        },

        onClose: function () {
            this._oDialog.close();
        },

        onSelectCupo: function (oEvent) {
            this._oDialog.close();
            var Producto = this.byId("_producto"),
                Terminal = this.byId("cbTerminal"),
                Composicion = this.byId("_cQuimica"),
                Cantidad = this.byId("_cantidadAfectada"),
                Remito = this.byId("_remitos"),
                FechaCarga = this.byId("_fechaCarga");

            Producto.setSelectedKey(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("Producto"));
            Terminal.setSelectedKey(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("PlantaOrigen"));
            // Transporte.setSelectedKey(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("Transporte"));
            Composicion.setValue(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("Composicion"));
            Cantidad.setValue(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("Cantidad"));
            Remito.setValue(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("Remito"));
            FechaCarga.setValue(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("FechaCarga").toLocaleDateString());

            this.onSelectKeyTerminal(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("TermOut"));

            this.fillTransporte(oEvent.getSource().getSelectedItem().getBindingContext("cupo").getProperty("Transporte"));

            this._oWizard.validateStep(this.byId("ws03"));
        },

        fillTransporte: function (key) {
            var Transporte = this.byId("_transporte"),
                valor;

            switch (key) {
                case 'DEL':
                case 'DES':
                case 'DEF':
                case 'CFR':
                case 'EXW':
                    valor = 'PRO';
                    break;
                case 'FOT':
                case 'FOR':
                    valor = 'CLI';
                    break;
                default:
                    valor = '';
                    break;
            }
            Transporte.setSelectedKey(valor);
        },

        onSelectKey: function () {

            var categoria = this.getView().byId("_tipoReclamo");
            var texto = this.getView().byId("_otroReclamo");
            var key = this.getView().byId("cbCategoria").getSelectedKey();

            var oItemTemplate = new sap.ui.core.Item({
                key: '{IdCategoria}',
                text: '{Descripcion}'
            });

            if (key == 'OTROS') {
                categoria.setValue();
                categoria.setVisible(false);
                texto.setValue("");
                texto.setVisible(true);
            } else {
                texto.setValue("");
                texto.setVisible(false);
                categoria.setValue();
                categoria.setVisible(true);
                categoria.bindAggregation("items", {
                    path: "/TipoReclamoSet('" + key + "')/SubCategoriaSet",
                    template: oItemTemplate,
                    templateShareable: true
                });
            }
        },

        onSelectKeyTerminal: function (sKey) {

            var categoria = this.getView().byId("_terminal");
            categoria.setValue();
            categoria.setVisible(true);

            var key = this.getView().byId("cbTerminal").getSelectedKey();
            var oItemTemplate = new sap.ui.core.Item({
                key: '{IdTerminal}',
                text: '{Descripcion}'
            });

            var oFilter = new sap.ui.model.Filter("IdTerminal", sap.ui.model.FilterOperator.EQ, key);

             categoria.bindAggregation("items", {
                path: "/TerminalesSet",
                filters: [oFilter],
                template: oItemTemplate,
                templateShareable: true
            });

            if (typeof sKey == 'string') categoria.setSelectedKey(sKey);
            
        },

        _obtenerDatos: function () {

            var aReclamo = {
                FechaDet: new Date(this.byId("_fechaDeteccion").getDateValue()),
                LugarDeteccion: this.byId("_lugarDeteccion").getValue(),
                TipoReclamo: this.byId("_tipoReclamo").getSelectedKey(),
                OtroReclamo: this.byId("_otroReclamo").getValue(),
                ProductoId: this.byId("_producto").getSelectedKey(),
                Cantidad: this.byId("_cantidadAfectada").getValue(),
                ComposQuim: this.byId("_cQuimica").getValue(),
                Terminal: this.byId("_terminal").getSelectedKey(),
                Transporte: this.byId("_transporte").getSelectedKey(),
                Remitos: this.byId("_remitos").getValue(),
                Observaciones: this.byId("_observaciones").getValue(),
                ContactoNom: this.byId("_contactoNombre").getValue(),
                ContactoTel: this.byId("_telefono").getValue(),
                ContactoMail: this.byId("_email").getValue(),
                FechaCarga: new Date(this.byId("_fechaCarga").getDateValue())
            };
            if (aReclamo.TipoReclamo === "" || aReclamo.TipoReclamo === "OTR") {
              aReclamo.TipoReclamo = "OT";
            }
            return aReclamo;

        },

        wizardCompletedHandler: function () {

            var oModel = oController.getView().getModel();
            var oEntity = oController._obtenerDatos();
            oModel.setUseBatch(false);
            oModel.create("/ReclamosSet", oEntity, {
                success: function (resultado) {
                    var id = resultado.Id,
                        cliente = resultado.Cliente;

                    this.uploadFiles(cliente, id);

                    MessageBox.success("Reclamo N° "+ id +" enviado.", {
                        actions: [MessageBox.Action.OK],
                        emphasizedAction: MessageBox.Action.OK,
                        onClose: function (sAction) {
                            if (sAction == MessageBox.Action.OK) {
                                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                                if (oCrossAppNavigator) {
                                    oCrossAppNavigator.toExternal({
                                        target: { semanticObject: "#" }
                                    });
                                }
                            }
                        }
                    });
                }.bind(this),
                error: function (error) {
                    MessageToast.show("Error: Algo salió mal");
                    MessageBox.error("Verifique los datos");
                    oController.getView().setBusy(false);
                }
            });
        },

        uploadFiles: function (client, claim) {
            var file, filename;

            this.getClientFolder(client)
                .then(() => {
                    return this.getClaimFolder(client, claim);
                })
                .catch(() => {
                    return this.getClaimFolder(client, claim);
                })
                .then(() => {
                    var uploadSet = this.byId("UploadSet");
                    var items = this.byId("UploadSet").getIncompleteItems();

                    var path = "/" + client + "/" + claim;

                    for (var i = 0; i < items.length; i++) {
                        file = items[i].getFileObject();
                        filename = file.name;

                        this.uploadSingleFile(file, filename, path);
                    }

                });
        },

        getClientFolder: function (client) {
            return this.createFolder(client);
        },

        getClaimFolder: function (client, claim) {
            return this.createFolder(claim, "/" + client);
        },

        uploadSingleFile: function (file, filename, path) {
            var data = new FormData();
            var dataObject = {
                "cmisaction": "createDocument",
                "propertyId[0]": "cmis:name",
                "propertyId[1]": "cmis:objectTypeId",
                "propertyValue[0]": filename,
                "propertyValue[1]": "cmis:document",
                "media": file,
            };

            var keys = Object.keys(dataObject);

            for (var key of keys) {
                data.append(key, dataObject[key]);
            }

            $.ajax({
                url: this._dmsUrl + path,
                type: "POST",
                data: data,
                contentType: false,
                processData: false
            });
        },

        createFolder: function (foldername, path) {
            var data = new FormData();
            var dataObject = {
                "cmisaction": "createFolder",
                "propertyId[0]": "cmis:name",
                "propertyId[1]": "cmis:objectTypeId",
                "propertyValue[0]": foldername,
                "propertyValue[1]": "cmis:folder"
            };

            var keys = Object.keys(dataObject);

            for (var key of keys) {
                data.append(key, dataObject[key]);
            }

            return $.ajax({
                url: this._dmsUrl + (!path ? "" : path),
                type: "POST",
                data: data,
                contentType: false,
                processData: false
            });
        },

        getDMSUrl: function (sPath) {
            var sComponent = this.getOwnerComponent().getManifest()["sap.app"]["id"]
            return jQuery.sap.getModulePath(sComponent) + sPath;
        },

        getData: function (path) {
            var url = this.getDMSUrl("/SDM_API/browser");
            var fullUrl = path ? url + "/" + path : url;

            return $.get({
                url: fullUrl
            });
        },

        setRepoUrl: function () {
            this.getData("")
                .then(response => {
                    var repos = Object.keys(response).filter(repo => response[repo].repositoryName == "RECLAMOS");

                    var root = repos[0] + "/root";

                    var url = this.getDMSUrl("/SDM_API/browser/" + root);

                    this._dmsUrl = url;
                });
        },


        onActivateStep1: function () {

            var oModel = this.getView().getModel("view"),
                sCombo2 = this.byId("_tipoReclamo").getSelectedKey(),
                sTexto = this.byId("_otroReclamo").getValue();

            this.handleButtonsVisibility();

            if (sCombo2 || sTexto.length > 5) {
                this._oWizard.validateStep(this.byId("ws01"));
                oModel.setProperty("/nextButtonEnabled", true);
            } else {
                this._oWizard.invalidateStep(this.byId("ws01"));
                oModel.setProperty("/nextButtonEnabled", false);
            }
        },

        onActivateStep2: function () {

            var oModel = this.getView().getModel("view"),
                sLugar = this.byId("_lugarDeteccion").getValue(),
                sRemito = this.byId("_remitos").getValue(),
                sFecha = this.byId("_fechaDeteccion").getValue();

            this.handleButtonsVisibility();

            if ((!sFecha) || (sLugar.length < 4 || sRemito.length < 6)) {
                this._oWizard.invalidateStep(this.byId("ws02"));
                oModel.setProperty("/nextButtonEnabled", false);
            } else {
                this._oWizard.validateStep(this.byId("ws02"));
                oModel.setProperty("/nextButtonEnabled", true);
            }
        },

        onActivateStep3: function () {

            var oModel = this.getView().getModel("view"),
                sCombo2 = this.byId("_terminal").getSelectedKey(),
                sTransporte = this.byId("_transporte").getSelectedKey(),
                sFecha = this.byId("_fechaCarga").getValue();

            if ((!sFecha) || (!sCombo2) || (!sTransporte)) {
                this._oWizard.invalidateStep(this.byId("ws03"));
                oModel.setProperty("/nextButtonEnabled", false);
            } else {
                this._oWizard.validateStep(this.byId("ws03"));
                oModel.setProperty("/nextButtonEnabled", true);
            }
        },

        onActivateStep4: function () {

            var oModel = this.getView().getModel("view"),
                sProducto = this.byId("_producto").getSelectedKey(),
                //  sQuimica = this.byId( "_cQuimica").getValue(),
                sCantidad = parseInt(this.byId("_cantidadAfectada").getValue()),
                sDescripcion = this.byId("_observaciones").getValue();

            this.handleButtonsVisibility();

            if ((!sProducto) || (isNaN(sCantidad)) || (sDescripcion.length < 4)) {
                this._oWizard.invalidateStep(this.byId("ws04"));
                oModel.setProperty("/nextButtonEnabled", false);
            } else {
                this._oWizard.validateStep(this.byId("ws04"));
                oModel.setProperty("/nextButtonEnabled", true);
            }

        },

        onActivateStep6: function () {

            var oModel = this.getView().getModel("view"),
                sContacto = this.byId("_contactoNombre").getValue(),
                sMail = this.byId("_email").getValue(),
                sTelefono = (this.byId("_telefono").getValue());

            this.handleButtonsVisibility();


            if ((sContacto.length < 4) || (sMail.length < 4) || (sTelefono.length <= 7)) {
                this._oWizard.invalidateStep(this.byId("ws06"));
                oModel.setProperty("/nextButtonVisible", false);
                oModel.setProperty("/finishButtonVisible", false);
            } else {
                this._oWizard.validateStep(this.byId("ws06"));
                oModel.setProperty("/finishButtonVisible", true);
            }
        },

        onFileNameError: function(oEvent) {
          var item = oEvent.getParameter("item");

          item.destroy();

          MessageBox.error("El nombre del archivo es muy largo (Max. 50 caracteres).");
        },

        onFileSizeError: function(oEvent) {
          var item = oEvent.getParameter("item");

          item.destroy();

          MessageBox.error("El archivo es demasiado grande (Max. 50MB).");
        },

        onFileTypeError: function(oEvent) {
          var item = oEvent.getParameter("item");

          item.destroy();

          MessageBox.error("El tipo de archivo no es valido.");
        },

    });
});

