sap.ui.define([], function () {
	"use strict";
	return {

    dateFormat: dDate => {
      return dDate ? dDate.toLocaleDateString() : "";
    },

    formatName: function (str) {
			var sReturn = str;
			try {
				sReturn = str.replace(
					/\w\S*/g,
					function (txt) {
						return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
					}
				);
			} finally {
				return sReturn;
			}
    },

    fixZero: function (s) {
      return parseInt(s, 10);
		}
  };
});
