## Application Details
|               |
| ------------- |
|**Generation Date and Time**<br>Mon Apr 26 2021 14:27:56 GMT+0000 (Coordinated Universal Time)|
|**App Generator**<br>@sap/generator-fiori|
|**App Generator Version**<br>1.1.9|
|**Generation Platform**<br>SAP Business Application Studio|
|**Floorplan Used**<br>simple|
|**Service Type**<br>SAP System (ABAP On Premise)|
|**Service URL**<br>http://profertil.dev:80/sap/opu/odata/sap/ZSV_SELECCION_CLIENTE_SRV
|**Module Name**<br>seleccioncliente|
|**Application Title**<br>Selección de cliente|
|**Namespace**<br>profertil|
|**UI5 Theme**<br>sap_fiori_3|
|**UI5 Version**<br>Latest|
|**Enable Telemetry**<br>True|

## seleccioncliente

Selección de cliente

### Starting the generated app

-   This app has been generated using the SAP Fiori tools - App Generator, as part of the SAP Fiori tools suite.  In order to launch the generated app, simply run the following from the generated app root folder:

```
    npm start
```


#### Pre-requisites:

1. Active NodeJS LTS (Long Term Support) version and associated supported NPM version.  (See https://nodejs.org)


