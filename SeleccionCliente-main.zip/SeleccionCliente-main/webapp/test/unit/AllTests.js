sap.ui.define([
	"profertil/seleccioncliente/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
