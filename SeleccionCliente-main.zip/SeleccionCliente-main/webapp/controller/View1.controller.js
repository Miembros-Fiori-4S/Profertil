sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
    function (Controller, MessageBox) {
        "use strict";

        return Controller.extend("profertil.seleccioncliente.controller.View1", {
            onInit: function () {

                this.oTextos = this.getOwnerComponent().getModel("i18n").getResourceBundle();
            },

            onBuscarClientes: function () {
                var oView = this.getView();
                var aFiltros = [];
                var oTabla = oView.byId("idTablaClientes");
                var searchString = oView.byId("idBuscador").getValue();

                if (searchString.length > 0 && searchString.length < 3) {
                    sap.m.MessageToast.show("Para buscar escriba al menos 3 caracteres");
                    return;
                }

                // en backend se desglosa la busqueda
                if (searchString) {
                    aFiltros.push(new sap.ui.model.Filter("IdCliente", sap.ui.model.FilterOperator.EQ, searchString));
                }
                if (searchString) {
                    aFiltros.push(new sap.ui.model.Filter("Cuit", sap.ui.model.FilterOperator.EQ, searchString));
                }
                if (searchString) {
                    aFiltros.push(new sap.ui.model.Filter("Nombre", sap.ui.model.FilterOperator.EQ, searchString));
                }

                oTabla.getBinding("items").filter(aFiltros);
            },

            onFavorito: function (oEvent) {
                var sPath = oEvent.getSource().getBindingContext().sPath;
                var nuevoEstado = oEvent.getParameter("pressed");

                var oTextos = this.getOwnerComponent().getModel("i18n").getResourceBundle();
                this.getView().getModel().update(sPath, {
                    Favorito: nuevoEstado
                }, {
                    success: function (oData, oResponse) {
                        if (nuevoEstado) {
                            sap.m.MessageToast.show(oTextos.getText("mensaje_success_agregar_favorito"));
                        } else {
                            sap.m.MessageToast.show(oTextos.getText("mensaje_success_quitar_favorito"));
                        }
                    },
                    error: function (oResponse) {
                        sap.m.MessageToast.show(oTextos.getText("error_generico"));
                    }
                });
            },

            onSeleccionar: function (oEvent) {
                var mensaje;
                var titulo = this.oTextos.getText("seleccionar_titulo");
                var vCliente = oEvent.getSource().getBindingContext().getObject().IdCliente;
                var vNombre = oEvent.getSource().getBindingContext().getObject().Nombre;

                jQuery.sap.storage.put("profertil.sesion.cliente", vCliente);
                jQuery.sap.storage.put("profertil.sesion.nombreCliente", vNombre);

                // setear el ID de cliente en header from
                var o = XMLHttpRequest.prototype.open;
                XMLHttpRequest.prototype.open = function () {
                    var r = o.apply(this, arguments);
                    if (arguments[1].indexOf("sap/opu/odata/sap") > 0) {
                        var cliente = jQuery.sap.storage.get("profertil.sesion.cliente");
                        if (cliente) {
                            this.setRequestHeader("from", cliente);
                        }
                    }
                    return r;
                };



                mensaje = this.oTextos.getText("seleccionar_mensaje", [vNombre, vCliente]);

                MessageBox.success(mensaje, {
                    title: titulo,
                    onClose: this.onCloseMensaje
                });

                // disparar evento profertil/clienteSeleccionado
                var oEventBus = sap.ui.getCore().getEventBus();
                oEventBus.publish("profertil", "clienteSeleccionado", oEvent.getSource().getBindingContext().getObject());
            },

            onCloseMensaje: function () {
                // volver al launchpad
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
                oCrossAppNavigator.toExternal({
                    target: {
                        semanticObject: "#"
                    }
                });
            }
        });
    });
