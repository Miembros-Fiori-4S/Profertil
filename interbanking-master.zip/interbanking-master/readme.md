# Interbanking

Interbanking allows customers to pay.

See [Chengelog](./CHANGELOG.md).
If you continue the development please, follow [standard-version](https://github.com/conventional-changelog/standard-version).

## Credits
This project has been generated with 💙 and [easy-ui5](https://github.com/SAP)
Initial release by [Tomas Sanchez](https://github.com/tomasanchez). @Softtek - March 2021.
