sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "profertil/plugincai2/model/models"
], function (UIComponent, Device, models) {
    "use strict";



    return UIComponent.extend("profertil.plugincai2.Component", {


        metadata: {
            manifest: "json"
        },
        init: function () {
            var e = this._getRenderer();

            var oPluginParameters = this.getComponentData().config; // obtain plugin parameters

            if (!document.getElementById("cai-webchat-new")) {
                var e = document.createElement("script");
                e.setAttribute("id", "cai-webclient-custom");
                e.setAttribute("src", oPluginParameters.SRC);
                e.setAttribute("data-channel-id", oPluginParameters.CHANNEL_ID);
                e.setAttribute("data-token", oPluginParameters.TOKEN)
                document.body.appendChild(e)
            }

            var that = this;
            this._getRenderer().done(function () {
                var oRendererExtensions = sap.ushell.renderers.fiori2.RendererExtensions;
                var oBotonChat = new sap.ushell.ui.shell.ShellHeadItem("idBotonChatbot", {
                    showSeparator: true,
                    icon: oPluginParameters.ICON,
                    press: function(oEvent){
                        window.sap.cai.webclient.toggle();
                    }
                });
                oRendererExtensions.addHeaderEndItem(oBotonChat);
            });

            this.getModel().read("/ClienteSet", {
                success: function (oData) {

                    if (oData.results.length > 0) {
                        // declarar un metodo global que va a ser llamado por webChat, y le retornamos el segmento y rol del usuario obtenidos de SAP
                        window.webchatMethods = {
                            getMemory: (conversationId) => {
                                const memory = {
                                    Rol: oData.results[0].Rol,
                                    Segmento: oData.results[0].Segmento
                                }
                                return { memory, merge: true }
                            }
                        }
                    }
                }
            });

        },

        _getRenderer: function () {
            var e = this, t = new jQuery.Deferred, n;
            e._oShellContainer = jQuery.sap.getObject("sap.ushell.Container");
            if (!e._oShellContainer) {
                t.reject("Illegal state: shell container not available; this component must be executed in a unified shell runtime context.")
            } else {
                n = e._oShellContainer.getRenderer();
                if (n) {
                    t.resolve(n)
                } else {
                    e._onRendererCreated = function (e) {
                        n = e.getParameter("renderer");
                        if (n) {
                            t.resolve(n)
                        } else {
                            t.reject("Illegal state: shell renderer not available after recieving 'rendererLoaded' event.")
                        }
                    }
                        ;
                    e._oShellContainer.attachRendererCreatedEvent(e._onRendererCreated)
                }
            }
            return t.promise()
        }

    });
});
