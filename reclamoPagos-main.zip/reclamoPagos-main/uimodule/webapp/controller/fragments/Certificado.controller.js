sap.ui.define(["../BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "sap/m/MessageBox"],
function (BaseController, JSONModel, MessageToast, MessageBox) {
	"use strict";
	var oController;
	return BaseController.extend("profertil.ReclamoPagos.controller.Certificado", {

		onBeforeShow: function (parent, fragment, callback, data) {
			oController = this;
			this.parent = data.parent;
			this.fragment = fragment;
			this.callback = callback;
			this.data = data;

		//	this.fragment.attachBeforeOpen(this._onObjectMatched, this);

    },

   

    onClose: function () {
				//	this._clear();
				this.fragment.close();
			//	this.parent.Rsnum = null;
				if (this.callback) this.callback.call(this.parent);
			},


    onPressReclamo: function (oEvent) {
      //sap.m.MessageToast.show("Reclamo press");
      var sId = oEvent.getSource().getBindingContext().getProperty("Id");
      this.parent.navToReclamo(sId);

    },


	/*	_onObjectMatched: function (oEvent) {

			this.parent.getView().getModel().metadataLoaded().then(function () {
				var sObjectPath = this.parent.getView().getModel().createKey("ReservasSet", {
					Rsnum: this.parent.Rsnum
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},*/
/*
		_bindView: function (sObjectPath) {
			var oDataModel = this.parent.getModel();

			this.parent.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
							// while metadata is loaded.

						});

					}
				}
			});
		},

		_onBindingChange: function () {
			var oView = this.parent.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.parent.getRouter().getTargets().display("objectNotFound");
				return;
			}

		},*/
		/* =========================================================== */
		/* event handlers */
		/* =========================================================== */
			/*,
					_clear: function(){
						var input = this.fragmentById(this.parent, "__idUsuario");
						input.setValue("");
					}*/
	});
});