sap.ui.define(
  [
    "profertil/ReclamoPagos/controller/BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/library",
    "sap/ui/core/Fragment",
    "../model/formatter"
  ],
  function (Controller, JSONModel, MessageToast, MessageBox, Filter, FilterOperator, CoreLibrary, Fragment, formatter) {
    "use strict";
    var oController;
    return Controller.extend("profertil.ReclamoPagos.controller.Main", {
      onInit: function () {
        oController = this;

        this.setRepoUrl();

        this.initFragments();

        this.getModel().read('/InformexClienteSet', {
          success: function (result) {
          }
        });

        this._cbList = [];
        this._cbData = [
          [
            {
              key: "TRANS",
              id: "cuenta-destino-cb",
              label: "Cuenta Destino",
              valores: [
                {
                  key: "RIO",
                  value: "Rio",
                },
                {
                  key: "GAL",
                  value: "Galicia",
                },
                {
                  key: "NAC",
                  value: "Nacion",
                },
                {
                  key: "PRO",
                  value: "Provincia",
                },
                {
                  key: "CIT",
                  value: "Citi",
                },
                {
                  key: "CRE",
                  value: "Credicoop",
                },
                {
                  key: "MAC",
                  value: "Macro",
                },
                {
                  key: "OTR",
                  value: "Otro",
                },
              ],
            },
            {
              key: "DEPOS",
              id: "forma-deposito-cb",
              label: "Forma de Deposito",
              valores: [
                {
                  key: "REC",
                  value: "Recaudacion",
                },
                {
                  key: "CUE",
                  value: "Directo en cuenta",
                },
              ],
            },
            {
              key: "CHEQ",
              id: "clase-cb",
              label: "Clase",
              valores: [
                {
                  key: "CHQ",
                  value: "Cheque al dia",
                },
                {
                  key: "DIF",
                  value: "Diferido",
                },
              ],
            },
            {
              key: "CUPT",
              id: "banco-cb",
              label: "Banco Emisor",
              valores: [
                {
                  key: "RIO",
                  value: "Rio",
                },
                {
                  key: "GAL",
                  value: "Galicia",
                },
                {
                  key: "NAC",
                  value: "Nacion",
                },
                {
                  key: "PRO",
                  value: "Provincia",
                },
                {
                  key: "ICB",
                  value: "ICBC",
                },
                {
                  key: "PAT",
                  value: "Patagonia",
                },
                {
                  key: "MAC",
                  value: "Macro",
                },
                {
                  key: "SAN",
                  value: "Santa Fe",
                },
                {
                  key: "FRA",
                  value: "Frances",
                },
                {
                  key: "PAM",
                  value: "Pampa",
                },
                {
                  key: "OTR",
                  value: "Otro",
                },
              ],
            },
            {
              key: "RETNC",
              id: "tipo-cb",
              label: "Tipo",
              valores: [
                {
                  key: "IIBB",
                  value: "IIBB",
                },
                {
                  key: "IVA",
                  value: "IVA",
                },
                {
                  key: "SUSS",
                  value: "SUSS",
                },
                {
                  key: "GAN",
                  value: "Ganancias",
                },
                {
                  key: "OTR",
                  value: "Otro",
                },
              ],
            },
            {
              key: "FACC",
              id: "factura-text",
              label: "Nro. de Factura",
            },
            {
              key: "LIQC",
              id: "corredor-cb",
              label: "Corredor",
              valores: [
                {
                  key: "INTA",
                  value: "INTAGRO"
                },
                {
                  key: "ZENI",
                  value: "ZENI"
                },
                {
                  key: "GRAN",
                  value: "GRANAR"
                },
                {
                  key: "GRAS",
                  value: "GRASSI"
                },
                {
                  key: "ACA",
                  value: "ACA"
                },
                {
                  key: "FYO",
                  value: "FYO"
                },
                {
                  key: "MARO",
                  value: "MAROUN"
                },
                {
                  key: "DIAZ",
                  value: "DIAZ RIGANTI"
                },
                {
                  key: "OTRO",
                  value: "OTRO"
                },
              ],
            },
          ],
          [
            {
              key: "DEPOS",
              id: "clase-cb",
              label: "Clase",
              valores: [
                {
                  key: "EFC",
                  value: "Efectivo",
                },
                {
                  key: "CHQ",
                  value: "Cheque al dia",
                },
                {
                  key: "DIF",
                  value: "Diferido",
                },
              ],
            },
            {
              key: "CUPT",
              id: "tipo-cupon-cb",
              label: "Tipo",
              valores: [
                {
                  key: "CON",
                  value: "Convenio",
                },
                {
                  key: "NOC",
                  value: "No Convenio",
                },
              ],
            },
            {
              key: "IIBB",
              id: "jurissdiccion-cb",
              label: "Jurisdiccion",
              valores: [
                {
                  key: "BSAS",
                  value: "Buenos Aires",
                },
                {
                  key: "SANF",
                  value: "Santa Fe",
                },
                {
                  key: "ENTR",
                  value: "Entre Rios",
                },
                {
                  key: "CATM",
                  value: "Catamarca",
                },
                {
                  key: "TUCU",
                  value: "Tucuman",
                },
                {
                  key: "LPMP",
                  value: "La Pampa",
                },
                {
                  key: "OTR",
                  value: "Otro",
                },
              ],
            },
            {
              key: "RETNC",
              id: "jurissdiccion-cb",
              label: "Jurisdicción",
              valores: [
                {
                  key: "NAC",
                  value: "Nacional"
                },
              ],
            },
            {
              key: "LIQC",
              id: "contacto-text",
              label: "Nro de Contrato",
            }
          ],
        ];

        this.getView().setModel(
          new JSONModel({
            backButtonVisible: false,
            nextButtonVisible: true,
            nextButtonEnabled: true,
            backButtonEnabled: false,
            finishButtonVisible: false,
            maxDate: new Date()
          }),
          "view"
        );
        
        this._oWizard = this.byId("Wizard01");
      },

      onAfterRendering: function () {
        setTimeout(
          function () {
            this._oWizard = this.byId("Wizard01");
            this.handleButtonsVisibility();
          }.bind(this),
          50
        );
      },

      handleButtonsVisibility: function () {
        var oModel = this.getView().getModel("view");

        switch (this._oWizard.getProgress()) {
          case 1:
            oModel.setProperty("/nextButtonVisible", true);
            oModel.setProperty("/nextButtonEnabled", true);
            oModel.setProperty("/backButtonVisible", false);
            oModel.setProperty("/finishButtonVisible", false);
            break;
          case 2:
            oModel.setProperty("/backButtonVisible", true);
            oModel.setProperty("/nextButtonVisible", true);
            oModel.setProperty("/nextButtonEnabled", false);
            break;
          case 3:
            oModel.setProperty("/backButtonVisible", true);
            oModel.setProperty("/nextButtonVisible", false);
            oModel.setProperty("/finishButtonVisible", true);
            break;
          default:
            break;
        }
      },

      onNextButton: function () {
        if (this._oWizard.getProgressStep().getValidated()) {
          this._oWizard.nextStep();
        }

        this.handleButtonsVisibility();
      },

      _obtenerDatos: function () {

        var aReclamo = {
          Tipopago: this.byId("_cbTipo") ? this.byId("_cbTipo").getValue() : "",
          Cuentadestino: this.byId("cuenta-destino-cb") ? this.byId("cuenta-destino-cb").getValue() : "",
          Tipodeposito: this.byId("forma-deposito-cb") ? this.byId("forma-deposito-cb").getValue() : "",
          Clase: this.byId("clase-cb") ? this.byId("clase-cb").getValue() : "",
          Bancoemisor: this.byId("banco-cb") ? this.byId("banco-cb").getValue() : "",
          Tiporetencion: this.byId("tipo-cb") ? this.byId("tipo-cb").getValue() : "",
          Jurisdiccion: this.byId("jurissdiccion-cb") ? this.byId("jurissdiccion-cb").getValue() : "",
          Nrofactura: this.byId("factura-text") ? this.byId("factura-text").getValue() : "",
          Fecha: new Date(this.byId("_fecha").getDateValue()),
          Importe: this.byId("_importe").getValue(),
          Descripcion: this.byId("_descripcion").getValue(),
          Corredor: this.byId("corredor-cb") ? this.byId("corredor-cb").getValue() : "",
          Contacto: this.byId("contacto-text") ? this.byId("contacto-text").getValue() : "",
          //      Comprobante:
          Tipocupon: this.byId("tipo-cupon-cb") ? this.byId("tipo-cupon-cb").getValue() : "",
          Estado: "N"
        };
        //    console.log(aReclamo);
        return aReclamo;

      },

      wizardCompletedHandler: function () {

        var oModel = oController.getView().getModel();
        var oEntity = oController._obtenerDatos();
        this.getView().setBusy(true);
        oModel.setUseBatch(false);
        var that = this;
        oModel.create("/InformeSet", oEntity, {
          success: function (resultado) {
            oModel.setUseBatch(true);
            var id = resultado.Id,
              cliente = resultado.Nrocliente;

            //this.uploadFiles(cliente, id);
            //this.displayMessageOk();

            this.uploadFiles2(cliente, id);
            
          }.bind(this),
          error: function (error) {
            oModel.setUseBatch(true);
            that.getView().setBusy(false);
            MessageToast.show("Error: Algo salió mal");
            MessageBox.error("Verifique los datos");
            //oController.getView().setBusy(false);
          }
        });
      },

      onSelect: function () { },

      setRepoUrl: function () {
        this.getData("")
          .then(response => {
            var repos = Object.keys(response).filter(repo => response[repo].repositoryName == "INFORME_PAGOS");
            var root = repos[0] + "/root";
            var url = this.getDMSUrl("/SDM_API/browser/" + root);
            this._dmsUrl = url;
          });

      },


      uploadFiles2: function (client, claim) {
        var that = this;
        if (client !== "") {
          this.getClientFolder(client).then( function () {
            that.getClaimFolder(client, claim).then(function () {
              that.subirLosArchivos(client, claim);
            });
          }).catch( function () {
            console.warn("-->>using existing client folder...");
            that.getClaimFolder(client, claim).then(function () {
              that.subirLosArchivos(client, claim);
            });
          });

        } else {
          this.getClaimFolder(client, claim).then(function () {
            that.subirLosArchivos(client, claim);
          });

        }

      },

      subirLosArchivos: function (client, claim) {
        var aError = [];
        var aSuccess = [];
        var items = this.byId("UploadSet").getIncompleteItems();
        var sUrlDMS = this._dmsUrl;
        var that = this;
        
        var runRequest = function (fileIndex) {
          if (items.length == fileIndex) {
            console.warn("uploaded: " + aSuccess.length + "/" + aError.length);
            that.getView().setBusy(false);
            that.displayMessageOk2(claim, aSuccess.length);
            return;
          }

          var file = null;
          var filename = "";
          var dataObject = {};
          var data = null;
          var keys = null;
          var path = "/" + client + "/" + claim;

          file = items[fileIndex].getFileObject();
          filename = file.name;
          
          data = new FormData();
          dataObject = {
            "cmisaction": "createDocument",
            "propertyId[0]": "cmis:name",
            "propertyId[1]": "cmis:objectTypeId",
            "propertyValue[0]": filename,
            "propertyValue[1]": "cmis:document",
            "media": file,
          };

          keys = Object.keys(dataObject);

          for (var key of keys) {
            data.append(key, dataObject[key]);
          }

          $.ajax({
            url: sUrlDMS + path,
            type: "POST",
            data: data,
            contentType: false,
            processData: false,
            success: function () {
              aSuccess.push(filename);
            },
            error: function () {
              aError.push(filename);
            },
            complete: function () {
              runRequest(++fileIndex);
            }
          });

        };
        runRequest(0);

      },


      displayMessageOk2: function (claim, sCant) {
        var sMessage = "Informe " + claim + " enviado, con " + sCant + " adjuntos."
        MessageBox.success(sMessage, {
          actions: [MessageBox.Action.OK],
          emphasizedAction: MessageBox.Action.OK,
          onClose: function (sAction) {
            if (sAction == MessageBox.Action.OK) {
              var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
              if (oCrossAppNavigator) {
                oCrossAppNavigator.toExternal({
                  target: { semanticObject: "#" }
                });
              }
            }
          }
        });

      },

      displayMessageOk3: function (claim, sCant) {
        var sMessage = "Informe " + claim + " enviado, con " + sCant + " adjuntos."
        MessageBox.warning(sMessage, {
          actions: [MessageBox.Action.OK],
          emphasizedAction: MessageBox.Action.OK,
          onClose: function (sAction) {
            if (sAction == MessageBox.Action.OK) {
              var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
              if (oCrossAppNavigator) {
                oCrossAppNavigator.toExternal({
                  target: { semanticObject: "#" }
                });
              }
            }
          }
        });

      },


      displayMessageOk: function (claim) {
        var sMessage = "Informe " + claim + " enviado."
        MessageBox.success(sMessage, {
          actions: [MessageBox.Action.OK],
          emphasizedAction: MessageBox.Action.OK,
          onClose: function (sAction) {
            if (sAction == MessageBox.Action.OK) {
              var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
              if (oCrossAppNavigator) {
                oCrossAppNavigator.toExternal({
                  target: { semanticObject: "#" }
                });
              }
            }
          }
        });

      },

      
      uploadFiles: function (client, claim) {
        var file, filename;

        this.getClientFolder(client)
          .then(() => {
            return this.getClaimFolder(client, claim);
          })
          .catch(() => {
            // crea el folder igualmente sin cliente?
            return this.getClaimFolder(client, claim);
          })
          .then(() => {
            var uploadSet = this.byId("UploadSet");
            var items = this.byId("UploadSet").getIncompleteItems();

            var path = "/" + client + "/" + claim;

            for (var i = 0; i < items.length; i++) {
              file = items[i].getFileObject();
              filename = file.name;

              this.uploadSingleFile(file, filename, path);
            }
          });
      },

      getClientFolder: function (client) {
        return this.createFolder(client);
      },

      getClaimFolder: function (client, claim) {
        return this.createFolder(claim, "/" + client);
      },

      uploadSingleFile: function (file, filename, path) {
        var data = new FormData();
        var dataObject = {
          "cmisaction": "createDocument",
          "propertyId[0]": "cmis:name",
          "propertyId[1]": "cmis:objectTypeId",
          "propertyValue[0]": filename,
          "propertyValue[1]": "cmis:document",
          "media": file,
        };

        var keys = Object.keys(dataObject);

        for (var key of keys) {
          data.append(key, dataObject[key]);
        }

        $.ajax({
          url: this._dmsUrl + path,
          type: "POST",
          data: data,
          contentType: false,
          processData: false
        });

      },

      createFolder: function (foldername, path) {
        var data = new FormData();
        var dataObject = {
          "cmisaction": "createFolder",
          "propertyId[0]": "cmis:name",
          "propertyId[1]": "cmis:objectTypeId",
          "propertyValue[0]": foldername,
          "propertyValue[1]": "cmis:folder"
        };

        var keys = Object.keys(dataObject);

        for (var key of keys) {
          data.append(key, dataObject[key]);
        }

        return $.ajax({
          url: this._dmsUrl + (!path ? "" : path),
          type: "POST",
          data: data,
          contentType: false,
          processData: false
        });
      },

      getDMSUrl: function (sPath) {
        var sComponent = this.getOwnerComponent().getManifest()["sap.app"]["id"]
        return jQuery.sap.getModulePath(sComponent) + sPath;
      },

      getData: function (path) {
        var url = this.getDMSUrl("/SDM_API/browser");
        var fullUrl = path ? url + "/" + path : url;

        return $.get({
          url: fullUrl
        });
      },

      crearCombo: function (oEvent, num, pKey) {
        var oController = this;

        var key = oEvent.getSource().getSelectedKey(),
          itemsArr = this._cbData[num];

        if (!itemsArr) return;

        var objeto = itemsArr.filter((obj) => obj.key == key)[0];

        //var counter = 1;
        //var oldCb = this.byId("cb" + (num + counter));

        // while (oldCb) {
        //   oldCb.destroy();
        //   this.byId("lb" + (num + counter)).destroy();
        //   counter++;
        //   oldCb = this.byId("cb" + (num + counter));
        // }

        var counter = 0;
        var oldCb = this._cbList[num];

        while (oldCb) {
          oldCb.comboBox.destroy();
          oldCb.label.destroy();

          counter++;

          oldCb = this._cbList[num + counter];
        }

        this._cbList.splice(num, counter + 1);

        if (!objeto) objeto = itemsArr.filter((obj) => obj.key == pKey)[0];
        if (!objeto) return;

        if (objeto.valores) {
          var oModel = new JSONModel(objeto.valores);
          this.getView().setModel(oModel, "Valores" + num);

          var label = new sap.m.Label(
            oController.getView().createId("lb" + (num + 1)),
            {
              text: objeto.label,
              // labelFor: "cb" + (num + 1),
              labelFor: objeto.id
            }
          );

          var cb = new sap.m.ComboBox(
            // oController.getView().createId("cb" + (num + 1)),
            oController.getView().createId(objeto.id),
            {
              required: true,
              items: {
                path: "Valores" + num + ">/",
                template: new sap.ui.core.Item({
                  key: "{Valores" + num + ">key}",
                  text: "{Valores" + num + ">value}"
                }),
              },
            }
          );

          cb.attachSelectionChange((oEvent) =>
            oController.crearCombo(oEvent, num + 1, key)
          );

          this._cbList.push({ comboBox: cb, label: label });

          this.getView().byId("form1").addContent(label);
          this.getView().byId("form1").addContent(cb);
        } else {
          var label = new sap.m.Label(
            oController.getView().createId("lb" + (num + 1)),
            {
              text: objeto.label,
              //labelFor: "cb" + (num + 1),
              labelFor: objeto.id
            }
          );

          var input = new sap.m.Input(
            //oController.getView().createId("cb" + (num + 1)),
            oController.getView().createId(objeto.id),
            {
              required: true,
            }
          );

          this._cbList.push({ comboBox: input, label: label });

          this.getView().byId("form1").addContent(label);
          this.getView().byId("form1").addContent(input);
        }
      },

      onActivateStep1: function () {
        var oModel = this.getView().getModel("view");
        //     // sTexto = this.byId("_nfactura").getValue();

        //   this.handleButtonsVisibility();

        //   if (sTexto.length > 5) {
        this._oWizard.validateStep(this.byId("_wRegistro"));
        oModel.setProperty("/nextButtonEnabled", true);
        //   } else {
        //     this._oWizard.invalidateStep(this.byId("_wRegistro"));
        //     oModel.setProperty("/nextButtonEnabled", false);
        //   }
      },

      onActivateStep2: function (oEvent) {



        var oModel = this.getView().getModel("view"),
          sFecha = this.byId("_fecha").getValue(),
          sImporte = this.byId("_importe").getValue(),
          sDescripcion = (this.byId("_descripcion").getValue());

        this.handleButtonsVisibility();

        if ((!sFecha) || (sImporte.length < 3) || (sDescripcion.length < 4)) {
          this._oWizard.invalidateStep(this.byId("_wDetalle"));
          oModel.setProperty("/nextButtonVisible", false);
        } else {
          this._oWizard.validateStep(this.byId("_wDetalle"));
          oModel.setProperty("/nextButtonEnabled", true);
        }

        //var vFocus = this.getView().byId("_descripcion").focus();

        if (oEvent.getSource().sId.includes("descripcion")) {
          var ValueState = CoreLibrary.ValueState;

          var oTextArea = oEvent.getSource(),
            iValueLength = oTextArea.getValue().length,
            iMaxLength = oTextArea.getMaxLength(),
            sState = iValueLength > iMaxLength ? ValueState.Error : ValueState.None;
  
          oTextArea.setValueState(sState);          
        }

      },

      onCertificado: function (oEvent) {
        this.openFragment("Certificado", this.getModel(), true, null, {
          parent: this
        }, null);

      },

      onCertificado2: function (oEvent) {
        var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
        var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "recpagoscli",
                        action: "display"
                    }})) || "";
        oCrossAppNavigator.toExternal({
                target: {
                    shellHash: hash
                }
        });

      }



    });
  }
);
