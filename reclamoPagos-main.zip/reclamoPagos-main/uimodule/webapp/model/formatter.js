sap.ui.define([], function () {
  "use strict";
	return {

    highlightEstado: function (sEstado) {
			switch (sEstado) {
			case "N":
				return "Error";
			case "P":
				return "Warning";
			case "R":
				return "Success";
			default:
				return "None";
			}
    },

    toNumber: function (fValue) {
        fValue = parseFloat(fValue);
        return Intl.NumberFormat().format(fValue.toFixed(2));
    },

    nombreEstado: function (sStatus) {
			switch (sStatus) {
			case "P":
				return "Pendiente";
			case "N":
				return "No leído";
			case "R":
				return "Resuelto";
			default:
        break;
			}
    },

    nombreState: function (sStatus) {
			switch (sStatus) {
			case "P":
				return "Warning";
			case "N":
				return "Error";
			case "R":
				return "Success";
			default:
        break;
			}
    },
    
  };
});
