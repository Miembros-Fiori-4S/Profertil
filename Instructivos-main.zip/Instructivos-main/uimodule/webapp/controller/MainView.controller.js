sap.ui.define([
  "profertil/documentos/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/m/Link"
], function (Controller, JSONModel,Link) {
  "use strict";

  return Controller.extend("profertil.documentos.controller.MainView", {
    onInit: function () {
      this.getUserData()
      .then(response => {
        this._user = response.results[0];

        return this.getData("");
      })
      .then(response => {
        var repos = Object.keys(response).filter(repo => response[repo].repositoryName == "PROCEDIMIENTOS_E_INSTRUCTIVOS");

        var ramo = this.getRamo(this._user.Segmento);
        var rol = this.getRole(this._user.Rol);

        var root = repos[0] + "/root" + (ramo.length > 0 ? ("/" + ramo) : "") + (rol.length > 0 ? ("/" + rol) : ""); //idrepo/root/nroclient/reclamo
        
        var data = {
          rootPath: root,
          path: root,
          content: []
        };

        var jsonModel = new JSONModel(data);

        this.getView().setModel(jsonModel, "Content");

        return data.path;
      })
      .then(path => {
        this.updateContent(path);
      })
      .catch(error => {
        console.log(error);
      });
    },

    onItemPress: function(oEvent) {
      var path = this.getView().getModel("Content").getData().path;
      var selectedItem = oEvent.getSource().getSelectedItem().getBindingContext("Content").getObject();
      
      var { name, type }= selectedItem;

      var fullPath = path + "/" + name;

      if (type != "cmis:folder") return this.downloadFile(fullPath);
      
      this.updateContent(fullPath);
    },

    getDestinationUrl: function(sPath){
      var sComponent = this.getOwnerComponent().getManifest()["sap.app"]["id"]
      return jQuery.sap.getModulePath(sComponent) + sPath;
    },

    getData: function(path) { // "idrepo/root/nroclient/reclamo"
      var url =  this.getDestinationUrl("/SDM_API/browser"); // pathdetuapp/SDM_API/browser
      var fullUrl = path ? url + "/" + path : url; // pathdetuapp/SDM_API/browser + /nroclient/reclamo/

      return $.get({
        url: fullUrl
      });
    },

    getRamo: function(ramo) {
      switch (ramo.toLowerCase()) {
        case "p001":
          return "Industriales";
        case "z001":
          return "Cuentas Nacionales";
        case "z002":
          return "Dealers";
        default:
          return "";
      }
    },

    downloadFile: function(path) {
      var url =  this.getDestinationUrl("/SDM_API/browser");

      window.open(url + "/" + path);
    },

    updateModel: function(data) {
      var oData = this.getView().getModel("Content").getData();

      oData.path = data.path;
      oData.content = data.content;
    },

    updateContent: function(path) {
      this.getView().setBusy(true);
      this.getData(path)
        .then(data => {
          return this.createObject({
            path,
            content: data.objects
          });
        })
        .then(data => {
          this.updateModel(data);
        })
        .then(() => {
          this.bindList();
          this.generateBreadcrumbs();

          this.getView().setBusy(false);
        })
        .catch(error => {
          console.log(error);
          this.getView().setBusy(false);
        });
    },

    createObject: function({ path, content }) {
      var oData = content.map(item => {
        return ({
          name: item.object.properties["cmis:name"].value,
          type: item.object.properties["cmis:objectTypeId"].value
        });
      });

      return ({
        path,
        content: oData
      });
    },

    generateBreadcrumbs: function() {
      var bcContainer = this.byId("breadcrumbs");
      var pathArr = this.getPathArr();

      bcContainer.destroyLinks();

      pathArr.forEach(item => {
        bcContainer.addLink(new Link({
          text: item,
          press: this.onPressLink.bind(this)
        }));
      });
    },

    onPressLink: function(oEvent) {
      oEvent.preventDefault();

      var linksArr = oEvent.getSource().getParent().getLinks();
      var selectedId = oEvent.getSource().getId();
      var { rootPath } = this.getView().getModel("Content").getData();

      var selectedIndex = 0;

      for (var i = 0; i < linksArr.length; i++) {
        if (linksArr[i].getId() == selectedId) selectedIndex = i;
      }

      var path = this.getPathArr().slice(1, selectedIndex + 1).join("/");
      var fullPath = rootPath + "/" + path;

      this.updateContent(fullPath);
    },

    getPathArr: function() {
      var oData = this.getView().getModel("Content").getData();

      var { path, rootPath } = oData;

      var bcPath = path.replace(rootPath, "Documentos");

      return bcPath.split("/").filter(item => item.length > 0);
    },

    bindList: function () {
      var oTable = this.byId("DocumentList");

      oTable.unbindItems();
      oTable.bindItems("Content>/content",
        new sap.m.StandardListItem({
          title: "{Content>name}",
          info: "{Content>type}",
          icon: {
            parts: [
              {path: 'Content>name'},
              {path: 'Content>type'}
            ],
            formatter: this.iconFormatter
          }
        })
      );
    },

    iconFormatter: function(name, type) {
      if (type == "cmis:folder") {
        return "sap-icon://folder-blank";
      } else {
        var extIndex = name.lastIndexOf(".");
        var ext = name.substr(extIndex);

        switch (ext) {
          case ".doc":
          case ".docx":
            return "sap-icon://doc-attachment";
          case ".pdf":
            return "sap-icon://pdf-attachment";
          case ".jpg":
          case ".png":
          case ".jpeg":
            return "sap-icon://background";
          default:
            return "sap-icon://document";
        };
      }
    },

    getUserData: function() {
      var oModel = this.getView().getModel();

      return new Promise((resolve, reject) => {
        oModel.read("/ClienteSet", {
          success: (data) => resolve(data),
          error: (error) => reject(error)
        });
      });
    },

    getRole: function(role) {
      switch(role) {
        case "2":
          return "Comercial";
        case "3":
          return "Creditos";
        case "4":
          return "Logistico";
        default:
          return "";
      }
    }
  });
});
