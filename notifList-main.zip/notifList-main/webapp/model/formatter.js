sap.ui.define(
    [],
    function () {
        "use strict";
    
        return {

            formatUnread: function (sValue) {
                if (sValue === 'S') {
                    return false;
                }
                return true;
            },

            formatLeidoIcon: function (sValue) {
                if (sValue === "S") {
                    return "sap-icon://employee-approvals";
                }
                return "sap-icon://negative";
            },

            formatLeidoIconColor: function (sValue) {
                if (sValue === "S") {
                    return "green";
                }
                return "red";
            },

            formatLeido: function (sValue) {
                if (sValue === "S") {
                    return "Si";
                }
                return "No";
            },

            formatSuspendida: function (sValue) {
                if (sValue === "S") {
                    return true;
                }
                return false;
            },

            formatClosebtn: function (sValue) {
                if (sValue === "S") {
                    return true;
                }
                return false;
            },

            formatCloseBtnText: function (sValue) {
                if (sValue === "S") {
                    return "Si";
                }
                return "No";
            },

            highlightColumn: function (sValue, dDesde, dHasta) {
                var dToday = new Date();
                
                // validez
                if (dDesde <= dToday && dToday <= dHasta) {

                } else {
                    return "Error";
                }

                // suspendida
                if (sValue === "S") {
                    return "Error";
                }
                return "None";
            },

            formatPrioridadState: function (sValue) {
                if (sValue === "1") {
                    return "Error";
                }
                if (sValue === "2") {
                    return "Warning";
                }
                if (sValue === "3") {
                    return "Success";
                }
                return "None";
            },

            formatPrioridadIcon: function (sValue) {
                if (sValue === "1") {
                    return "sap-icon://message-error";
                }
                if (sValue === "2") {
                    return "sap-icon://message-warning";
                }
                if (sValue === "3") {
                    return "sap-icon://message-success";
                }
                return "sap-icon://rhombus-milestone";
            },

            formatPrioridad: function (sValue) {
                
                if (sValue === "1") {
                    return "High";
                } 
                if (sValue === "2") {
                    return "Medium";
                }
                if (sValue === "3") {
                    return "Low";
                }
                return "None";

            }

        }

    }

);