sap.ui.define([
	"profertil/notiflist/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
