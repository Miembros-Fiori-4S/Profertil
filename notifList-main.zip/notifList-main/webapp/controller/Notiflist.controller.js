sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, formatter, MessageBox) {
        "use strict";
        
		return Controller.extend("profertil.notiflist.controller.Notiflist", {

            formatter: formatter,

			onInit: function () {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.getRoute("RouteList").attachPatternMatched(this._onObjectMatched, this);

            },

            onBeforeRebindTable: function (oEvent) {
                //var mBindingParams = oEvent.getParameter("bindingParams");
                //mBindingParams.parameters["expand"] = "ToCliente"; 
            },

            onCreateNotification: function (oEvent) {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteCrear", {});
            },

            onPressNotificacion: function (oEvent) {
                
            },

            onKunnrClicked: function (oEvent) {
                this.onPressDisplayAll(oEvent);

            },

            onPressDisplay: function (oEvent) {
                var oItem = oEvent.getSource().getParent();
                var sKunnr = oItem.getBindingContext().getProperty("kunnr");
                var sPos = oItem.getBindingContext().getProperty("posicion");
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteVisualizar", {
                    kunnr: sKunnr,
                    posicion: sPos
                });

            },

            onPressCopy: function (oEvent) {
                var oItem = oEvent.getSource().getParent();
                var sKunnr = oItem.getBindingContext().getProperty("kunnr");
                var sPos = oItem.getBindingContext().getProperty("posicion");
                var sTipo = oItem.getBindingContext().getProperty("tipo");
                if (sTipo === "6" || sTipo === "8") {
                    sap.m.MessageToast.show("Este tipo de Notificacion no se puede reutilizar");
                    return;
                }
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteCopiar", {
                    kunnr: sKunnr,
                    posicion: sPos
                });

            },

            onPressDetail: function (oEvent) {
                var oItem = oEvent.getSource();
                var oBindingContext = oItem.getBindingContext();
                var sKunnr = oBindingContext.getProperty("kunnr");
                var sPos = oBindingContext.getProperty("posicion");
                var sTipo = oBindingContext.getProperty("tipo");
                if (sTipo === "6" || sTipo === "8") {
                    sap.m.MessageToast.show("Este tipo de Notificacion no se puede modificar");
                    return;
                }
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteModificar", {
                    kunnr: sKunnr,
                    posicion: sPos
                });
            },

            onPressDisplayAll: function (oEvent) {
                var oItem = oEvent.getSource().getParent();
                var sKunnr = oItem.getBindingContext().getProperty("kunnr");
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteNotifList", {
                    kunnr: sKunnr
                });

            },

            onChangeSuspendida: function (oEvent) {
                var oModel = this.getView().getModel();
                oModel.setUseBatch(false);
                var oSwitch = oEvent.getSource();
                var bState = oSwitch.getState();
                var sSuspendida = "";
                if (bState) {
                    sSuspendida = 'S';
                } else {
                    sSuspendida = 'N';
                }
                var oItem = oEvent.getSource().getParent();
                var sKunnr = oItem.getBindingContext().getProperty("kunnr");
                var sPos = oItem.getBindingContext().getProperty("posicion");
                var oData = {};
                oData.suspendida = sSuspendida;
                var sPath = "/NotificacionSet(kunnr='" + sKunnr + "',posicion='" + sPos + "')";
                oModel.update(sPath, oData, {
                    success: function (oData, oResponse) {
                        sap.m.MessageToast.show("Cambios Guardados");
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show("Surgieron errores, intentelo mas tarde");
                    }
                });

            },

            onDeleteNotificacion: function (oEvent) {
                var sPath = oEvent.getParameter("listItem").getBindingContext().getPath();
                var sMessage = "Desea Borrar el mensaje seleccionado?";
                var that = this;
                MessageBox.warning(sMessage, {
                    actions: [MessageBox.Action.OK, MessageBox.Action.CANCEL],
                    emphasizedAction: MessageBox.Action.CANCEL,
                    initialFocus: MessageBox.Action.CANCEL,
                    onClose: function (sAction) {
                        if (sAction === "OK") {
                            that.deleteNotificacion(sPath);
                        } else {
                            sap.m.MessageToast.show("Accion Cancelada");
                        }
                        
                    }
                });

            },

            deleteNotificacion: function (sPath) {  
                var oModel = this.getView().getModel();
                oModel.setUseBatch(false);             
                oModel.remove(sPath, {
                    success: function (oData, oResponse) {
                        sap.m.MessageToast.show("Notificacion Eliminada");
                    },
                    error: function (oError) {
                        sap.m.MessageToast.show("Surgieron errores, intentelo mas tarde");

                    }
                });

            },

            _onObjectMatched: function (oEvent) {
                this.getView().getModel().setUseBatch(true);
            }
            


		});  // function controller
	});