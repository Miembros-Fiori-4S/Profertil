sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment",
    "sap/m/Token",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/core/routing/History",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, Filter, FilterOperator, Fragment, Token, JSONModel, formatter, History, MessageBox) {
		"use strict";

		return Controller.extend("profertil.notiflist.controller.CopiarNotificacion", {

            formatter: formatter,

            onInit: function () {
                this.createIconModel();
                this.createViewModel();
                this.byId("fdesdeID").setMinDate(new Date());
                this.byId("fhastaID").setMinDate(new Date());
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.getRoute("RouteCopiar").attachPatternMatched(this._onObjectMatched, this);

            },

            createViewModel: function () {
                var oModel = new JSONModel({
                    editlink: true,
                    editlinkapp: false,
                    editlinkrepo: false,
                });
                this.getView().setModel(oModel, "viewModel");

            },

            createDestinosModel: function () {
                var oModel = new JSONModel({
                    aBrsch: [],
                    aBzirk: [],
                    aRol: [],
                    aKunnr: []
                });
                this.getView().setModel(oModel, "destinosModel");

            },

            createDataModel: function (sKunnr, sPos) {               
                var that = this;                
                this._readNotificacion(sKunnr, sPos).then(function (oData) {
                    var oModel = new JSONModel({
                        "brsch": "",
                        "lzone": "",
                        "clase": "",
                        "kunnr": "",
                        "usermail": "",
                        "titulo": oData.titulo,
                        "descripcion": oData.descripcion,
                        "prioridad": oData.prioridad, 
                        "autor": oData.autor,
                        "imagen": oData.imagen,
                        "colorimg": oData.colorimg,
                        "suspendida": oData.suspendida,
                        "fdesde": null,
                        "fhasta": null,
                        "tipo": oData.tipo,
                        "closebtn": oData.closebtn,
                        "link": oData.link,
                        "linkapp": oData.linkapp,
                        "linkrepo": oData.linkrepo
                    });
                    oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
                    that.getView().setModel(oModel, "dataModel");
                    if (oData.link) {
                        that.byId("rburlID").setSelected(true);
                        that.byId("rbappID").setSelected(false);
                        that.byId("rbrepID").setSelected(false);
                        // no se modifican
                        that.getView().getModel("viewModel").setProperty("/editlink", false);
                        that.getView().getModel("viewModel").setProperty("/editlinkapp", false);
                        that.getView().getModel("viewModel").setProperty("/editlinkrepo", false);
                    } else if (oData.linkapp){
                        that.byId("rburlID").setSelected(false);
                        that.byId("rbappID").setSelected(true);
                        that.byId("rbrepID").setSelected(false);
                        // no se modifican
                        that.getView().getModel("viewModel").setProperty("/editlink", false);
                        that.getView().getModel("viewModel").setProperty("/editlinkapp", false);
                        that.getView().getModel("viewModel").setProperty("/editlinkrepo", false);
                    } else if (oData.linkrepo) {
                        that.byId("rburlID").setSelected(false);
                        that.byId("rbappID").setSelected(false);
                        that.byId("rbrepID").setSelected(true);
                        // no se modifican
                        that.getView().getModel("viewModel").setProperty("/editlink", false);
                        that.getView().getModel("viewModel").setProperty("/editlinkapp", false);
                        that.getView().getModel("viewModel").setProperty("/editlinkrepo", false);
                    }

                });


            },

            createIconModel: function () {
                var aData = [];
                var aData_aux = [];
                aData = sap.ui.core.IconPool.getIconNames();
                for (var i=0; i < aData.length; i++) {
                    var oData = {};
                    oData.imagen = "sap-icon://" + aData[i];
                    oData.descripcion = aData[i];
                    aData_aux.push(oData);   
                }
                this.getView().setModel(new JSONModel(aData_aux), "iconModel2");

            },

            saveFilter: function (aSelectedItems, sPath, sProperty) {                
                var aFilter = [];
                var oModel = this.getView().getModel("destinosModel");
                for (var i = 0; i < aSelectedItems.length; i++) {
                    var sKey = aSelectedItems[i].getKey();
                    aFilter.push( new Filter({
                        path: sPath,
                        operator: FilterOperator.EQ,
                        value1: sKey
                    }));

                }
                oModel.setProperty(sProperty, aFilter);

            },

            saveFilterKunnr: function (aSelectedItems, sPath, sProperty) {
                var aFilter = [];
                var oModel = this.getView().getModel("destinosModel");
                for (var i = 0; i < aSelectedItems.length; i++) {
                    var sKey = aSelectedItems[i].getKey();
                    aFilter.push( new Filter({
                        path: sPath,
                        operator: FilterOperator.EQ,
                        value1: sKey
                    }));

                }
                oModel.setProperty(sProperty, aFilter);
                return aFilter;

            },

            /**
             * Events
             * @param {*} oEvent 
             */
            onTokenUpdate: function (oEvent) {
            },

            onSelectLink: function (oEvent) {  // radiobutton
                var iSelectedIndex = oEvent.getParameter("selectedIndex");
                
                if (iSelectedIndex === 0) {
                    this.getView().getModel("dataModel").setProperty("/linkapp", "");
                    this.getView().getModel("dataModel").setProperty("/linkrepo", "");
                    this.getView().getModel("viewModel").setProperty("/editlink", true);
                    this.getView().getModel("viewModel").setProperty("/editlinkapp", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkrepo", false);
                }
                
                if (iSelectedIndex === 1) {
                    this.getView().getModel("dataModel").setProperty("/link", "");
                    this.getView().getModel("dataModel").setProperty("/linkrepo", "");
                    this.getView().getModel("viewModel").setProperty("/editlink", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkapp", true);
                    this.getView().getModel("viewModel").setProperty("/editlinkrepo", false);
                }
                
                if (iSelectedIndex === 2) {
                    this.getView().getModel("dataModel").setProperty("/link", "");
                    this.getView().getModel("dataModel").setProperty("/linkapp", "");
                    this.getView().getModel("viewModel").setProperty("/editlink", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkapp", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkrepo", true);
                }

            },

            onSelectionFinishBrsch: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");
                this.saveFilter(selectedItems, "brsch", "/aBrsch");
            },

            onSelectionFinishZone: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");
                this.saveFilter(selectedItems, "bzirk", "/aBzirk");
            },

            onSelectionFinishClase: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");
                this.saveFilter(selectedItems, "crole", "/aRol");
            },

            onChangePrioridad: function (oEvent) {               
                var sKey = oEvent.getParameter("selectedItem").getProperty("key");
                this.getView().getModel("dataModel").setProperty("/prioridad", sKey);
            },

            onChangeClosebtn: function (oEvent) {
                var bValue = oEvent.getParameter("state");              
                var sClosebtn = (bValue ? "S" : "N");
                this.getView().getModel("dataModel").setProperty("/closebtn", sClosebtn);
            },

            onChangeSuspendida: function (oEvent) {                
                var bValue = oEvent.getParameter("state");              
                var sSuspendida = (bValue ? "S" : "N");
                this.getView().getModel("dataModel").setProperty("/suspendida", sSuspendida);
            },

            onChangeTipo: function (oEvent) {
                var sKey = oEvent.getParameter("selectedItem").getProperty("key");
                this.getView().getModel("dataModel").setProperty("/tipo", sKey);
            },

            onChangeColor: function (oEvent) {
                var sKey = oEvent.getParameter("selectedItem").getProperty("key");
                this.getView().getModel("dataModel").setProperty("/colorimg", sKey);
            },

            onChangeFdesde: function (oEvent) {
            },

            onPressVerReceptores: function (oEvent) {
                this.handleValueHelpR(oEvent);
            },


            // arma el filtro de los receptores antes de grabar
            armarFiltroDeReceptores: function () {
                var aFilters = [];
                var oModel = this.getView().getModel("destinosModel");
                
                var aBrsch = oModel.getProperty("/aBrsch");
                var aBzirk = oModel.getProperty("/aBzirk");
                var aRol = oModel.getProperty("/aRol");

                //tokens del multiinput
                var oMultiInput = this.byId("kunnrIDM");
                var oTokens = oMultiInput.getTokens();
                var aKunnr = this.saveFilterKunnr(oTokens, "kunnr", "/aKunnr");

                if (aBrsch.length) {
                    aFilters.push( 
                        new Filter({filters: aBrsch}) 
                    );
                }
                if (aBzirk.length) {
                    aFilters.push( 
                        new Filter({filters: aBzirk}) 
                    );
                }
                if (aRol.length) {
                    aFilters.push( 
                        new Filter({filters: aRol}) 
                    );
                }
                if (aKunnr.length) {
                    aFilters.push( 
                        new Filter({filters: aKunnr}) 
                    );
                }
                return aFilters;

            },

            validarDatos: function (oData) {
                if (!oData.titulo) {
                    this.byId("tituloID").setValueState("Error");
                    this.byId("tituloID").setValueStateText("Es un campo obligatorio");
                    return false;
                } else {
                    this.byId("tituloID").setValueState("None");
                    this.byId("tituloID").setValueStateText("");
                }
                return true;

            },

            /**
             * 
             * @param {*} oData 
             */
            crearNotificacion: function (oData) {
                var oModel = this.getView().getModel();
                return new Promise(function (resolve, reject) {
                    var sPath = "/NotificacionSet";
                    oModel.create(sPath, oData, {
                        success: function (oData, oResponse) {
                            resolve();
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });

                });
                
            },

            leerReceptores: function (aFilters) {
                var oModel = this.getView().getModel();
                return new Promise(function (resolve, reject) {
                    var sPath = "/VH_ReceptorSet";
                    oModel.read(sPath, {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }, 
                        filters: aFilters
                    });

                });

            },


            /**
             * 
             * @param {*} oEvent 
             */

            // Receptores
            handleValueHelpR: function (oEvent) {
				var oView = this.getView();
                // create value help dialog
                if (!this._pValueHelpDialogR) {
                    this._pValueHelpDialogR = Fragment.load({
                        id: oView.getId(),
                        name: "profertil.notiflist.view.ValueHelpReceptor",
                        controller: this
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }

                var that = this;
                this._pValueHelpDialogR.then(function (oValueHelpDialog) {
                    // create a filter for the binding
                    var aFilters = that.armarFiltroDeReceptores();
                    oValueHelpDialog.getBinding("items").filter(aFilters);
                    oValueHelpDialog.open();

                });

            },  

            _handleValueHelpSearchR: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter("name1", FilterOperator.Contains, sValue);
                oEvent.getSource().getBinding("items").filter([oFilter]);

            }, 

            _handleValueHelpCloseR: function (oEvent) {

            },

            // kunnr
            handleValueHelp: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue();
                oEvent.getSource().setValue("");
				var oView = this.getView();

                // create value help dialog
                if (!this._pValueHelpDialog) {
                    this._pValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "profertil.notiflist.view.ValueHelpKunnr",
                        controller: this
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }

                var that = this;
                this._pValueHelpDialog.then(function (oValueHelpDialog) {
                    // create a filter for the binding
                    var aFilters = [];
                    var oModel = that.getView().getModel("destinosModel");
                    var aBrsch = oModel.getProperty("/aBrsch");
                    var aBzirk = oModel.getProperty("/aBzirk");
                    var aRol = oModel.getProperty("/aRol");

                    var aFilters = [];

                    if (aBrsch.length) {
                        aFilters.push( 
                            new Filter({filters: aBrsch}) 
                        );
                    }
                    if (aBzirk.length) {
                        aFilters.push( 
                            new Filter({filters: aBzirk}) 
                        );
                    }
                    if (aRol.length) {
                        aFilters.push( 
                            new Filter({filters: aRol}) 
                        );
                    }

                    oValueHelpDialog.getBinding("items").filter(aFilters);
                    // open value help dialog filtered by the input value
                    oValueHelpDialog.open(sInputValue);

                });

            },  

            _handleValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");               
                var oFilter = new Filter(
                    "name1",
                    FilterOperator.Contains,
                    sValue
                );             
                oEvent.getSource().getBinding("items").filter([oFilter]);

            }, 

            _handleValueHelpClose: function (oEvent) {
                var aSelectedItems = oEvent.getParameter("selectedItems");
                var oMultiInput = this.byId("kunnrIDM");
                var sText = [];
                if (aSelectedItems && aSelectedItems.length > 0) {
                    aSelectedItems.forEach(function (oItem) {
                        sText = oItem.getTitle().split("-");
                        oMultiInput.addToken(new Token({
                            text: sText[0],
                            key: oItem.getDescription()
                        }));

                    });
                    
                }
                
                if (oMultiInput.getTokens().length) {
                    oMultiInput.setValueState("None");
                    oMultiInput.setValueStateText("");
                }

            },  
                
            // imagen (icono)
            handleValueHelp2: function (oEvent) {
                var oView = this.getView();                
                // create value help dialog
                if (!this._pValueHelpDialog2) {
                    this._pValueHelpDialog2 = Fragment.load({
                        id: oView.getId(),
                        name: "profertil.notiflist.view.ValueHelpIcon",
                        controller: this
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }

                // open value help dialog
                this._pValueHelpDialog2.then(function(oValueHelpDialog){
                    oValueHelpDialog.open();
                });

            },  

            _handleValueHelpSearch2: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter(
                    "descripcion",
                    FilterOperator.Contains, sValue
                );
                oEvent.getSource().getBinding("items").filter([oFilter]);

            },

           _handleValueHelpClose2: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                if (oSelectedItem) {
                    var iconInput = this.byId("imagenID");
                    iconInput.setValue(oSelectedItem.getTitle());

                    var sKey = oSelectedItem.getIcon();
                    this.getView().getModel("dataModel").setProperty("/imagen", sKey);

                }
                oEvent.getSource().getBinding("items").filter([]);

            },


            /**
             * Boton Grabar y Cancelar
             * @param {*} oEvent 
             */
            onSubmitChanges: function (sChangeSetId) {
                var oModel = this.getView().getModel();
                oModel.setUseBatch(true);
                this.getView().setBusy(true);
                var that = this;
                oModel.submitChanges({
                    changeSetId: sChangeSetId,
                    success: function () {
                        that.getView().setBusy(false);
                        sap.m.MessageToast.show("Notificaciones Creadas");
                        that.onNavBack();
                        
                    },
                    error: function () {
                        that.getView().setBusy(false);
                        sap.m.MessageToast.show("Error creando las Notificaciones, intente mas tarde");
                    }
                });
                
            },

            createEntries2: function (aReceptores, oFormData) {               
                var oModel = this.getView().getModel();
                oModel.setUseBatch(false);
                var sPath = "/NotificacionSet";                
                var sPos = "";
                var oNewData = null; 
                var dFdesde = this.byId("fdesdeID").getProperty("dateValue");
                var dFhasta = this.byId("fhastaID").getProperty("dateValue");

                for (var i=0; i < aReceptores.length; i++) {
                    oNewData = {};
                    oNewData = Object.assign({}, oFormData);
                    sPos = (i+1).toString();
                    oNewData.kunnr = aReceptores[i].kunnr;
                    oNewData.posicion = sPos;
                    oNewData.clase = aReceptores[i].crole;
                    oNewData.brsch = aReceptores[i].brsch;
                    oNewData.bzirk = aReceptores[i].bzirk;
                    oNewData.usermail = aReceptores[i].usbtp;
                    oNewData.fdesde = dFdesde;
                    oNewData.fhasta = dFhasta;
                    oModel.create(sPath, oNewData);
                }
                sap.m.MessageToast.show("Notificaciones Creadas");
                this.onNavBack();
             
            },

            confirmarGrabar: function (aReceptores, oFormData) {
                var iLength = aReceptores.length; 
                var sMessage = "Se generaran " + iLength.toString() + " notificaciones";
                var that = this;
                MessageBox.warning(sMessage, {
                    actions: ["Generar Notificaciones", "Cancelar"],
                    onClose: function (sAction) {
                        if (sAction === "Cancelar") {
                            sap.m.MessageToast.show("Accion Cancelada");
                        } else {
                            that.createEntries2(aReceptores, oFormData); //loop + batch false
                        }
                    }
                });

            },

            onGrabar: function (oEvent) {
                var oModel = this.getView().getModel("dataModel");
                var oFormData = oModel.getData();
                var aFilters = this.armarFiltroDeReceptores();

                var bDatosOK = this.validarDatos(oFormData);
                if (!bDatosOK) {
                    return;
                }

                var that = this;
                this.leerReceptores(aFilters).then(function (oData) {
                    if (oData.results.length) {
                        that.confirmarGrabar(oData.results, oFormData);
                    } else {
                        sap.m.MessageToast.show("Valide los receptores del mensaje");
                    }
                    
                });

            },

            onCancelar: function (oEvent) {
                this.onNavBack();
            },

            setBatchMode: function (bValue) {
                this.getView().getModel().setUseBatch(bValue);
            },

            onNavBack: function () {
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();

                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteList", true);
                }
            },

            _readNotificacion: function (sKunnr, sPos) {
                var oModel = this.getView().getModel();
                var sPath = "/NotificacionSet(kunnr='" + sKunnr + "',posicion='" + sPos + "')";
                var that = this;
                return new Promise(function (resolve, reject){
                    oModel.read(sPath, {
                        success: function (oData) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    })
                });
            },

            _onObjectMatched: function (oEvent) {
                // get route parameters
                var sKunnr = oEvent.getParameter("arguments").kunnr;
                var sPos = oEvent.getParameter("arguments").posicion;                
                this.createDataModel(sKunnr, sPos);
                this.createDestinosModel();
                this.byId("brschID").setSelectedKeys([]);
                this.byId("bzirkID").setSelectedKeys([]);
                this.byId("croleID").setSelectedKeys([]);
                this.byId("kunnrIDM").setTokens([]);
                this.setBatchMode(true);
                
            }


		});  // function controller
	});