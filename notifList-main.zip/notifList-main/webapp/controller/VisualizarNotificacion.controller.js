sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "sap/m/MessageBox",
    "sap/ui/core/routing/History"
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function (Controller, formatter, MessageBox, History) {
    "use strict";
    
    return Controller.extend("profertil.notiflist.controller.VisualizarNotificacion", {

        formatter: formatter,

        onInit: function () {

            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("RouteVisualizar").attachPatternMatched(this._onObjectMatched, this);

        },


        onCancelar: function (oEvent) {
            this.onNavBack();
        },

        onNavBack: function () {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteList", true);
            }
        },

        _onObjectMatched: function (oEvent) {
            
            var oModel = this.getView().getModel();
            var sKunnr = oEvent.getParameter("arguments").kunnr;
            var sPos = oEvent.getParameter("arguments").posicion;
            var sPath = oModel.createKey("/NotificacionSet", {
                kunnr: sKunnr,
                posicion: sPos
            });

            this.getView().bindElement({
                path: sPath,
                parameters: { $expand: 'ToCliente' }
			});

        }

    });
});