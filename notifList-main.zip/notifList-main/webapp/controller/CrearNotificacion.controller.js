sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "sap/ui/core/Fragment",
    "sap/m/Token",
    "sap/ui/model/json/JSONModel",
    "../model/formatter",
    "sap/ui/core/routing/History",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, Filter, FilterOperator, Fragment, Token, JSONModel, formatter, History, MessageBox) {
		"use strict";

		return Controller.extend("profertil.notiflist.controller.CrearNotificacion", {

            formatter: formatter,

            onInit: function () {
                this.createIconModel();
                this.createTargetModel();
                this.createViewModel();
                this.byId("fdesdeID").setMinDate(new Date());
                this.byId("fhastaID").setMinDate(new Date());
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			    oRouter.getRoute("RouteCrear").attachPatternMatched(this._onObjectMatched, this);

            },

            createTargetModel: function () {
                var aModel = [];
                var oObject = null;
                var aObjects = [];
                var aParams = [];
                var that = this;
                try {
                    var oCrossAppNav = sap.ushell.Container.getService("CrossApplicationNavigation");
                    oCrossAppNav.getDistinctSemanticObjects().then(function (aSemantics) {
                        for(var i=0; i < aSemantics.length; i++) {
                            oObject = {};
                            aObjects = [];
                            oObject = { "semanticObject": aSemantics[i] };
                            aObjects[0] = oObject;
                            aParams.push(aObjects);
                        }
                        oCrossAppNav.getLinks(aParams).then(function (aLinks) {
                            for(var z=0; z < aLinks.length; z++) {
                                for(var x=0; x < aLinks[z].length; x++){
                                    for(var y=0; y < aLinks[z][x].length; y++) {
                                        oObject = {};
                                        oObject.text = aLinks[z][x][y].text;
                                        oObject.intent = aLinks[z][x][y].intent.split("#")[1].split("?")[0];
                                        aModel.push(oObject);
                                    }
                                }
                            }
                            that.getView().setModel(new JSONModel(aModel), "targetModel");
                        });

                    });
                
                } catch (oError) {
                    console.log("No shell conatiner, this is test mode");
                    //console.log(oError);
                }

            },

            createViewModel: function () {
                var oModel = new JSONModel({
                    editlink: true,
                    editlinkapp: false,
                    editlinkrepo: false,
                });
                this.getView().setModel(oModel, "viewModel");

            },


            createDestinosModel: function () {
                var oModel = new JSONModel({
                    aBrsch: [],
                    aBzirk: [],
                    aRol: [],
                    aKunnr: []
                });
                this.getView().setModel(oModel, "destinosModel");
            },


            createDataModel: function () {
                var oModel = new JSONModel({
                    "kunnr": "",
                    "clase": "",
                    "usermail": "",
                    "titulo": "",
                    "descripcion": "",
                    "prioridad": "3", 
                    "autor": "",
                    "imagen": "sap-icon://group",
                    "colorimg": "Accent5",
                    "suspendida": "N",
                    "fdesde": null,
                    "fhasta": null,
                    "tipo": "5",
                    "lzone": "",
                    "brsch": "",
                    "closebtn": "S",
                    "link": "",
                    "linkapp": "",
                    "linkrepo": "",
                });
                oModel.setDefaultBindingMode(sap.ui.model.BindingMode.TwoWay);
                this.getView().setModel(oModel, "dataModel");

                this.byId("fdesdeID").setValue("");
                this.byId("fhastaID").setValue("");

            },


            createIconModel: function () {
                var aData = [];
                var aData_aux = [];
                aData = sap.ui.core.IconPool.getIconNames();
                for (var i=0; i < aData.length; i++) {
                    var oData = {};
                    oData.imagen = "sap-icon://" + aData[i];
                    oData.descripcion = aData[i];
                    aData_aux.push(oData);   
                }
                this.getView().setModel(new JSONModel(aData_aux), "iconModel2");

            },


            saveFilter: function (aSelectedItems, sPath, sProperty) {               
                var aFilter = [];
                var oModel = this.getView().getModel("destinosModel");
                for (var i = 0; i < aSelectedItems.length; i++) {
                    var sKey = aSelectedItems[i].getKey();
                    aFilter.push( new Filter({
                        path: sPath,
                        operator: FilterOperator.EQ,
                        value1: sKey
                    }));

                }
                oModel.setProperty(sProperty, aFilter);

            },


            saveFilterKunnr: function (aSelectedItems, sPath, sProperty) {
                var aFilter = [];
                var oModel = this.getView().getModel("destinosModel");
                for (var i = 0; i < aSelectedItems.length; i++) {
                    var sKey = aSelectedItems[i].getKey();
                    aFilter.push( new Filter({
                        path: sPath,
                        operator: FilterOperator.EQ,
                        value1: sKey
                    }));

                }
                oModel.setProperty(sProperty, aFilter);
                return aFilter;

            },


            /**
             * Events
             * @param {*} oEvent 
             */
            onTokenUpdate: function (oEvent) {
                //sap.m.MessageToast.show("update");
            },


            onSelectLink: function (oEvent) {  // radiobutton
                var iSelectedIndex = oEvent.getParameter("selectedIndex");
                
                if (iSelectedIndex === 0) {
                    this.getView().getModel("dataModel").setProperty("/linkapp", "");
                    this.getView().getModel("dataModel").setProperty("/linkrepo", "");
                    this.getView().getModel("viewModel").setProperty("/editlink", true);
                    this.getView().getModel("viewModel").setProperty("/editlinkapp", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkrepo", false);
                }
                
                if (iSelectedIndex === 1) {
                    this.getView().getModel("dataModel").setProperty("/link", "");
                    this.getView().getModel("dataModel").setProperty("/linkrepo", "");
                    this.getView().getModel("viewModel").setProperty("/editlink", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkapp", true);
                    this.getView().getModel("viewModel").setProperty("/editlinkrepo", false);
                }
                
                if (iSelectedIndex === 2) {
                    this.getView().getModel("dataModel").setProperty("/link", "");
                    this.getView().getModel("dataModel").setProperty("/linkapp", "");
                    this.getView().getModel("viewModel").setProperty("/editlink", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkapp", false);
                    this.getView().getModel("viewModel").setProperty("/editlinkrepo", true);
                }

            },

            onSelectionFinishBrsch: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");
                this.saveFilter(selectedItems, "brsch", "/aBrsch");
            },

            onSelectionFinishZone: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");
                this.saveFilter(selectedItems, "bzirk", "/aBzirk");
            },

            onSelectionFinishClase: function (oEvent) {
                var selectedItems = oEvent.getParameter("selectedItems");
                this.saveFilter(selectedItems, "crole", "/aRol");
            },

            onChangePrioridad: function (oEvent) {               
                var sKey = oEvent.getParameter("selectedItem").getProperty("key");
                this.getView().getModel("dataModel").setProperty("/prioridad", sKey);
            },

            onChangeClosebtn: function (oEvent) {
                var bValue = oEvent.getParameter("state");              
                var sClosebtn = (bValue ? "S" : "N");
                this.getView().getModel("dataModel").setProperty("/closebtn", sClosebtn);
            },

            onChangeSuspendida: function (oEvent) {                
                var bValue = oEvent.getParameter("state");              
                var sSuspendida = (bValue ? "S" : "N");
                this.getView().getModel("dataModel").setProperty("/suspendida", sSuspendida);
            },

            onChangeTipo: function (oEvent) {
                var sKey = oEvent.getParameter("selectedItem").getProperty("key");
                this.getView().getModel("dataModel").setProperty("/tipo", sKey);
            },

            onChangeColor: function (oEvent) {
                var sKey = oEvent.getParameter("selectedItem").getProperty("key");
                this.getView().getModel("dataModel").setProperty("/colorimg", sKey);
            },

            onChangeFdesde: function (oEvent) {
                //sap.m.MessageToast.show("change fdesde");
            },

            onPressVerReceptores: function (oEvent) {
                this.handleValueHelpR(oEvent);
            },


            // arma el filtro de los receptores antes de grabar
            armarFiltroDeReceptores: function () {
                var aFilters = [];
                var oModel = this.getView().getModel("destinosModel");
                
                var aBrsch = oModel.getProperty("/aBrsch");
                var aBzirk = oModel.getProperty("/aBzirk");
                var aRol = oModel.getProperty("/aRol");

                //tokens del multiinput
                var oMultiInput = this.byId("kunnrIDM");
                var oTokens = oMultiInput.getTokens();
                var aKunnr = this.saveFilterKunnr(oTokens, "kunnr", "/aKunnr");

                if (aBrsch.length) {
                    aFilters.push( 
                        new Filter({filters: aBrsch}) 
                    );
                }
                if (aBzirk.length) {
                    aFilters.push( 
                        new Filter({filters: aBzirk}) 
                    );
                }
                if (aRol.length) {
                    aFilters.push( 
                        new Filter({filters: aRol}) 
                    );
                }
                if (aKunnr.length) {
                    aFilters.push( 
                        new Filter({filters: aKunnr}) 
                    );
                }
                return aFilters;

            },

            validarDatos: function (oData) { 
                if (!this.validateField(oData.prioridad, "prioridadID")) {
                    return false;
                }
                if (!this.validateField(oData.titulo, "tituloID")) {
                    return false;
                }                
                return true;

            },

            validateField: function (sFieldValue, sFieldId) {
                var bResult = true;
                var oField = this.byId(sFieldId);
                if (!sFieldValue) {
                    oField.setValueState("Error");
                    oField.setValueStateText("Es un campo obligatorio");
                    bResult = false;
                } else {
                    oField.setValueState("None");
                    oField.setValueStateText("");
                    bResult = true;
                }
                return bResult;

            },

            /**
             * 
             * @param {*} oData 
             */
            crearNotificacion: function (oData) {
                var that = this;
                var oModel = this.getView().getModel();
                return new Promise(function (resolve, reject) {
                    var sPath = "/NotificacionSet";
                    oModel.create(sPath, oData, {
                        success: function (oData, oResponse) {
                            resolve();
                        },
                        error: function (oError) {
                            reject(oError);
                        }
                    });

                });
                
            },

            leerReceptores: function (aFilters) {
                var that = this;
                var oModel = this.getView().getModel();
                return new Promise(function (resolve, reject) {
                    var sPath = "/VH_ReceptorSet";
                    oModel.read(sPath, {
                        success: function (oData, oResponse) {
                            resolve(oData);
                        },
                        error: function (oError) {
                            reject(oError);
                        }, 
                        filters: aFilters
                    });

                });

            },


            /**
             * 
             * @param {*} oEvent 
             */

            // Receptores
            handleValueHelpR: function (oEvent) {
				var oView = this.getView();
                // create value help dialog
                if (!this._pValueHelpDialogR) {
                    this._pValueHelpDialogR = Fragment.load({
                        id: oView.getId(),
                        name: "profertil.notiflist.view.ValueHelpReceptor",
                        controller: this
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }

                var that = this;
                this._pValueHelpDialogR.then(function (oValueHelpDialog) {
                    // create a filter for the binding
                    var aFilters = that.armarFiltroDeReceptores();
                    oValueHelpDialog.getBinding("items").filter(aFilters);
                    oValueHelpDialog.open();

                });

            },  

            _handleValueHelpSearchR: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter(
                    "name1",
                    FilterOperator.Contains,
                    sValue
                );
                oEvent.getSource().getBinding("items").filter([oFilter]);

            }, 

            _handleValueHelpCloseR: function (oEvent) {

            },

            // kunnr
            handleValueHelp: function (oEvent) {
                var sInputValue = oEvent.getSource().getValue();
                oEvent.getSource().setValue("");
				var oView = this.getView();

                // create value help dialog
                if (!this._pValueHelpDialog) {
                    this._pValueHelpDialog = Fragment.load({
                        id: oView.getId(),
                        name: "profertil.notiflist.view.ValueHelpKunnr",
                        controller: this
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }

                var that = this;
                this._pValueHelpDialog.then(function (oValueHelpDialog) {
                    // create a filter for the binding
                    var aFilters = [];
                    var oModel = that.getView().getModel("destinosModel");
                    var aBrsch = oModel.getProperty("/aBrsch");
                    var aBzirk = oModel.getProperty("/aBzirk");
                    var aRol = oModel.getProperty("/aRol");

                    var aFilters = [];

                    if (aBrsch.length) {
                        aFilters.push( 
                            new Filter({filters: aBrsch}) 
                        );
                    }
                    if (aBzirk.length) {
                        aFilters.push( 
                            new Filter({filters: aBzirk}) 
                        );
                    }
                    if (aRol.length) {
                        aFilters.push( 
                            new Filter({filters: aRol}) 
                        );
                    }

                    oValueHelpDialog.getBinding("items").filter(aFilters);
                    // open value help dialog filtered by the input value
                    oValueHelpDialog.open(sInputValue);

                });

            },  

            _handleValueHelpSearch: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                
                var oFilter = new Filter(
                    "name1",
                    FilterOperator.Contains,
                    sValue
                );
                var oFilter2 = new Filter(
                    "kunnr",
                    FilterOperator.Contains,
                    sValue
                );
                                   
                oEvent.getSource().getBinding("items").filter([oFilter]);

            }, 

            _handleValueHelpClose: function (oEvent) {
                var aSelectedItems = oEvent.getParameter("selectedItems");
                var oMultiInput = this.byId("kunnrIDM");
                var aFilter = [];
                var sText = [];
                if (aSelectedItems && aSelectedItems.length > 0) {
                    aSelectedItems.forEach(function (oItem) {
                        sText = oItem.getTitle().split("-");
                        oMultiInput.addToken(new Token({
                            text: sText[0],
                            key: oItem.getDescription()
                        }));

                    });
                    
                }
                
                if (oMultiInput.getTokens().length) {
                    oMultiInput.setValueState("None");
                    oMultiInput.setValueStateText("");
                }

            },  
                
            // imagen (icono)
            handleValueHelp2: function (oEvent) {
                var oView = this.getView();                
                // create value help dialog
                if (!this._pValueHelpDialog2) {
                    this._pValueHelpDialog2 = Fragment.load({
                        id: oView.getId(),
                        name: "profertil.notiflist.view.ValueHelpIcon",
                        controller: this
                    }).then(function (oValueHelpDialog) {
                        oView.addDependent(oValueHelpDialog);
                        return oValueHelpDialog;
                    });
                }

                // open value help dialog
                this._pValueHelpDialog2.then(function(oValueHelpDialog){
                    oValueHelpDialog.open();
                });

            },  

            _handleValueHelpSearch2: function (oEvent) {
                var sValue = oEvent.getParameter("value");
                var oFilter = new Filter(
                    "descripcion",
                    FilterOperator.Contains, sValue
                );
                oEvent.getSource().getBinding("items").filter([oFilter]);

            },

           _handleValueHelpClose2: function (oEvent) {
                var oSelectedItem = oEvent.getParameter("selectedItem");
                if (oSelectedItem) {
                    var iconInput = this.byId("imagenID");
                    iconInput.setValue(oSelectedItem.getTitle());
                    var sKey = oSelectedItem.getIcon();
                    this.getView().getModel("dataModel").setProperty("/imagen", sKey);

                }
                oEvent.getSource().getBinding("items").filter([]);

            },


            /**
             * Boton Grabar y Cancelar
             * @param {*} oEvent 
             */
            onSubmitChanges: function (sGroupId, sChangeSetId) {
                var oModel = this.getView().getModel();
                oModel.setUseBatch(true);
                this.getView().setBusy(true);
                var that = this;
                oModel.submitChanges({
                    changeSetId: sChangeSetId,                    
                    success: function () {
                        that.getView().setBusy(false);
                        sap.m.MessageToast.show("Notificaciones Creadas");
                        that.onNavBack();
                        
                    },
                    error: function () {
                        that.getView().setBusy(false);
                        sap.m.MessageToast.show("Error creando las Notificaciones, intente mas tarde");
                    }
                });
                
            },

            createEntries5: function (aReceptores, oFormData) { 
                var aSuccess = [];
                var aError = [];
                var oModel = this.getView().getModel();
                oModel.setUseBatch(false);
                var dFdesde = this.byId("fdesdeID").getProperty("dateValue");
                var dFhasta = this.byId("fhastaID").getProperty("dateValue");
                var sPath = "/NotificacionSet";
                var that = this;
                var runCreate = function (dataIndex) {
                    if (aReceptores.length === dataIndex) {
                        sap.m.MessageToast.show("Notificaciones creadas: " + aSuccess.length);
                        //console.warn("OK: " + aSuccess.length + ", Errores: " + aError.length );
                        that.onNavBack();
                        that.getView().setBusy(false);
                        return;
                    }

                    var oReceptor = {};
                    oReceptor = aReceptores[dataIndex];

                    var oNewData = {};
                    oNewData = Object.assign({}, oFormData);

                    var sPos = "";
                    sPos = (dataIndex+1).toString();
                    oNewData.kunnr = oReceptor.kunnr;
                    oNewData.posicion = sPos;
                    oNewData.clase = oReceptor.crole;
                    oNewData.brsch = oReceptor.brsch;
                    oNewData.bzirk = oReceptor.bzirk;
                    oNewData.usermail = oReceptor.usbtp;
                    oNewData.fdesde = dFdesde;
                    oNewData.fhasta = dFhasta;
                    oModel.create(sPath, oNewData, {
                        success: function (oData) {
                            aSuccess.push(sPos);
                            runCreate(++dataIndex);
                        },
                        error: function (oError) {
                            aError.push(sPos);
                            runCreate(++dataIndex);
                        }
                    });                    

                }
                this.getView().setBusy(true);
                runCreate(0);         

            },

            confirmarGrabar: function (aReceptores, oFormData) {
                var iLength = aReceptores.length; 
                var sMessage = "Se generaran " + iLength.toString() + " notificaciones";
                var that = this;
                MessageBox.warning(sMessage, {
                    actions: ["Generar Notificaciones", "Cancelar"],
                    onClose: function (sAction) {
                        if (sAction === "Cancelar") {
                            sap.m.MessageToast.show("Accion Cancelada");
                        } else {
                            that.createEntries5(aReceptores, oFormData); // ok recursive calls 
                        }

                    }
                });

            },

            // boton grabar
            onGrabar: function (oEvent) {
                var oModel = this.getView().getModel("dataModel");
                var oFormData = oModel.getData();
                var aFilters = this.armarFiltroDeReceptores();
                var bDatosOK = this.validarDatos(oFormData);
                if (!bDatosOK) {
                    return;
                }

                var that = this;
                this.leerReceptores(aFilters).then(function (oData) {
                    if (oData.results.length) {
                        that.confirmarGrabar(oData.results, oFormData);
                    } else {
                        sap.m.MessageToast.show("Valide los receptores del mensaje");
                    }
                    
                });

            },

            setBatchMode: function (bValue) {
                this.getView().getModel().setUseBatch(bValue);
            },

            onCancelar: function (oEvent) {
                this.onNavBack();

            },

            onNavBack: function () {
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();

                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteList", true);
                }
            },

            _onObjectMatched: function (oEvent) {
                this.createDataModel();
                this.createDestinosModel();
                this.byId("brschID").setSelectedKeys([]);
                this.byId("bzirkID").setSelectedKeys([]);
                this.byId("croleID").setSelectedKeys([]);
                this.byId("kunnrIDM").setTokens([]);
                this.setBatchMode(true);
                
            }


		});  // function controller
	});