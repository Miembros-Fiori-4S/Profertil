sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/routing/History"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, formatter, Filter, JSONModel, History) {
		"use strict";

		return Controller.extend("profertil.notiflist.controller.ListarNotificaciones", {

            formatter: formatter,

			onInit: function () {
                this.createViewModel();
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("RouteNotifList").attachPatternMatched(this._onObjectMatched, this);
                
            },

            createViewModel: function () {
                var oModel = new JSONModel({
                    "kunnr": "",
                    "name1": ""
                });
                this.getView().setModel(oModel, "viewModel");

            },

            onUpdateFinished: function (oEvent) {
                var sPath = "";
                var oItems = this.byId("listID").getBinding("items");
                var sName1 = "";
                var sKunnr = "";
                if (oItems.aKeys.length) {
                    sPath = "/" + oItems.aKeys[0];
                    sName1 = this.getView().getModel().getProperty(sPath).name1;
                    sKunnr = this.getView().getModel().getProperty(sPath).kunnr;
                }
                var oModel = this.getView().getModel("viewModel");
                oModel.setProperty("/kunnr", sKunnr);
                oModel.setProperty("/name1", sName1);

            },

            onCancelar: function (oEvent) {
                this.onNavBack();
                
            },

            onNavBack: function () {
                var oHistory = History.getInstance();
                var sPreviousHash = oHistory.getPreviousHash();

                if (sPreviousHash !== undefined) {
                    window.history.go(-1);
                } else {
                    var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                    oRouter.navTo("RouteList", true);
                }

            },

            _onObjectMatched: function (oEvent) {
                var sKunnr = oEvent.getParameter("arguments").kunnr;
                var aFilter = [];
                aFilter.push(new Filter("kunnr", "EQ", sKunnr));
                aFilter.push(new Filter("soloactivas", "EQ", "X"));
                this.byId("listID").getBinding("items").filter(aFilter); 

            }
                
            
		});
	});
