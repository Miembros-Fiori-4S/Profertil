sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "sap/m/MessageBox",
    "sap/ui/core/routing/History",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment"
],
/**
 * @param {typeof sap.ui.core.mvc.Controller} Controller
 */
function (Controller, formatter, MessageBox, History, JSONModel, Fragment) {
    "use strict";
    
    return Controller.extend("profertil.notiflist.controller.ModificarNotificacion", {

        formatter: formatter,

        onInit: function () {

            this.createIconModel();
            this.createViewModel();
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
            oRouter.getRoute("RouteModificar").attachPatternMatched(this._onObjectMatched, this);
                
        },

        createViewModel: function () {
            var oModel = new JSONModel({
                editlink: true
            });
            this.getView().setModel(oModel, "viewModel");

        },

        onSelectLink: function (oEvent) {  // radiobutton
            var iSelectedIndex = oEvent.getParameter("selectedIndex");
            if (iSelectedIndex === 1) {
                this.byId("linkID").setValue("");
                this.getView().getModel("viewModel").setProperty("/editlink", false);
            }
            if (iSelectedIndex === 0) {
                this.byId("linkappID").setValue("");
                this.getView().getModel("viewModel").setProperty("/editlink", true);
            }

        },


        onChangeColor: function () {
        },

        onGrabar: function (oEvent) {
            var oContext = this.getView().getBindingContext();
            var sPath = oEvent.getSource().getBindingContext().sPath
            var oData = oContext.getProperty(sPath);
            
            var oDataNew = {
                "kunnr": oData.kunnr,
                "posicion": oData.posicion,
                "prioridad": oData.prioridad,
                "titulo": oData.titulo,
                "descripcion": oData.descripcion,
                "imagen": oData.imagen,
                "colorimg": oData.colorimg,
                "autor": oData.autor,
                "closebtn": oData.closebtn,
                "tipo": oData.tipo,
                "fdesde": this.byId("fdesdeID").getProperty("dateValue"),
                "fhasta": this.byId("fhastaID").getProperty("dateValue"),
                "suspendida": oData.suspendida,
                "link": oData.link,
                "linkapp": oData.linkapp
            };

            var that = this;
            this.grabarModificaciones(oDataNew).then(function (oData) {
                sap.m.MessageToast.show("Cambios Guardados", {closeOnBrowserNavigation: false});
                that.onNavBack();
            }).catch(function (oError) {
                sap.m.MessageToast.show("Se produjeron errores, intente mas tarde", {closeOnBrowserNavigation: false});
            });

        },

        grabarModificaciones: function (oData) {
            var that = this;
            return new Promise(function (resolve, reject) {
                var sKunnr = oData.kunnr;
                var sPos = oData.posicion;
                var sPath = "/NotificacionSet(kunnr='" + sKunnr + "',posicion='" + sPos + "')";
                var oModel = that.getView().getModel();
                oModel.setUseBatch(false);
                oModel.update(sPath, oData, {
                    success: function (oData, oResponse) {
                        resolve(oData);
                    },
                    error: function (oError) {
                        reject(oError);
                    }
                });
            } );

        },

        onCancelar: function (oEvent) {
            this.onNavBack();
        },

        onNavBack: function () {
            var oHistory = History.getInstance();
            var sPreviousHash = oHistory.getPreviousHash();

            if (sPreviousHash !== undefined) {
                window.history.go(-1);
            } else {
                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.navTo("RouteList", true);
            }
            
        },

        onChangeClosebtn: function (oEvent) {
            var bValue = oEvent.getParameter("state");              
            var sClosebtn = (bValue ? "S" : "N");
            var sPath = oEvent.getSource().getBindingContext().sPath + "/closebtn";
            this.getView().getModel().setProperty(sPath, sClosebtn);
            
        },

        onChangeSuspendida: function (oEvent) {
            var bValue = oEvent.getParameter("state");
            var sSuspendida = (bValue ? "S" : "N");
            var sPath = oEvent.getSource().getBindingContext().sPath + "/suspendida";
            this.getView().getModel().setProperty(sPath, sSuspendida);

        },

        // iconos
        createIconModel: function () {
            var aData = [];
            var aData_aux = [];
            aData = sap.ui.core.IconPool.getIconNames();
            for (var i=0; i < aData.length; i++) {
                var oData = {};
                oData.imagen = "sap-icon://" + aData[i];
                oData.descripcion = aData[i];
                aData_aux.push(oData);   
            }
            this.getView().setModel(new JSONModel(aData_aux), "iconModel2");

        },

        // imagen (icono)
        handleValueHelp2: function (oEvent) {
            var oView = this.getView();                
            // create value help dialog
            if (!this._pValueHelpDialog2) {
                this._pValueHelpDialog2 = Fragment.load({
                    id: oView.getId(),
                    name: "profertil.notiflist.view.ValueHelpIcon",
                    controller: this
                }).then(function (oValueHelpDialog) {
                    oView.addDependent(oValueHelpDialog);
                    return oValueHelpDialog;
                });
            }

            // open value help dialog
            this._pValueHelpDialog2.then(function(oValueHelpDialog){
                oValueHelpDialog.open();
            });

        },  

        _handleValueHelpSearch2: function (oEvent) {
            var sValue = oEvent.getParameter("value");
            var oFilter = new Filter(
                "descripcion",
                FilterOperator.Contains, sValue
            );
            oEvent.getSource().getBinding("items").filter([oFilter]);
        },

        _handleValueHelpClose2: function (oEvent) {
            var oSelectedItem = oEvent.getParameter("selectedItem");
            if (oSelectedItem) {
                var iconInput = this.byId("imagenID");
                var sKey = oSelectedItem.getIcon();
                iconInput.setValue(sKey);

            }
            oEvent.getSource().getBinding("items").filter([]);

        },

        _onObjectMatched: function (oEvent) {
            var oModel = this.getView().getModel();
            var sKunnr = oEvent.getParameter("arguments").kunnr;
            var sPos = oEvent.getParameter("arguments").posicion;
            var sPath = oModel.createKey("/NotificacionSet", {
                kunnr: sKunnr,
                posicion: sPos
            });

            this.getView().bindElement({
                path: sPath
			});


        }

    });
});