sap.ui.define([], function () {
	"use strict";
	return {};
});
