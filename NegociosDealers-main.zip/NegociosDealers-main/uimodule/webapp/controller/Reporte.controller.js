/* global moment:true */

sap.ui.define([
  "profertil/historialAcuerdosDealers/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  'sap/m/ColumnListItem',
  'sap/m/Label',
  'sap/m/Token',
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "../libs/moment"
], function (Controller, JSONModel, ColumnListItem, Label, Token, Filter, FilterOperator) {
  "use strict";

  return Controller.extend("profertil.historialAcuerdosDealers.controller.Reporte", {
    onInit: function () {
      var isUser = this._isUser();

      var jsonModel = new JSONModel({
        showAdminUI: !isUser,
        isUser: isUser
      });

      this.getView().setModel(jsonModel, "AdminUI");

      // // setear el ID de cliente en header from
      //   sap._sesionProfertil = { cliente: "0000100027" };
      //   var o = XMLHttpRequest.prototype.open;
      //   XMLHttpRequest.prototype.open = function () {
      //     var r = o.apply(this, arguments);
      //     if (arguments[1].indexOf("sap/opu/odata/sap") > -1) {
      //       this.setRequestHeader("from", sap._sesionProfertil.cliente);
      //     }
      //     return r;
      //   };
    },

    onBeforeRebindTable: function (oEvent) {
      if (this._isUser()) return;

      var mBindingParams = oEvent.getParameter("bindingParams");
      
      try {
        var fecha1 = this.byId("smartFilterBar").getFilterData().Fecha.ranges[0].value1;
        var fecha2 = this.byId("smartFilterBar").getFilterData().Fecha.ranges[0].value2;
        if (this._differenceInDays(fecha2, fecha1) > 732) {
          mBindingParams.preventTableBind = true;

          sap.m.MessageBox.error("Por favor, seleccione un periodo de fechas menor a dos años.");
          return;
        }
      } catch (e) {
      }
    },
    
    onBeforeExport: function(oEvent) {
      console.log(oEvent);
    },

    onOpenSummaryDialog: function () {
      if (!this._oDialog) {
        this._oDialog = sap.ui.xmlfragment("profertil.historialAcuerdosDealers.view.Summary", this);
        this.getView().addDependent(this._oDialog);
      }
      var that = this;  
      var oModel = this.getView().getModel();

      if (!this._isUser()) {
        var clientFilter = this.byId("smartFilterBar").getAllFiltersWithValues().filter(item => item.getName() === "User")[0];
        var client = parseInt(clientFilter.getControl().getTokens()[0].getKey()).toString();;

        oModel.setHeaders({
          "from": client
        });
      }

      this.getView().getModel().read("/ResumenSet", {
        success: function (data) {
          var oModel = new sap.ui.model.json.JSONModel();
          var list = [];
          var item = {};  
          for (var i=0; i < data.results.length; i++){
              item = {};    
              item.Producto = data.results[i].Producto;
              item.Saldo1 = parseFloat(data.results[i].Saldo1 , 3);
              item.Saldo2 = parseFloat(data.results[i].Saldo2 , 3);
              item.Saldo3 = parseFloat(data.results[i].Saldo3 , 3);
              item.Saldo4 = parseFloat(data.results[i].Saldo4 , 3);
              list.push(item);
          }
          oModel.setData(list);
          sap.ui.getCore().byId("summaryTable").setModel(oModel, "Saldos");
          // that._oDialog.setBusy(false);
        },
        error: function (oError) {
            // that._oDialog.setBusy(false);
        }
      });

      this._oDialog.open();
      // this._oDialog.setBusy(true);
    },

    onCloseDialog: function () {
      this._oDialog.close();
    },

    onPress: function (oEvent) {
      if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
        var item = oEvent.getParameter("listItem").getBindingContext().getProperty("Negocio");
        var sPath = "DocumentosRel-display?&/Documento/CON," + item;
        var hash = sap.ushell.Container.getService("CrossApplicationNavigation").hrefForExternal({
          target: {
            shellHash: sPath
          }
        });
        var id = window.location.href.substring(window.location.href.indexOf("true&") + 5, window.location.href.lastIndexOf("&sap-startup"));
        var url = window.location.href.replace(id, "sap-ui-app-id=profertil.RelatedsDocs").split("#")[0] + hash;
        //var url = urlH.replace("cp.portal/ui5appruntime.html", "site");
        sap.m.URLHelper.redirect(url, true);
      }
    },

    formatDate: function (date) {
      var oDate = new Date(date);

      let day = oDate.getUTCDate();
      let month = oDate.getUTCMonth() + 1;
      let year = oDate.getUTCFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    formatRowHighlight: function (date) {
      if (!date) return "Error";

      var state = "Error";

      if (moment().isBefore(date)) {
        var a = moment();
        var b = moment(date);

        if (Math.abs(a.diff(b, 'days')) < 8) {
          state = "Error";
        } else {
          state = "Success";
        }
      }

      return state;
    },

    formatPrice: function (price) {
      var num = parseFloat(price);
      return num.toFixed(2);
    },

    formatBalanceStatus: function (balance) {
      var state = "Error";

      if (balance > 0 && balance <= 150) state = "Warning";
      else if (balance > 150) state = "None";

      return state;
    },

    formatBalance: function (balance) {
      if (balance < 0) {
        return (balance - balance).toFixed(3);
      }

      return balance;
    },

    formatStatus(status, date) {
      var state = "Error";

      if (status.toLowerCase() == "abierto" || moment().isAfter(date)) state = "Success";

      return state;
    },

    onSort: function () {
      var oSmartTable = this._getSmartTable();
      if (oSmartTable) {
        oSmartTable.openPersonalisationDialog("Sort");
      }
    },

    onDocumentDownload: function (oEvent) {
      var negocio = oEvent.oSource.getBindingContext().getObject().Negocio;

      var oModel = this.getView().getModel("relatedDocs");
      var sServiceUrl = oModel.sServiceUrl;
      var sSource = sServiceUrl + "/PrinterSet(TipoDoc='CON',Documento='" + negocio + "')/$value";

      var w = window.open(sSource, '_blank');
      if (w == null) {
        sap.m.MessageBox.warning(oBundle.getText("Error.PopUpBloqued"));
      }
    },

    _getSmartTable: function () {
      if (!this._oSmartTable) {
        this._oSmartTable = this.getView().byId("acuerdosTable");
      }
      return this._oSmartTable;
    },

    _isUser: function () {
      var oHashObject = new sap.ui.core.routing.HashChanger();
      return oHashObject.getHash().includes("-display");
    },

    _differenceInDays: function(date1, date2) {
      var difference = Math.abs(date1.getTime() - date2.getTime());

      return difference / (1000*60*60*24);
    }
  });
});

