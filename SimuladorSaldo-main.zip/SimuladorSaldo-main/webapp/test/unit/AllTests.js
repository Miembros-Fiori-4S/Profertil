sap.ui.define([
	"profertil/simuladorsaldo/test/unit/controller/App.controller"
], function () {
	"use strict";
});
