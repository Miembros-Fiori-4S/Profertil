sap.ui.define(
  [
    "sap/ui/core/mvc/Controller",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "../model/formatter",
    "sap/viz/ui5/format/ChartFormatter"

  ],
  function (
    Controller,
    JSONModel,
    MessageBox,
    Filter,
    FilterOperator,
    formatter,
    ChartFormatter
  ) {
    "use strict";

    // tipos de línea según la tabla de origen
    const LINE_TYPES = {
      SALDO: 1,
      CHEQUE: 2,
      FIJACION_CEREAL: 3,
      ENTREGA_CEREAL: 4,
      NEGOCIO: 5,
      SIMULACION_PAGO: 6,
      LINEA_CREDITO: 7,
      LIQUIDACION_CEREAL: 8,
      MERC_FACT_COMP: 9,
      MERC_FACT_NO_COMP: 10,
      MERC_NO_FACT_NO_COMP: 11
    }

    return Controller.extend("profertil.simuladorsaldo.controller.Main", {
      formatter: formatter,

      onInit: function () {
        // setear el modelo a la vista
        this.getView().setModel(this.getOwnerComponent().getModel());
        this.getView().setModel(this.getOwnerComponent().getModel("mercaderia"), "mercaderia");

        // setear modelo con info inicial de la cuenta corriente
        this.getView().setModel(new JSONModel({}), "data");

        // modelos de los graficos
        this.getView().setModel(new JSONModel({
          saldo: {},
          credito: {}
        }),
          "graficos");

        // textos
        this._oTextos = this.getOwnerComponent().getModel("i18n").getResourceBundle();


        // TODO QUITAR
        // setear el ID de cliente en header from
        /* sap._sesionProfertil = { cliente: "0000101240" };
        var o = XMLHttpRequest.prototype.open;
        XMLHttpRequest.prototype.open = function () {
          var r = o.apply(this, arguments);
          if (arguments[1].indexOf("sap/opu/odata/sap") > 0) {
            this.setRequestHeader("from", sap._sesionProfertil.cliente);
          }
          return r;
        };*/


        this._oBusyDialog = new sap.m.BusyDialog({
          text: this._oTextos.getText("texto_cargando"),
        });
        this.readData();

        this.initChartSaldo();
        this.initChartCredito();
      },

      initChartSaldo: function () {
        var oVizProperties = {
          plotArea: {
            window: {
              start: "firstDataPoint",
              end: "lastDataPoint"
            },
            dataLabel: {
              formatString: ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
              visible: false
            },
            dataPointStyle: {
              "rules":
                [
                  {
                    // Positivos: rojo
                    "dataContext": { "Saldo": { max: 0 } },
                    "properties": {
                      "color": "sapUiChartPaletteSemanticGoodDark1",
                      "lineColor": "sapUiChartPaletteSemanticGoodLight1",
                      "lineType": "line"
                    },
                  },
                  {
                    // negativos: verde
                    "dataContext": { "Saldo": { min: 0 } },
                    "properties": {
                      "color": "sapUiChartPaletteSemanticBadDark1",
                      "lineColor": "sapUiChartPaletteSemanticBadLight1",
                      "lineType": "line"
                    }
                  }
                ]
            }
          },
          title: {
            visible: false,
            text: "Saldo a favor/vencido"
          },
          valueAxis: {
            visible: true,
            // label: {
            //   formatString: ChartFormatter.DefaultPattern.SHORTFLOAT
            // },
            title: {
              visible: true,
              text: "Saldo (USD)"
            }
          },
          timeAxis: {
            title: {
              visible: false
            },
            interval: {
              unit: ''
            }
          },
          interaction: {
            syncValueAxis: true,
            zoom: {
              enablement: "enabled"
            }
          }
        }

        var oVizFrame = this.getView().byId("idVizFrameSaldo");
        oVizFrame.setVizProperties(oVizProperties);

        var oPopOver = this.getView().byId("idVizPopoverSaldo");
        oPopOver.connect(oVizFrame.getVizUid());
        // oPopOver.setFormatString({
        //     "Saldo": ChartFormatter.DefaultPattern.STANDARDFLOAT,
        //     "Credito": ChartFormatter.DefaultPattern.STANDARDFLOAT
        // });
      },

      initChartCredito: function () {
        var oVizProperties = {
          plotArea: {
            window: {
              start: "firstDataPoint",
              end: "lastDataPoint"
            },
            dataLabel: {
              formatString: ChartFormatter.DefaultPattern.SHORTFLOAT_MFD2,
              visible: false
            },
            dataPointStyle: {
              "rules":
                [
                  {
                    // Positivos: verde
                    "dataContext": { "Credito": { min: 0 } },
                    "properties": {
                      "color": "sapUiChartPaletteSemanticGoodDark1",
                      "lineColor": "sapUiChartPaletteSemanticGoodLight1",
                      "lineType": "line"
                    },
                  },
                  {
                    // negativos: rojo
                    "dataContext": { "Credito": { max: 0 } },
                    "properties": {
                      "color": "sapUiChartPaletteSemanticBadDark1",
                      "lineColor": "sapUiChartPaletteSemanticBadLight1",
                      "lineType": "line"
                    }
                  }
                ]
            }

          },
          title: {
            visible: false,
            text: "Línea de crédito disponible"
          },
          valueAxis: {
            visible: true,
            // label: {
            //   formatString: ChartFormatter.DefaultPattern.SHORTFLOAT
            // },
            title: {
              visible: true,
              text: "Crédito (USD)"
            }
          },
          timeAxis: {
            title: {
              visible: false
            },
            interval: {
              unit: ''
            }
          },
          interaction: {
            syncValueAxis: true,
            zoom: {
              enablement: "enabled"
            }
          }
        }

        var oVizFrame = this.getView().byId("idVizFrameCredito");
        oVizFrame.setVizProperties(oVizProperties);

        var oPopOver = this.getView().byId("idVizPopoverCredito");
        oPopOver.connect(oVizFrame.getVizUid());
        // oPopOver.setFormatString({
        //     "Saldo": ChartFormatter.DefaultPattern.STANDARDFLOAT,
        //     "Credito": ChartFormatter.DefaultPattern.STANDARDFLOAT
        // });
      },

      /* Leer toda la info de cuenta corriente por unica vez y guardarla en modelo data */
      readData: function () {
        var oModel = this.getView().getModel();

        this._oBusyDialog.open();
        var aPromises = [
          this.read_detSaldo(),
          this.read_detNegocio(),
          this.read_detMercaderiaFacturadaCompensada(),
          this.read_detMercaderiaFacturadaNoCompensada(),
          this.read_detMercaderiaNoFacturada(),
          this.read_detCereal(),
          this.read_detCheques(),
          this.read_saldoCuenta()
        ];

        Promise.all(aPromises)
          .then(
            function (aResults) {
              this._oBusyDialog.close();
              this.saveData(aResults);
              this.calculateCharts();
            }.bind(this)
          )
          .catch(
            function (error) {
              this._oBusyDialog.close();
              console.log(error);
              MessageBox.error("Se ha producido un error, intente nuevamente.");
            }.bind(this)
          );
      },

      /* Leer entidad detalle de saldo cuenta corriente: cta_det_salSet*/
      read_detSaldo: function () {
        var aFilters = [];
        aFilters.push(
          new Filter({
            path: "FechaSaldo",
            operator: FilterOperator.EQ,
            value1: new Date(),
          })
        );
        aFilters.push(
          new Filter({
            path: "Kunnr",
            operator: FilterOperator.EQ,
            value1: "null",
          })
        );

        var oModel = this.getView().getModel();
        return new Promise(function (resolve, reject) {
          oModel.read("/cta_det_salSet", {
            filters: aFilters,
            success: function (oData) {
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      // /* Leer entidad detalle de negocios abiertos: det_negocioSet */
      read_detNegocio: function () {
        var aFilters = [];
        aFilters.push(
          new Filter({
            path: "Kunnr",
            operator: FilterOperator.EQ,
            value1: "null",
          })
        );


        var oModel = this.getView().getModel();
        return new Promise(function (resolve, reject) {
          oModel.read("/det_negocioSet", {
            filters: aFilters,
            success: function (oData) {
              if (!oData.results) {
                reject("Sin resultados");
              }
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      /* Leer entidad MercaderiaFacturadaCompensada */
      read_detMercaderiaFacturadaCompensada: function () {
        var aFilters = [];
        var oModel = this.getView().getModel("mercaderia");
        return new Promise(function (resolve, reject) {
          oModel.read("/MercaderiaFacturadaCompensadaSet", {
            filters: aFilters,
            success: function (oData) {
              if (!oData.results) {
                reject("Sin resultados");
              }
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      /* Leer entidad MercaderiaFacturadaNoCompensada */
      read_detMercaderiaFacturadaNoCompensada: function () {
        var aFilters = [];
        var oModel = this.getView().getModel("mercaderia");
        return new Promise(function (resolve, reject) {
          oModel.read("/MercaderiaFacturadaNoCompensadaSet", {
            filters: aFilters,
            success: function (oData) {
              if (!oData.results) {
                reject("Sin resultados");
              }
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },
      /* Leer entidad MercaderiaNoFacturada */
      read_detMercaderiaNoFacturada: function () {
        var aFilters = [];
        var oModel = this.getView().getModel("mercaderia");
        return new Promise(function (resolve, reject) {
          oModel.read("/MercaderiaNoFacturadaSet", {
            filters: aFilters,
            success: function (oData) {
              if (!oData.results) {
                reject("Sin resultados");
              }
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      /* Leer entidad detalle de cereal: det_cerealSet */
      read_detCereal: function () {
        var aFilters = [];
        aFilters.push(
          new Filter({
            path: "Kunnr",
            operator: FilterOperator.EQ,
            value1: "null",
          })
        );


        var oModel = this.getView().getModel();
        return new Promise(function (resolve, reject) {
          oModel.read("/det_cerealSet", {
            filters: aFilters,
            success: function (oData) {
              if (!oData.results) {
                reject("Sin resultados");
              }
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      /* Leer entidad detalle de cheques pendientes de acreditar: det_chequeSet */
      read_detCheques: function () {
        var aFilters = [];
        aFilters.push(
          new Filter({
            path: "Kunnr",
            operator: FilterOperator.EQ,
            value1: "null",
          })
        );


        var oModel = this.getView().getModel();
        return new Promise(function (resolve, reject) {
          oModel.read("/det_chequeSet", {
            filters: aFilters,
            success: function (oData) {
              if (!oData.results) {
                reject("Sin resultados");
              }
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      /* Leer entidad con los saldos de la cuenta: cta_saldoSet */
      read_saldoCuenta: function () {
        var aFilters = [];
        aFilters.push(
          new Filter({
            path: "Kunnr",
            operator: FilterOperator.EQ,
            value1: "null",
          })
        );


        var oModel = this.getView().getModel();
        return new Promise(function (resolve, reject) {
          oModel.read("/cta_saldoSet", {
            filters: aFilters,
            success: function (oData) {
              if (!oData.results || !oData.results.length) {
                reject("Sin resultados");
              }
              resolve(oData);
            },
            error: function (oError) {
              reject(oError);
            },
          });
        });
      },

      saveData: function (aResults) {
        var oData = {
          detSaldo: aResults[0].results, // detalle cuenta corriente
          detNegocio: aResults[1].results, // negocios comprometidos
          detMercaderia: [], // detalle de mercaderia, se completa abajo
          detCereal: aResults[5].results, // detalle de cereal
          detCheques: aResults[6].results, // detalle de cheques diferidos
          lineaCreditoDisponible: aResults[7].results[0].LineaDisponible, // linea de credito disponible
          saldoHoy: 0, // saldo al día de hoy
          tituloGraficoSaldo: "", // titulo del grafico de saldo
          tituloGraficoCredito: "", // titulo del grafico de credito
          pagosSimulados: [], // al principio está en blanco hasta que cargue algo
          bLiquidacionCereal: false, // flag simular liquidación cereal
          bFijacionCereal: false, // flag simular fijación cereal
          bEntregaCereal: false, // flag simular entrega de cereal
          bChequesPagoDiferido: false, // flag simular cheques pago diferido
          hoy: new Date()
        };

        // // Con la informacion obtenida en el paso 2. A aquellos negocios que tengan fecha Vig. Neg inferior o igual a (hoy+7) se le cambia el vencimiento a (hoy()+7)
        // // Y se recalcula la columna Valor USD solo usando Saldo. =saldo * Precio * 1,105
        // // Solo para crédito
        var hoymas7 = new Date();
        hoymas7.setDate(hoymas7.getDate() + 7);


        for (var line of oData.detNegocio) {
          if (line.Gueen < hoymas7) {
            line.Gueen = hoymas7;
          }
          line.ValorCredito = parseFloat(line.Saldo) * parseFloat(line.Netpr) * 1.105;
        }


        // Con la informacion obtenida en el paso 2. A aquellos negocios que tengan fecha Vig. Neg inferior o igual a (hoy+7) se le cambia el vencimiento a (hoy()+7)
        // Y se consolidan las 3 tablas de mercaderia en una sola detMercaderia
        // mercaderia facturada compensada
        for (var line of aResults[2].results) {
          if (line.Gueen < hoymas7) {
            line.Gueen = hoymas7;
          }
          line.Saldo = parseFloat(line.NoEntreFacComp); // toneladas, para el simulador de retiros
          line.Valor = parseFloat(line.NoEntreFacCompIva); // importe, para el simulador de retiros
          line.Tipo = LINE_TYPES.MERC_FACT_COMP;
          oData.detMercaderia.push(line);
        }

        // mercaderia facturada NO compensada
        for (var line of aResults[3].results) {
          if (line.Gueen < hoymas7) {
            line.Gueen = hoymas7;
          }
          line.Saldo = parseFloat(line.NoEntreFacNoComp); // toneladas, para el simulador de retiros
          line.Valor = parseFloat(line.NoEntreFacNoCompIva); // importe, para el simulador de retiros
          line.Tipo = LINE_TYPES.MERC_FACT_NO_COMP;
          oData.detMercaderia.push(line);
        }

        // mercaderia NO facturada NO compensada
        for (var line of aResults[4].results) {
          if (line.Gueen < hoymas7) {
            line.Gueen = hoymas7;
          }
          line.Saldo = parseFloat(line.NoEntreNoFac); // toneladas, para el simulador de retiros
          line.Valor = parseFloat(line.NoEntreNoFacIva); // importe, para el simulador de retiros
          line.Tipo = LINE_TYPES.MERC_NO_FACT_NO_COMP;
          oData.detMercaderia.push(line);
        }

        console.log(oData);
        this.getView().getModel("data").setData(oData);
      },

      /* Toma todas las tablas de detalle de cuenta corriente y las compila en 2 tablas, una para
      cada grafico: saldos y creditos */
      compileDataModels: function () {

        var oData = this.getView().getModel("data").getData();
        var aChartSaldoSortedData = [];
        var aChartCreditoSortedData = [];
        var importe;
        var hoy = new Date();
        var ayer = new Date();
        ayer.setDate(ayer.getDate() - 1);

        // consolidar las 6 tablas en una, ordenada por fecha


        // credito: a LineaCreditoDisponible le asginamos fecha de ayer y lo ponemos con signo negativo
        aChartCreditoSortedData.push({
          //importe: Math.abs(parseFloat(oData.lineaCreditoDisponible)) * -1,
          importe: parseFloat(oData.lineaCreditoDisponible) * -1,
          fecha: ayer,
          fechaKey: this.getDateKey(ayer),
          detalle: null,
          tipo: LINE_TYPES.LINEA_CREDITO,
        })


        // detalle saldo
        for (var line of oData.detSaldo) {
          if (line.Zfbdt) {

            // info para grafico de saldo
            aChartSaldoSortedData.push({
              // importe: parseFloat(line.SaldoAcumMe),
              importe: parseFloat(line.Dmbe3),
              fecha: line.Zfbdt,
              fechaKey: this.getDateKey(line.Zfbdt),
              detalle: line,
              tipo: LINE_TYPES.SALDO,
              descripcion: line.BlartTxt
            });

          }
        }

        // // negocios comprometidos
        for (var line of oData.detNegocio) {
          if (line.BstdkE) {

            // info para grafico de saldo
            aChartSaldoSortedData.push({
              importe: parseFloat(line.Valor),
              fecha: line.BstdkE,
              fechaKey: this.getDateKey(line.BstdkE),
              detalle: line,
              tipo: LINE_TYPES.NEGOCIO,
            });

            // info para grafico de credito - ahora se toma de mercaderia

            // aChartCreditoSortedData.push({
            //   importe: parseFloat(line.ValorCredito),
            //   fecha: line.Gueen, // vigencia negocio
            //   fechaKey: this.getDateKey(line.Gueen),
            //   detalle: line,
            //   tipo: LINE_TYPES.NEGOCIO,
            // });
          }
        }

        // Mercaderia
        for (var line of oData.detMercaderia) {
          if (line.BstdkE) {

            // info para grafico de credito
            // solo las no compensadas
            if (line.Tipo === LINE_TYPES.MERC_FACT_NO_COMP || line.Tipo === LINE_TYPES.MERC_NO_FACT_NO_COMP)
              aChartCreditoSortedData.push({
                importe: parseFloat(line.Valor),
                fecha: line.Gueen, // vigencia negocio
                fechaKey: this.getDateKey(line.Gueen),
                detalle: line,
                tipo: line.Tipo,
              });
          }
        }


        // detalle de cereal
        for (var line of oData.detCereal) {

          // info para grafico de saldo segun los switchs activos

          // entrega cereal, UsdPend con fecha de hoy
          importe = parseFloat(line.UsdPend);

          // para el saldo, es importe pendiente - ìmporte liquidado no entregado
          var importeSaldoEntrega = parseFloat(line.UsdPend) + parseFloat(line.UsdLiqNoEntregadas);

          var fechaEntregaCereal = line.Hasta;
          // si está vencido, poner fecha de hoy
          if (fechaEntregaCereal < hoy) {
            fechaEntregaCereal = hoy;
          }

          // saldo
          if (oData.bEntregaCereal && importeSaldoEntrega) {
            aChartSaldoSortedData.push({
              importe: importeSaldoEntrega,
              fecha: fechaEntregaCereal,
              fechaKey: this.getDateKey(fechaEntregaCereal),
              detalle: line,
              tipo: LINE_TYPES.ENTREGA_CEREAL,
            });
          }
          // credito
          if (oData.bEntregaCereal && importe) {
            aChartCreditoSortedData.push({
              importe: importe,
              fecha: fechaEntregaCereal,
              fechaKey: this.getDateKey(fechaEntregaCereal),
              detalle: line,
              tipo: LINE_TYPES.ENTREGA_CEREAL,
            });
          }

          // fijacion cereal, UsdEntrPendFijar con fecha de hoy
          importe = parseFloat(line.UsdEntrPendFijar);
          if (oData.bFijacionCereal && importe) {
            aChartSaldoSortedData.push({
              importe: importe,
              fecha: hoy,
              fechaKey: this.getDateKey(hoy),
              detalle: line,
              tipo: LINE_TYPES.FIJACION_CEREAL,
            });
          }

          // liquidacion cereal, UsdEntrPendLiqui con fecha de hoy
          importe = parseFloat(line.UsdEntrPendLiqui);
          if (oData.bLiquidacionCereal && importe) {
            aChartSaldoSortedData.push({
              importe: importe,
              fecha: hoy,
              fechaKey: this.getDateKey(hoy),
              detalle: line,
              tipo: LINE_TYPES.LIQUIDACION_CEREAL,
            });
          }

        }

        // detalle de cheques
        if (oData.bChequesPagoDiferido) {
          // solo si está activado el switch

          for (var line of oData.detCheques) {
            if (line.Zfbdt) {
              aChartSaldoSortedData.push({
                importe: parseFloat(line.Dmbe3),
                fecha: line.Zfbdt,
                fechaKey: this.getDateKey(line.Zfbdt),
                detalle: line,
                tipo: LINE_TYPES.CHEQUE,
              });

              aChartCreditoSortedData.push({
                importe: parseFloat(line.Dmbe3),
                fecha: line.Zfbdt,
                fechaKey: this.getDateKey(line.Zfbdt),
                detalle: line,
                tipo: LINE_TYPES.CHEQUE,
              });
            }
          }

        } // fin detalle de cereal

        // simulaciones de pagos
        for (var line of oData.pagosSimulados) {
          if (line.fecha && line.importe > 0) {
            aChartSaldoSortedData.push({
              importe: parseFloat(line.importe) * -1,
              fecha: line.fecha,
              fechaKey: this.getDateKey(line.fecha),
              detalle: line,
              tipo: LINE_TYPES.SIMULACION_PAGO,
            });
          }
          if (line.fecha && line.importe > 0) {
            aChartCreditoSortedData.push({
              importe: parseFloat(line.importe) * -1,
              fecha: line.fecha,
              fechaKey: this.getDateKey(line.fecha),
              detalle: line,
              tipo: LINE_TYPES.SIMULACION_PAGO,
            });
          }
        }


        // ordenar los documentos por fecha ascendente, para luego poder calcular acumulado
        aChartSaldoSortedData = aChartSaldoSortedData.sort((a, b) =>
          a.fecha > b.fecha ? 1 : -1
        );

        aChartCreditoSortedData = aChartCreditoSortedData.sort((a, b) =>
          a.fecha > b.fecha ? 1 : -1
        );

        // cargar acumulado para saldo
        var acumulado = 0;
        for (var line of aChartSaldoSortedData) {
          acumulado += line.importe;
          line.acumulado = acumulado;
        }

        console.log(oData);

        // cargar acumulado para creditos e invertir signo
        var acumulado = 0;
        for (var line of aChartCreditoSortedData) {
          line.importe *= -1;
          acumulado += line.importe;
          line.acumulado = acumulado;
        }

        console.log(oData);

        return {
          aChartSaldoSortedData: aChartSaldoSortedData,
          aChartCreditoSortedData: aChartCreditoSortedData
        }
      },

      calculateCharts: function () {
        var aSortedInfo = this.compileDataModels();
        console.log(aSortedInfo);

        // armar grafico de saldo
        var aChartSaldo = this.buildChartSaldo(aSortedInfo.aChartSaldoSortedData);


        // buscar el saldo de hoy o inmediatamente anterior
        var saldoHoy = 0;
        var hoy = new Date();
        for (var line of aChartSaldo) {
          if (line.fecha > hoy) {
            break;
          }
          saldoHoy = line.saldo;
        }
        this.getView().getModel("data").setProperty("/saldoHoy", saldoHoy);

        // setear titulo del grafico de saldo
        if (saldoHoy > 0) {
          this.getView().getModel("data").setProperty("/tituloGraficoSaldo", this._oTextos.getText("grafico_saldo_titulo_positivo", [new Date().toLocaleDateString(), formatter.importe(saldoHoy)]));
        } else {
          this.getView().getModel("data").setProperty("/tituloGraficoSaldo", this._oTextos.getText("grafico_saldo_titulo_negativo", [new Date().toLocaleDateString(), formatter.importe(saldoHoy)]));
        }

        // armar grafico de credito
        var aChartCredito = this.buildChartCredito(aSortedInfo.aChartCreditoSortedData);

        // setear titulo del grafico de credito
        this.getView().getModel("data").setProperty("/tituloGraficoCredito", this._oTextos.getText("grafico_credito_titulo", [formatter.importe(this.getView().getModel("data").getProperty("/lineaCreditoDisponible"))]));

        this.getView()
        .getModel("graficos").setSizeLimit(300);
        
        this.getView()
          .getModel("graficos")
          .setProperty("/saldo", aChartSaldo);

        this.getView()
          .getModel("graficos")
          .setProperty("/credito", aChartCredito);

        this.getView()
          .getModel("graficos")
          .setProperty("/tablaSaldo", aSortedInfo.aChartSaldoSortedData);

        this.getView()
          .getModel("graficos")
          .setProperty("/tablaCredito", aSortedInfo.aChartCreditoSortedData);

      },

      /* Toma la info ordenada por fecha y la agrupa en el formato que espera el grafico de saldo */
      buildChartSaldo: function (aData) {
        var aChartSaldo = [];
        var saldo = 0
        var fecha = null;
        var fechaKey = null;
        var hoy = new Date();

        if (!aData.length) {
          return;
        }

        // calcular acumulado dia por dia
        for (var i = 0; i < aData.length; i++) {
          var line = aData[i];

          // cuando cambia la fecha, antes del ultimo registro: agregar nueva linea
          if (line.fechaKey !== fechaKey && i < aData.length) {
            aChartSaldo.push({
              fecha: fecha,
              fechaKey: fechaKey,
              saldo: saldo
            });
          }

          // guardar el anterior
          fecha = line.fecha;
          fechaKey = line.fechaKey;

          // acumular saldo
          saldo += line.importe;

        }

        // agregar la linea final
        aChartSaldo.push({
          fecha: line.fecha,
          fechaKey: line.fechaKey,
          saldo: saldo
        });

        // agregar una linea con fecha de hoy, si el grafico no termina hoy
        if (aChartSaldo[aChartSaldo.length - 1].fecha < hoy) {
          aChartSaldo.push({
            fecha: hoy,
            fechaKey: this.getDateKey(hoy),
            saldo: saldo
          });
        }

        return aChartSaldo;
      },

      /* Toma la info ordenada por fecha y la agrupa en el formato que espera el grafico de credito */
      buildChartCredito: function (aData) {
        var aChartCredito = [];
        var credito = 0
        var fecha = null;
        var fechaKey = null;
        var hoy = new Date();

        if (!aData.length) {
          return;
        }

        // calcular acumulado dia por dia
        for (var i = 0; i < aData.length; i++) {
          var line = aData[i];


          // cuando cambia la fecha, antes del ultimo registro: agregar nueva linea
          if (line.fechaKey !== fechaKey && i < aData.length) {
            aChartCredito.push({
              fecha: fecha,
              fechaKey: fechaKey,
              credito: credito
            });
          }

          // guardar el anterior
          fecha = line.fecha;
          fechaKey = line.fechaKey;

          // acumular credito
          credito += line.importe;
        }

        // agregar la linea final
        aChartCredito.push({
          fecha: line.fecha,
          fechaKey: line.fechaKey,
          credito: credito
        });

        return aChartCredito;
      },

      getDateKey: function (date) {
        return date.toISOString().substr(0, 10);
      },

      onAgregarPagoSimulado: function (oEvent) {
        var aPagos = this.getView().getModel("data").getProperty("/pagosSimulados");
        var hoy = new Date();
        aPagos.push({
          fecha: hoy,
          importe: ""
        });
        this.getView().getModel("data").setProperty("/pagosSimulados", aPagos);
      },

      onEliminarPagoSimulado: function (oEvent) {
        // tomar el indice del path del objeto: /pagosSimulados/1
        var sPath = oEvent.getSource().getBindingContext("data").getPath();
        var index = sPath.substr(sPath.lastIndexOf("/") + 1);

        var aPagos = this.getView().getModel("data").getProperty("/pagosSimulados");

        // borrar el objeto
        aPagos.splice(index, 1);
        this.getView().getModel("data").setProperty("/pagosSimulados", aPagos);

        this.calculateCharts();
      },

      onDescargarPDF: function () {
        var sGraficoSaldo = this.getView().byId("idVizFrameSaldo").exportToSVGString({
          width: 800,
          height: 600
        });
        var sGraficoCredito = this.getView().byId("idVizFrameCredito").exportToSVGString({
          width: 800,
          height: 600
        });


        // Movimientos de saldo

        var aDataSaldoIn = this.getView().getModel("graficos").getProperty("/tablaSaldo");
        var aDataSaldo = [];

        // pasar los datos formateados a aDataSaldo
        for (var line of aDataSaldoIn) {
          aDataSaldo.push([
            line.fecha.toLocaleDateString(),
            formatter.tipoMovimiento(line.tipo, line.descripcion),
            formatter.importe(line.importe),
            formatter.importe(line.acumulado)
          ])
        }

        var aHeadersSaldo = [["Fecha", "Tipo movimiento", "Importe", "Acumulado"]];

        // Movimientos de crédito

        var aDataCreditoIn = this.getView().getModel("graficos").getProperty("/tablaCredito");
        var aDataCredito = [];

        // pasar los datos formateados a aDataSaldo
        for (var line of aDataCreditoIn) {
          aDataCredito.push([
            line.fecha.toLocaleDateString(),
            formatter.tipoMovimiento(line.tipo),
            formatter.importe(line.importe),
            formatter.importe(line.acumulado)
          ])
        }
        var aHeadersCredito = [["Fecha", "Tipo movimiento", "Importe", "Acumulado"]];

        // Simulaciones de pago

        var aDataPagosSimuladosIn = this.getView().getModel("data").getProperty("/pagosSimulados");
        var aDataPagosSimulados = [];

        // pasar los datos formateados a aDataPagosSimulados
        for (var line of aDataPagosSimuladosIn) {
          aDataPagosSimulados.push([
            line.fecha.toLocaleDateString(),
            formatter.importe(line.importe),
          ])
        }
        var aHeadersPagosSimulados = [["Fecha", "Importe"]];

        // Simulaciones de retiro fertilizante

        var aDataSimulacionRetiroIn = this.getView().getModel("data").getProperty("/detMercaderia");
        var aDataSimulacionRetiro = [];

        // pasar los datos formateados a aDataPagosSimulados
        for (var line of aDataSimulacionRetiroIn) {
          aDataSimulacionRetiro.push([
            line.Vbeln,
            line.Arktx,
            formatter.importe(line.Netpr),
            line.Gueen.toLocaleDateString(),
            formatter.toneladas(line.Saldo) + " TN",
            formatter.importe(line.Valor)
          ])
        }
        var aHeadersSimulacionRetiro = [["Negocio", "Material", "Precio", "Fecha", "Saldo", "Valor"]];


        function obtenerImagen(sSvg) {
          //Create Canvas html Element to add SVG content
          var oCanvasHTML = document.createElement("canvas");
          canvg(oCanvasHTML, sSvg); // add SVG content to Canvas
          // Get dataURL for content in Canvas as PNG / JPEG
          return oCanvasHTML.toDataURL("image/png");
        }


        // Crear el PDF con jspdf
        var oFormat = {
          orientation: "p",
          unit: "mm",
          format: "a4",
          putOnlyUsedFonts: true
        };
        var oPDF = new jsPDF(oFormat);

        oPDF.setFontSize(15);
        oPDF.text(
          this.getView().getModel("data").getProperty("/tituloGraficoSaldo"), 10, 20);
        oPDF.addImage(obtenerImagen(sGraficoSaldo), "PNG", 10, 20, 180, 150);

        oPDF.text(
          this.getView().getModel("data").getProperty("/tituloGraficoCredito"), 10, 150);
        oPDF.addImage(obtenerImagen(sGraficoCredito), "PNG", 10, 150, 180, 150);

        // Simulaciones de pagos
        if (aDataPagosSimulados.length > 0) {
          // pasar a una nueva página
          oPDF.addPage();
          oPDF.text(this._oTextos.getText("simulador_pagos_titulo_pdf"), 10, 20);
          // Agregar tablas con plugin jspdf.autotable - simulación de pagos
          oPDF.autoTable({ head: aHeadersPagosSimulados, body: aDataPagosSimulados, startY: 25 });
        }


        // Simulaciones de retiros
        if (aDataSimulacionRetiro.length > 0) {
          // pasar a una nueva página
          oPDF.addPage();
          oPDF.text(this._oTextos.getText("simulador_retiros_titulo_pdf"), 10, 20);
          // Agregar tablas con plugin jspdf.autotable - simulación de retiros
          oPDF.autoTable({ head: aHeadersSimulacionRetiro, body: aDataSimulacionRetiro, startY: 25 });
        }

        var sFilename = this._oTextos.getText("export_filename", [this.getDateKey(new Date())]);
        oPDF.save(sFilename);

      },

      // /* Descargar imagen SVG generada por los gráficos */
      // saveSvg: function (sData, sFilename) {
      //   var preface = '<?xml version="1.0" standalone="no"?>\r\n';
      //   var svgBlob = new Blob([preface, sData], {
      //     type: "image/svg+xml;charset=utf-8"
      //   });
      //   var svgUrl = URL.createObjectURL(svgBlob);
      //   var downloadLink = document.createElement("a");
      //   downloadLink.href = svgUrl;
      //   downloadLink.download = sFilename;
      //   document.body.appendChild(downloadLink);
      //   downloadLink.click();
      //   document.body.removeChild(downloadLink);
      // },

    });
  }
);
