sap.ui.define([], function () {
	"use strict";
	return {

		importe: function (valor) {
			var oCurrency = new sap.ui.model.type.Currency({
				showMeasure: true,
				maxFractionDigits: 0,
				minFractionDigits: 0,
				// minFractionDigits: 2,
				// maxFractionDigits: 2,
				preserveDecimals: false
			});

			return oCurrency.formatValue([valor, "USD"], "string");

		},

		toneladas: function (valor) {
			var oValue = new sap.ui.model.type.Float({
				minFractionDigits: 0,
				maxFractionDigits: 0,
				preserveDecimals: false
				// minFractionDigits: 2,
				// maxFractionDigits: 2
			});

			return oValue.formatValue(valor, "string");

		},


		valueStateImportePago: function (valor) {
			if (!valor || isNaN(valor) || valor < 0) {
				return sap.ui.core.ValueState.Error;
			}
			return sap.ui.core.ValueState.None;
		},

		colorImporte: function (valor) {
			if (valor < 0) {
				return sap.ui.core.ValueState.Error;
			}
			return sap.ui.core.ValueState.Success;
		},

		colorImporteSaldo: function (valor) {
			if (valor > 0) {
				return sap.ui.core.ValueState.Error;
			}
			return sap.ui.core.ValueState.Success;
		},


		tipoMovimiento: function (tipo, descripcion) {


			const LINE_TYPES = {
				SALDO: 1,
				CHEQUE: 2,
				FIJACION_CEREAL: 3,
				ENTREGA_CEREAL: 4,
				// NEGOCIO: 5,
				SIMULACION_PAGO: 6,
				LINEA_CREDITO: 7,
				LIQUIDACION_CEREAL: 8,
				MERC_FACT_COMP: 9,
				MERC_FACT_NO_COMP: 10,
				MERC_NO_FACT_NO_COMP: 11
			}

			switch (tipo) {
				case 1:
					if (descripcion) {
						// return "Movimiento cuenta corriente (" + descripcion + ")";
						return descripcion;
					}
					return "Movimiento cuenta corriente";
				case 2: return "Cheque de pago diferido";
				case 3: return "Fijación de cereal";
				case 4: return "Entrega de cereal";
				case 5: return "Negocio";
				case 6: return "Simulación de pago";
				case 7: return "Línea de crédito disponible";
				case 8: return "Liquidación de cereal";
				case 9:
				case 10:
				case 11: return "Simulación retiro fertilizante";
				default: return "Otros"
			}
		}
	};
});