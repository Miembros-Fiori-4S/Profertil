sap.ui.define([
  "profertil/CotizacionesDealer/controller/BaseController",
  "sap/ui/core/Fragment",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox"
], function (Controller, Fragment, JSONModel, MessageBox) {
  "use strict";

  return Controller.extend("profertil.CotizacionesDealer.controller.NegocioForm", {
    onInit: function () {
      this.getView().setBusy(true);

      this._fragmentLoaded = false;
      this._formFragments = {};
      this._mode = "";

      var UIModel = new JSONModel({
        saveButtonVisible: false,
        cancelButtonVisible: false,
        editButtonVisible: false,
      });

      this.getView().setModel(UIModel, "UI");

      this.getRouter().getRoute("neg-form").attachPatternMatched(this._onObjectMatched, this);
    },

    handleEditPress: function () {
      this._toggleEditView(true);
    },

    handleCancelPress: function () {
      this._toggleEditView(false);
    },

    handleSavePress: function () {
      var oObject = this.getView().getBindingContext().getObject();

      // mover los campos actualizables
      var data = {
        Negocio: oObject.Negocio,
        Estado: "SAP",
        EstadoTexto: "Negocio SAP",
        Incoterm: oObject.Incoterm,
        Incoterm2: oObject.Incoterm2,
        Modalidad: oObject.Modalidad,
        ModalidadTexto: oObject.ModalidadTexto,
        Negocio: oObject.Negocio,
        Precio: oObject.Precio,
        Presentacion: oObject.Presentacion,
        PresentacionTexto: oObject.PresentacionTexto,
        EntregaFin: oObject.EntregaFin,
        EntregaInicio: oObject.EntregaInicio,
        FechaPago: oObject.FechaPago,
        Centro: oObject.Centro,
        FechaPago: oObject.FechaPago,
        Cantidad: oObject.Cantidad,
        Financiado: oObject.Financiado === "true",
        TasaInteres: oObject.TasaInteres,
        Comentario: oObject.Comentario
      };

      this._updateData(data, this._id);
    },

    onPressComposicion: function () {
      if (!this._oDialog) {
        this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "profertil.CotizacionesDealer.view.ComposicionDisplay", this);
        this.getView().addDependent(this._oDialog);
      }

      this._oDialog.open();

      this._bindComposicionTable();
    },

    onCloseComposicionDialog: function () {
      this._oDialog.close();
    },

    formatDateStr: function (date) {
      var oDate = new Date(date);

      let day = oDate.getDate();
      let month = oDate.getMonth() + 1;
      let year = oDate.getFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    _toggleEditView: function (bEdit) {
      var oModel = this.getView().getModel("UI");
      var fragmentName;
      if (bEdit) {
        fragmentName = "EditNegocio";

        // poner 2 decimales      
        var oDataModel = this.getView().getModel();
        var oObject = this.getView().getBindingContext().getObject();
        var sPath = this.getView().getBindingContext().sPath;
        if (oModel && oObject) {
          var precio = oObject.Precio;
          oDataModel.setProperty(sPath + "/Precio", parseFloat(precio).toFixed(2));
          var cantidad = oObject.Cantidad;
          oDataModel.setProperty(sPath + "/Cantidad", parseFloat(cantidad).toFixed(2));
        }


      }
      else {
        fragmentName = "DisplayNegocio";
      }

      this._showFormFragment(fragmentName);

      oModel.setProperty("/saveButtonVisible", bEdit);
      oModel.setProperty("/cancelButtonVisible", bEdit);
      oModel.setProperty("/editButtonVisible", !bEdit);
    },

    _getFormFragment: function (sFragmentName) {
      var pFormFragment = this._formFragments[sFragmentName],
        oView = this.getView();

      if (!pFormFragment) {
        pFormFragment = Fragment.load({
          id: this.getView().getId(),
          name: "profertil.CotizacionesDealer.view." + sFragmentName,
          controller: this
        });
        this._formFragments[sFragmentName] = pFormFragment;
      }

      return pFormFragment;
    },

    // _showFormFragment: function (sFragmentName) {
    //   var oPage = this.byId("neg-form-page");

    //   oPage.removeAllContent();
    //   this._getFormFragment(sFragmentName).then((oVBox) => {
    //     oPage.insertContent(oVBox);
    //   }).then(() => {
    //     this._fragmentLoaded = true;
    //   });
    // },


    _showFormFragment: function (sFragmentName) {
      var oPage = this.byId("neg-form-page");

      oPage.removeAllContent();

      this._getFormFragment(sFragmentName)
        .then((oVBox) => {
          this._formFragment = oVBox;
          oPage.insertContent(oVBox);
        }).then(() => {
          // var dataModel = this.getView().getModel("Cotizacion");
          // var uiModel = this.getView().getModel("UI");

          // if (sFragmentName === "EditNegocio") {
          //   var zonaKey = dataModel.getData().Zona;

          //   this._activateClientCB(zonaKey);
          //   this._setValidityDate();
          // }
        });
    },

    // _showEditView: function () {
    //   this._setTempModel();

    //   this.getView().getModel("UI").setProperty("/editView", true);

    //   this._convert = false;

    //   this._showForm("EDIT");
    // },


    _bindComposicionTable: function () {
      var oTable = this.byId("comp-list");

      var id = this.getView().getBindingContext().getObject().Id;

      oTable.unbindItems();
      oTable.bindItems("/CotizacionSet('" + id + "')/ComposicionSet",
        new sap.m.StandardListItem({
          title: '{ProductoTexto}',
          info: '{Porcentaje}'
        })
      );
    },

    _onObjectMatched: function (oEvent) {
      var id = oEvent.getParameter("arguments").objectId;
      var status = oEvent.getParameter("arguments").status;

      if (id) {
        this._bindView(id);
        this._id = id;
      }

      this._mode = oEvent.getParameter("arguments").mode;

      if (!this._fragmentLoaded) this._showFormFragment("DisplayNegocio");

      this._toggleEditView(false);

      this.getView().setBusy(false);
    },

    _formatDate: function (date) {
      let day = date.getDate();
      let month = date.getMonth() + 1;
      let year = date.getFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },


    onSelectDeliveryType: function (oEvent) {
      if (oEvent.getParameter("newValue") === "DEL") {
        this.byId("localidad-field").setEnabled(true);
      } else {
        this.byId("localidad-field").setEnabled(false);
        this.byId("localidad-field").setValue("");
      }
    },

    _updateData: function (oData, key) {
      var bError = this._onSubmitCheck();

      if (bError) {
        return MessageBox.error("Por favor, complete todos los campos.");
      }

      var oModel = this.getView().getModel();

      this.getView().setBusy(true);

      oData.Id = key;

      oModel.setUseBatch(false);

      oModel.update("/CotizacionSet('" + key + "')", oData, {
        success: function () {
          this.getView().setBusy(false);

          MessageBox.success("El negocio se ha actualizado con éxito.", {
            onClose: (oAction) => {
              if (oAction == "OK") this._toggleEditView(false);
            }
          });
        }.bind(this),
        error: function () {
          this.getView().setBusy(false);

          MessageBox.error("Se ha producido un error.");
        }.bind(this)
      });
    },

    _onSubmitCheck: function () {
      var oForm = this.byId("data-form--display").getFormContainers()[0].getFormElements();

      var bError = false;

      oForm.forEach(field => {
        if (typeof field.getFields()[0].getValue === "function" && field.getVisible()) {
          if (!field.getFields()[0].getValue() || field.getFields()[0].getValue().length < 1) {
            field.getFields()[0].setValueState("Error");

            bError = true;
          } else {
            field.getFields()[0].setValueState("None");
          }
        }
      });

      return bError;
    },

    _bindView: function (id) {
      var oView = this.getView();

      var sObjectPath = this.getModel().createKey("CotizacionSet", {
        Id: id
      });

      oView.bindElement("/" + sObjectPath);
    }
  });
});