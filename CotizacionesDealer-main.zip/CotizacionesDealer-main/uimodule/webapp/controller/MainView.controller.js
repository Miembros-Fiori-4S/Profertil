sap.ui.define([
  "profertil/CotizacionesDealer/controller/BaseController",
  'sap/ui/core/Fragment',
  'sap/ui/model/json/JSONModel',
  "sap/ui/model/Filter",
  "sap/ui/export/Spreadsheet"
], function (Controller, Fragment, JSONModel, Filter, Spreadsheet) {
  "use strict";

  return Controller.extend("profertil.CotizacionesDealer.controller.MainView", {
    onInit: function () {
      var oModel = this.getView().getModel();

      this.getRouter().getRoute("MainView").attachPatternMatched(this._onObjectMatched, this);
    },

    onAfterRendering: function () {
      this._filterTable(this.byId("iconTabBar").getSelectedKey());
    },

    onPressListItem: function (oEvent) {
      this._showForm("Display", oEvent.getSource());
    },

    onPressCreate: function (oEvent) {
      this.getRouter().navTo("create");
    },

    onSearch: function (oEvent) {
      var sKey = this.byId("iconTabBar").getSelectedKey();

      this._filterTable(sKey);
    },

    onSelectIconTab: function (oEvent) {
      var sKey = oEvent.getParameter("selectedKey");

      this._filterTable(sKey);
    },

    formatDate(date) {
      var oDate = new Date(date);

      let day = oDate.getDate();
      let month = oDate.getMonth() + 1;
      let year = oDate.getFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    _filterTable: function (sKey) {
      var aFilters = [];
      var tableHeader = this.byId("tableHeader");

      this.getView().setBusy(true);

      switch (sKey) {
    
        case "negocios":
          aFilters.push(new Filter("Estado", "EQ", "NEG"));
          tableHeader.setText("Negocios");
          break;
        case "negociossap":
          aFilters.push(new Filter("Estado", "EQ", "SAP"));
          tableHeader.setText("Negocios SAP");
          break;
        default:
          break;
      }

      var searchValue = this.byId("searchField").getValue();
      aFilters.push(new Filter("ClienteNombre", "Contains", searchValue));

      var oBinding = this.byId("table").getBinding("items");

      oBinding.filter(aFilters);

      this.getView().setBusy(false);
    },

    _showForm: function (mode, oItem) {
      if (oItem) {
        var status = oItem.getSelectedItem().getBindingContext().getProperty("Estado");
        var route = status === "COT" ? "form" : "neg-form";

        if (status === "COT") {
          this.getRouter().navTo(route, {
            objectId: oItem.getSelectedItem().getBindingContext().getProperty("Id")
          });
        } else {
          this.getRouter().navTo(route, {
            mode: mode,
            objectId: oItem.getSelectedItem().getBindingContext().getProperty("Id"),
            status: status
          });
        }
      }
    },

    _getSemanaPasada: function () {
      var aDates = [];
      var oDate = new Date();

      oDate.setDate(oDate.getDate() - 7);

      aDates.push(this._getNextDayOfWeek(oDate, 4));

      oDate.setDate(oDate.getDate() - 7);

      aDates.push(this._getNextDayOfWeek(oDate, 4));

      return aDates;
    },

    _getNextDayOfWeek: function (date, dayOfWeek) {
      var resultDate = new Date(date.getTime());

      resultDate.setDate(date.getDate() + (7 + dayOfWeek - date.getDay()) % 7);

      return resultDate;
    },

    _onObjectMatched: function (oEvent) {
      var oTable = this.byId("table");
      oTable.removeSelections();
    },

    onPressDownloadExcel: function () {

      var oTable = this.getView().byId("table");
      var key = this.getView().byId("iconTabBar").getSelectedKey();
      var fileName;
      switch (key) {
        case "negocios": fileName = "Negocios"; break;
        case "negociossap": fileName = "Negocios SAP"; break;
        default: fileName = "Cotizaciones";
      }
      var aCols = [{
        property: "Fecha",
        label: "Fecha",
        type: "datetime"
      }, {
        property: "ClienteNombre",
        label: "Cliente",
        type: "string"
      }, {
        property: "ProductoTexto",
        label: "Producto",
        type: "string"
      }, {
        property: "Centro",
        label: "Centro",
        type: "string"
      }, {
        property: "Zona",
        label: "Zona",
        type: "string"
      }, {
        property: "Precio",
        label: "Precio",
        type: "number"
      }, {
        property: "Cantidad",
        label: "Cantidad",
        type: "number"
      }, {
        property: "Negocio",
        label: "Negocio",
        type: "string"
      }];

      var aKeys = oTable.getBinding("items").aKeys;
      var aDatos = [];
      for (var a in aKeys) {
        var oDatos = this.getView().getModel().getObject("/" + aKeys[a]);
        aDatos.push(oDatos);
      }

      var oSettings = {
        workbook: {
          columns: aCols
        },
        dataSource: aDatos,
        worker: false,
        fileName: fileName,
        showProgress: false
      };
      new Spreadsheet(oSettings).build().then(function () {
        sap.m.MessageToast.show("Descargado correctamente");
      });


    }
  });
});
