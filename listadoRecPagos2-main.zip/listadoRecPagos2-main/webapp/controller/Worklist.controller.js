sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("profertil.listareclamos2.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {
			var oViewModel;
		    //var iOriginalBusyDelay;
			oViewModel = new JSONModel({});
			this.setModel(oViewModel, "worklistView");
            this.setRepoUrl();
            
        },
        
        setRepoUrl: function () {
            var oModel = this.getManifestModel("AppModel");            
            this.getData("")
                .then(response => {
                    var repos = Object.keys(response).filter(repo => response[repo].repositoryName == "INFORME_PAGOS");
                    var root = repos[0] + "/root";
                    var url = this.getDMSUrl("/SDM_API/browser/" + root);
                    this._dmsUrl = url;
                    oModel.setProperty("/url", url);
                    oModel.setProperty("/repoId", repos[0]);
                    oModel.setProperty("/rootId", response[repos[0]].rootFolderId);

                });
                
        },

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

		/**
		 * Event handler when a table item gets pressed
		 * @param {sap.ui.base.Event} oEvent the table selectionChange event
		 * @public
		 */
		onPress : function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
		},

		/**
		 * Event handler for navigating back.
		 * We navigate back in the browser history
		 * @public
		 */
		onNavBack : function() {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
        },
        
        /**
		 * Shows the selected item on the object page
		 * On phones a additional history entry is created
		 * @param {sap.m.ObjectListItem} oItem selected Item
		 * @private
		 */
		_showObject : function (oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Id")
			});
        },
        
        handlechangeEstado: function (oEvent) {
            //if (this.getView().byId("stListado")) {
            //    this.getView().byId("stListado").rebindTable();
            //}

        },

        handlechangeZona: function (oEvent) {
            //if (this.getView().byId("stListado")) {
            //    this.getView().byId("stListado").rebindTable();
            //}

        },

        onBeforeRebindTable: function (oEvent) {
            var mBindingParams = oEvent.getParameter("bindingParams");
            var oSmtFilter = this.getView().byId("smartFilterBar");
            
            var aFilters = [];
            var aFilters = mBindingParams.filters;

            //Custom Filters
            var sEstado = oSmtFilter.getControlByKey("Estado").getSelectedKey();
            var sZona = oSmtFilter.getControlByKey("Zona").getSelectedKey();
            
            if (sEstado) {
                var oEstadoFilter = new Filter("Estado", FilterOperator.EQ, sEstado);
                aFilters.push(oEstadoFilter);
            }
            
            if (sZona) {
                var oZonaFilter = new Filter("Zona", FilterOperator.EQ, sZona);
                aFilters.push(oZonaFilter);
            }

            mBindingParams.filters = aFilters;

            if (!mBindingParams.sorter.length){
                mBindingParams.sorter.push(new sap.ui.model.Sorter("Credat", true));
                mBindingParams.sorter.push(new sap.ui.model.Sorter("Id", true))
            }

            
        }


	});
});


