sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"sap/ui/core/routing/History",
	"../model/formatter",
    "sap/ui/core/library"
], function (BaseController, JSONModel, History, formatter, coreLibrary) {
	"use strict";

	return BaseController.extend("profertil.listareclamos2.controller.Object", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {
			// Model used to manipulate control states. The chosen values make sure,
			// detail page is busy indication immediately so there is no break in
			// between the busy indication for loading the view's meta data
			var iOriginalBusyDelay;
			var oViewModel = new JSONModel({
					busy : true,
                    delay : 0,
                    bztxt : ""
				});

            

			this.getRouter().getRoute("object").attachPatternMatched(this._onObjectMatched, this);

			// Store original busy indicator delay, so it can be restored later on
			iOriginalBusyDelay = this.getView().getBusyIndicatorDelay();
			this.setModel(oViewModel, "objectView");
			this.getOwnerComponent().getModel().metadataLoaded().then(function () {
					// Restore original busy indicator delay for the object view
					oViewModel.setProperty("/delay", iOriginalBusyDelay);
				}
            );
            
            //this.createAdjuntosModel();
			this.createViewModel();

        },
        

        createViewModel: function () {
			this.getView().setModel(
				new JSONModel({
				  _input2: false,
				  _input3: false,
				  _input4: false,
				  _input5: false,
				  _input6: false,
				  _input7: false,
				  _input8: false,
                  _input9: false,
                  _input21: false,
                  _input22: false,
				  resueltoVisible: false,
				  pendienteVisible: false,
				}),
				"view"
			  );

		},

		createAdjuntosModel: function () {
			var oAdjuntosModel = new JSONModel({
				adjuntos: [
                    {objectId: "000",fileName: "No se encotraron Adjuntos"}
                ]
			});
			this.getView().setModel(oAdjuntosModel, "adjuntosModel");

		},

		/* =========================================================== */
		/* event handlers                                              */
		/* =========================================================== */

        onAdjuntoPress: function (oEvent) {
			var sUrl = oEvent.getParameter("item").getBindingContext("adjuntosModel").getProperty("url");
            if (sUrl !== "") {
                window.open(sUrl, "_blank");
            }

		},

		onResuelto: function () {
            var sResolucion = this.byId("_textArea").getValue();
            var sPath = this.getView().getBindingContext().sPath;
            var oEntry = {};
            oEntry.Estado = 'R';
            oEntry.Resolucion = sResolucion;
            this.updateStatus(sPath, oEntry);
            
		},

		onPendiente: function () {
            var sResolucion = this.byId("_textArea").getValue();
            var sPath = this.getView().getBindingContext().sPath;
            var oEntry = {};
            oEntry.Estado = 'P';
            oEntry.Resolucion = sResolucion;
            this.updateStatus(sPath, oEntry);
            
        },
        
        onLeido: function (sBack) {
            var sEstado = this.getView().getBindingContext().getObject().Estado;
            if (sEstado === "N") {
                var sPath = this.getView().getBindingContext().sPath;
                var oEntry = {};
                oEntry.Estado = 'P';
                if (sBack === "") {
                    this.updateStatus(sPath, oEntry); // update and back
                } else {
                    this.updateStatus2(sPath, oEntry); // update without back
                }
            }

        },

		onAtras: function () {
            var sEstado = this.getView().getBindingContext().getObject().Estado;
            if (sEstado === "N") {
                this.onLeido("");
            } else {
                this.onNavBack();
            }
            
		},

        updateStatus2: function (sPath, oEntry) {
            var oModel = this.getView().getModel();
            oModel.setUseBatch(false);
            var that = this;
            oModel.update(sPath, oEntry, {
                success: function (oData) {
                    sap.m.MessageToast.show("Reclamo Actualizado");
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Surgieron errores al actualizar el reclamo, intentelo mas tarde");
                },
                refreshAfterChange: true
            });

        },

        updateStatus: function (sPath, oEntry) {
            var oModel = this.getView().getModel();
            oModel.setUseBatch(false);
            var that = this;
            oModel.update(sPath, oEntry, {
                success: function (oData) {
                    sap.m.MessageToast.show("Reclamo Actualizado");
                    that.onNavBack();
                },
                error: function (oError) {
                    sap.m.MessageToast.show("Surgieron errores al actualizar el reclamo, intentelo mas tarde");
                    that.onNavBack();
                },
                refreshAfterChange: true
            });

        },

        initFormFields: function () {
            var oContext = this.getView().getBindingContext();
            var sResolucion = oContext.getObject().Resolucion;
            var sValue = this.byId("_textArea").getValue();
            if (sResolucion !== sValue) {
                this.byId("_textArea").setValue(sResolucion);
            }

            var Zona = oContext.getObject().Zona;
            this.readZonaDescription(Zona);
            
        },

        readZonaDescription: function (sZona) {
            this.getView().getModel("objectView").setProperty("/bztxt", "");
            if (sZona === "") {
                return;
            }

            //var sPath = "/ZonasSet('" + sZona + "')";
            var sPath = "/ZonasSet";
            var that = this;
            this.getView().getModel().read(sPath, {
                success: function (oData) {
                    var aResults = [];
                    var aResults = oData.results;
                    for(let i=0; i < aResults.length; i++) {
                        if (aResults[i].Key === sZona) {
                            that.getView().getModel("objectView").setProperty("/bztxt", aResults[i].Value);
                            break;
                        }
                    }
                    
                },
                error: function (oError) {
                    that.getView().getModel("objectView").setProperty("/bztxt", "");
                }

            });

        },

        readAttachments: function () {
            this.byId("adjuntosListID").setBusy(true);
            var oReclamo = this.getView().getBindingContext().getObject();
            var sReclamo = oReclamo.Id;
            var sCliente = oReclamo.Nrocliente;
            var aAdjuntos = [];
            var oModel = this.getManifestModel("AppModel"); 
            var oData = oModel.getData();
            var sUrlFolder = "";
            if (sCliente !== "") {
                sUrlFolder = oData.repoId + "/root" + "/" + sCliente + "/" + sReclamo;
            } else {
                sUrlFolder = oData.repoId + "/root" + "/" + sReclamo;
            }
            
            var that = this;
            this.getData(sUrlFolder)
                .then(response => {
                    aAdjuntos = that.getAdjuntos(response);
                    //that.setStatusAdjuntos(aAdjuntos);
                    if (aAdjuntos.length === 0) {
                        aAdjuntos = [{"filename": "No se encontraron Adjuntos", "url": "", "objectId": ""}];
                    }
                    that.getView().getModel("adjuntosModel").setProperty("/adjuntos", aAdjuntos);
                }).catch(oError => {
                    //that.setStatusAdjuntos(aAdjuntos);
                    aAdjuntos = [{"filename": "No se encontraron Adjuntos", "url": "", "objectId": ""}];
                    that.getView().getModel("adjuntosModel").setProperty("/adjuntos", aAdjuntos);
                    that.byId("adjuntosListID").setBusy(false);
                });

        },

        getAdjuntos: function (oResponse) {
            var aAdjuntos = [];
            for(var i=0; i < oResponse.objects.length; i++) {
                var oFolderContent = {};
                oFolderContent = oResponse.objects[i].object.properties;
                var oAdjunto = {};
                oAdjunto = this.getAdjuntoProperties(oFolderContent);                
                aAdjuntos.push(oAdjunto);
            }
            this.byId("adjuntosListID").setBusy(false);
            return aAdjuntos;

        },

        getAdjuntoProperties: function (oFolderContent) {
            var oAdjunto = {};
            oAdjunto.objectId = oFolderContent["cmis:objectId"].value;
            oAdjunto.filename = oFolderContent["cmis:name"].value;
            oAdjunto.url = this.getDMSUrl("/SDM_API/browser") + "/" + this.getManifestModel("AppModel").getData().repoId + "/root" + "?objectId=" + oAdjunto.objectId + "&cmisSelector=content&download=attachment&filename=" + oAdjunto.filename;
            return oAdjunto;

        },

		/**
		 * Event handler  for navigating back.
		 * It there is a history entry we go one step back in the browser history
		 * If not, it will replace the current entry of the browser history with the worklist route.
		 * @public
		 */
		onNavBack : function() {
			var sPreviousHash = History.getInstance().getPreviousHash();

			if (sPreviousHash !== undefined) {
				history.go(-1);
			} else {
				this.getRouter().navTo("worklist", {}, true);
			}
		},

        campoVisibility: function () {
			var oModel = this.getView().getModel("view");
			var sTipopago = this.getView().getBindingContext().getObject().Tipopago;
			  switch (sTipopago) {
				case 'Transferencia':
                  oModel.setProperty("/_input2", true);	  
                  
				  oModel.setProperty("/_input3", false);
				  oModel.setProperty("/_input4", false);
				  oModel.setProperty("/_input5", false);
				  oModel.setProperty("/_input6", false);
				  oModel.setProperty("/_input7", false);
				  oModel.setProperty("/_input9", false);
                  oModel.setProperty("/_input8", false);
                  oModel.setProperty("/_input21", false);
                  oModel.setProperty("/_input22", false);
				  break;
				case 'Depósito':
				  oModel.setProperty("/_input3", true);
                  oModel.setProperty("/_input4", true);	  
                  
				  oModel.setProperty("/_input2", false);
				  oModel.setProperty("/_input5", false);
				  oModel.setProperty("/_input6", false);
				  oModel.setProperty("/_input7", false);
				  oModel.setProperty("/_input9", false);
                  oModel.setProperty("/_input8", false);
                  oModel.setProperty("/_input21", false);
                  oModel.setProperty("/_input22", false);
				  break;
				case 'Cheque':
                  oModel.setProperty("/_input4", true);	  
                  
				  oModel.setProperty("/_input2", false);
				  oModel.setProperty("/_input3", false);
				  oModel.setProperty("/_input5", false);
				  oModel.setProperty("/_input6", false);
				  oModel.setProperty("/_input7", false);
				  oModel.setProperty("/_input9", false);
                  oModel.setProperty("/_input8", false);
                  oModel.setProperty("/_input21", false);
                  oModel.setProperty("/_input22", false);
				  break;
				case 'Cupón tarjeta':
				  oModel.setProperty("/_input5", true);
                  oModel.setProperty("/_input9", true);	 
                   
				  oModel.setProperty("/_input2", false);
				  oModel.setProperty("/_input3", false);
				  oModel.setProperty("/_input4", false);
				  oModel.setProperty("/_input6", false);
				  oModel.setProperty("/_input7", false);
                  oModel.setProperty("/_input8", false);
                  oModel.setProperty("/_input21", false);
                  oModel.setProperty("/_input22", false);
				  break;
				case 'Retención':
				  oModel.setProperty("/_input6", true);
                  oModel.setProperty("/_input7", true);	 
                   
				  oModel.setProperty("/_input2", false);
				  oModel.setProperty("/_input3", false);
				  oModel.setProperty("/_input4", false);
				  oModel.setProperty("/_input5", false);
				  oModel.setProperty("/_input9", false);
                  oModel.setProperty("/_input8", false);
                  oModel.setProperty("/_input21", false);
                  oModel.setProperty("/_input22", false);
				  break;
				case 'Factura como':
                  oModel.setProperty("/_input8", true);	
                  			  
				  oModel.setProperty("/_input2", false);
				  oModel.setProperty("/_input3", false);
				  oModel.setProperty("/_input4", false);
				  oModel.setProperty("/_input5", false);
				  oModel.setProperty("/_input6", false);
				  oModel.setProperty("/_input7", false);
                  oModel.setProperty("/_input9", false);
                  oModel.setProperty("/_input21", false);
                  oModel.setProperty("/_input22", false);
                  break;
                case 'Liquidacion Canje':
                    oModel.setProperty("/_input21", true);
                    oModel.setProperty("/_input22", true);
                    			  
                    oModel.setProperty("/_input2", false);
                    oModel.setProperty("/_input3", false);
                    oModel.setProperty("/_input4", false);
                    oModel.setProperty("/_input5", false);
                    oModel.setProperty("/_input6", false);
                    oModel.setProperty("/_input7", false);
                    oModel.setProperty("/_input8", false);	
                    oModel.setProperty("/_input9", false);
                    break;
				default:
				  break;
			  }
			},
	  
			handleButtonVisibility: function () {
			  var oModel = this.getView().getModel("view");
			  var sEstado = this.getView().getBindingContext().getObject().Estado;
				switch (sEstado) {
				  case 'R':
					oModel.setProperty("/resueltoVisible",false);
					oModel.setProperty("/pendienteVisible",true);
					break;
				  case 'N':
					oModel.setProperty("/resueltoVisible",true);
					oModel.setProperty("/pendienteVisible",false);
					break;
				  case 'P':
					oModel.setProperty("/resueltoVisible",true);
					oModel.setProperty("/pendienteVisible",false);
					break;
				  default:
					break;
				}
			},

		/* =========================================================== */
		/* internal methods                                            */
		/* =========================================================== */

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
		 * @private
		 */
		_onObjectMatched : function (oEvent) {
            this.createAdjuntosModel();
			var sObjectId =  oEvent.getParameter("arguments").objectId;
			this.getModel().metadataLoaded().then( function() {
				var sObjectPath = this.getModel().createKey("InformeSet", {
					Id :  sObjectId
				});
				this._bindView("/" + sObjectPath);
			}.bind(this));
		},

		/**
		 * Binds the view to the object path.
		 * @function
		 * @param {string} sObjectPath path to the object to be bound
		 * @private
		 */
		_bindView : function (sObjectPath) {
			var oViewModel = this.getModel("objectView"),
				oDataModel = this.getModel();

			this.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							oViewModel.setProperty("/busy", true);
						});
					},
					dataReceived: function () {
						oViewModel.setProperty("/busy", false);
					}
				}
			});
		},

		_onBindingChange : function () {
			var oView = this.getView(),
				oViewModel = this.getModel("objectView"),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.getRouter().getTargets().display("objectNotFound");
				return;
			}
			//var oObject = oView.getBindingContext().getObject();
            this.campoVisibility();
            this.handleButtonVisibility();
            this.initFormFields();
            this.readAttachments();
            this.onLeido("X"); 
            oViewModel.setProperty("/busy", false);
            
		},

		handleLiveChange: function (oEvent) {

            var ValueState = coreLibrary.ValueState;

			var oTextArea = oEvent.getSource(),
				iValueLength = oTextArea.getValue().length,
				iMaxLength = oTextArea.getMaxLength(),
				sState = iValueLength > iMaxLength ? ValueState.Error : ValueState.None;

			oTextArea.setValueState(sState);
		},        

	});

});