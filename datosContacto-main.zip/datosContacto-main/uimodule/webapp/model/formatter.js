sap.ui.define([], function () {
    "use strict";
    return {

    formatName: function (str) {
			var sReturn = str;
			try {
				sReturn = str.replace(
					/\w\S*/g,
					function (txt) {
						return txt.substr(0).toUpperCase();
					}
				);
			} finally {
				return sReturn;
			}
    },

    formatMail: function (str) {
			var sReturn = str;
			try {
				sReturn = str.replace(
					/\w\S*/g,
					function (txt) {
						return txt.substr(0).toLowerCase();
					}
				);
			} finally {
				return sReturn;
			}
    },
    
    tipoContacto: function (sContacto) {
			switch (sContacto) {
        case "CONF_ENTREGA":
          return "ENTREGAS";
        case "CONF_PEDIDO":
          return "PEDIDOS";
        case "CONF_FACTURA":
          return "FACTURAS";
        case "NOTIF_RECIBOS_ZF48":
          return "RECIBOS";
        case "ZAR01_DEUDAS":
          return "COMPENSACIONES Y ESTADO DE CUENTA";
        case "ZSD100_BLOQUEOS":
          return "BLOQUEO CUPOS";
        case "ZF96_CREDITOS":
          return "RECLAMO DE BALANCES";
			}
    },
    
    esEstandar: function (sEstandar) {
			switch (sEstandar) {
        case "X":
          return "SI";
        case "":
          return "NO";
			}
    },

    };
});
