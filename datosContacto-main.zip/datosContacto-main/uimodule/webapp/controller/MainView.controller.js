sap.ui.define([
  "profertil/datosClientes/controller/BaseController",
  'sap/ui/model/json/JSONModel',
  'sap/ui/core/Fragment',
	"sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageBox",
  "sap/ui/model/FilterType"
], function (Controller, JSONModel, Fragment, Filter, FilterOperator, MessageBox, FilterType) {
    "use strict";
    var oController;
    var oKunnr = "";
  return Controller.extend("profertil.datosClientes.controller.MainView", {
    onInit: function () {
      oController = this;

      //this.Kunnr = '0000100541';
      

      this.getView().setModel(
          new JSONModel({
            showContactoTelefono: false,
            showContactoMail: false,
            showFMails: false,
            showFNombreTelefono: false
          }),
          "view"
      );

      var oTableModel = new JSONModel({
        //Kunnr: "1",
        Telefonos: [],
        Mails: [],
        Name1: "",
        Stras: "",
        Land1: "",
        Ort01: "",
        Pstlz: "",
        Regio: "",
        Brsch: "",
        Bezei: "",
        Landx: ""
      });
      
      this.setModel(oTableModel, "tabla");
      
      //var sPath = '/ClientesSet',
      //    sKey = this.getModel().createKey(sPath, {
      //      Kunnr: "1"
      //    });

      var sKey = "/ClientesSet('1')";
      this.getModel().read(sKey, {
          success: function (oData) {
            this.getView().getModel("tabla").setProperty("/Kunnr", oData.Kunnr);
            this.getView().getModel("tabla").setProperty("/Name1", oData.Name1);
            this.getView().getModel("tabla").setProperty("/Stras", oData.Stras);
            this.getView().getModel("tabla").setProperty("/Land1", oData.Land1);   
            this.getView().getModel("tabla").setProperty("/Ort01", oData.Ort01); 
            this.getView().getModel("tabla").setProperty("/Pstlz", oData.Pstlz); 
            this.getView().getModel("tabla").setProperty("/Regio", oData.Regio);  
            this.getView().getModel("tabla").setProperty("/Brsch", oData.Brsch);   
            this.getView().getModel("tabla").setProperty("/Landx", oData.Landx);  
            this.getView().getModel("tabla").setProperty("/Bezei", oData.Bezei); 
              oTableModel.setProperty("/Direccion", oTableModel);
              oKunnr = oData.Kunnr;
              this.fetchMailsSet(oData.Kunnr);
              this.fetchTelefonosSet(oData.Kunnr);
					}.bind(this),
					error: function (error) {
						sap.m.MessageToast.show("Error");
						  oTableModel.setProperty("/Direccion");
					}
      })

      //Setting Selections
			this.oSelectCMail = this.byId("_contactoMail");
			this.oSelectCTel = this.byId("_contactoTelefono");

			//Setting Keys
			/*this.aKeys = [
				"cMail", "cTel"
			];*/
    
      //this.fetchTelefonosSet(this.filtrar());

      //this.fetchMailsSet(this.filtrar());

      this.oSContactoTelefono = this.byId("_contactoTelefono");
      this.oSContactoMail = this.byId("_contactoMail");
      this.initFragments();

    },

    onLiveMailSearch: function (oEvent) {
      var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Mail", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			var oTableMails = this.byId("tableMails");
			var oBinding = oTableMails.getBinding("items");
			oBinding.filter(aFilters, "Application");

    },

    onLiveTelNombreSearch: function (oEvent) {
      var aFilters = [];
			var sQuery = oEvent.getSource().getValue();
			if (sQuery && sQuery.length > 0) {
				var filter = new Filter("Comentario", FilterOperator.Contains, sQuery);
				aFilters.push(filter);
			}
			var oTableMails = this.byId("tableTelefonos");
			var oBinding = oTableMails.getBinding("items");
			oBinding.filter(aFilters, "Application");

    },

    filtrar: function (){
      var aFilters = [],
          Kunnr = oKunnr;

      aFilters.push(new Filter("Kunnr", FilterOperator.EQ, Kunnr));
      return aFilters;
    },

    onSearch: function (oEvent) {
			// Si el filtro es en vista
			var bView = true;
      var aFilters = this.getAllFilters(bView);
      
      var oTable = this.getCorrespondingTable();
			var oBinding = oTable.getBinding("items");
			oBinding.filter(aFilters, "Application");
    },
    
    onSearchNombre: function (oEvent) {
      var sName = oEvent.getSource().getValue();
      var oFilter = new Filter("Comentario", FilterOperator.Contains, sName);

			  if (sName.length > 0) {
					aFilters.push(new Filter("Comentario", FilterOperator.Contains, sName));
				}				
    },

    getAllFilters: function (bView) {
			var sContactoMail,
				  sContactoTelefono;

      var aFilters = [];
      

      if (this.byId("iconTabBar").getSelectedKey() == 'Telefono'){
				  sContactoTelefono = this.oSelectCTel.getSelectedKey();
          if (sContactoTelefono.length > 2 && bView) {
            aFilters.push(new Filter("Extension", FilterOperator.EQ, sContactoTelefono));
          }
        }else{
          sContactoMail = this.oSelectCMail.getSelectedKey();
          if (sContactoMail.length > 2 && bView) {
            aFilters.push(new Filter("Comentario", FilterOperator.EQ, sContactoMail));
          }
        }

      return aFilters;
    },
    
    getTable: function () {
			return this.byId("tableTelefonos");
		},

		getCorrespondingTable: function () {
			var sKey = this.byId("iconTabBar").getSelectedKey();

			return sKey === "Telefono" ? this.getTable() : this.getTableMail();
    },
    
    getTableMail: function () {
			return this.byId("tableMails");
		},
    
    /**
		 * Convenience method for fetching Teléfonos
		 * @param {[sap.ui.model.filters]} aFilters the filters
		 * @public
		 */
		fetchTelefonosSet: function (sKunnr) {
			var oModel = this.getModel(),
          oTableModel = this.getModel("tabla"),
          oTable = this.byId("tableTelefonos");

      oTable.setBusy(true);
      
      var aFilters = [];

      aFilters.push(new Filter("Kunnr", FilterOperator.EQ, sKunnr));
      aFilters.push(new Filter({
        filters: [
          new Filter("Extension", FilterOperator.EQ, "COMERCIAL"),
          new Filter("Extension", FilterOperator.EQ, "CREDITOS"),
          new Filter("Extension", FilterOperator.EQ, "LOGISTICO")
        ],
        and: false
      }));
			
			setTimeout(function () {

				oModel.read("/TelefonosSet", {
					filters: aFilters,
					success: function (oData, oResponse) {
						//Seteo la tabla
						oTableModel.setProperty("/Telefonos", oData.results);
  					//Dejo de cargar
						oTable.setBusy(false);
					}.bind(this),
					error: function (error) {
						sap.m.MessageToast.show("Error");
						//Vacio la tabla
						oTableModel.setProperty("/Telefonos", []);
					  oTable.setBusy(false);
					}
				});
			}, 2500);
    },
    
    /**
		 * Convenience method for fetching Mails
		 * @param {[sap.ui.model.filters]} aFilters the filters
		 * @public
		 */
		fetchMailsSet: function (sKunnr) {
			var oModel = this.getModel(),
          oTableModel = this.getModel("tabla"),
          oTable = this.byId("tableMails");

      oTable.setBusy(true);
      
      var aFilters = [];

      aFilters.push(new Filter("Kunnr", FilterOperator.EQ, sKunnr));
			aFilters.push(new Filter({
        filters: [
          new Filter("Comentario", FilterOperator.EQ, "CONF_PEDIDO"),
          new Filter("Comentario", FilterOperator.EQ, "CONF_ENTREGA"),
          new Filter("Comentario", FilterOperator.EQ, "CONF_FACTURA"),
          new Filter("Comentario", FilterOperator.EQ, "NOTIF_RECIBOS_ZF48"),
          new Filter("Comentario", FilterOperator.EQ, "ZAR01_DEUDAS"),
          new Filter("Comentario", FilterOperator.EQ, "ZSD100_BLOQUEOS"),
          new Filter("Comentario", FilterOperator.EQ, "ZF96_CREDITOS")
        ],
        and: false
      }));

			setTimeout(function () {

				oModel.read("/MailsSet", {
					filters: aFilters,
					success: function (oData, oResponse) {
						//Seteo la tabla
						oTableModel.setProperty("/Mails", oData.results);
  					//Dejo de cargar
						oTable.setBusy(false);
					}.bind(this),
					error: function (error) {
						sap.m.MessageToast.show("Error");
						//Vacio la tabla
						oTableModel.setProperty("/Mails", []);
					  oTable.setBusy(false);
					}
				});
			}, 2500);
    },

    //          fragmentos          //
        
    onAddTelefono: function () {
      this.oData = {
        Kunnr: oKunnr
      }
      this.openFragment("AddT", this.getModel(), true, null, {
				parent: this
      }, null);
      
    },

    onPressDeleteTel: function (sPath) {        
      var that = this;
      var oModel = this.getView().getModel();
      oModel.setUseBatch(false);
      //this.getView().getModel().remove(sPath, {
      oModel.remove(sPath, {
        success: function (oData, oResponse) {
          sap.m.MessageToast.show("Teléfono Eliminado");
          that.fetchTelefonosSet(oKunnr);
        },
        error: function (oError) {
          console.log(oError.responseText);
        }
      });
    },

    onDeleteTel: function (oEvent){
      var sPath = oEvent.getParameter("listItem").getBindingContextPath();
      var oPath = this.getModel("tabla");
      var sMessage = "Desea borrar el teléfono seleccionado?";  
      var that = this;
      
      var sKunnr = oPath.getProperty(sPath).Kunnr,
          sId = oPath.getProperty(sPath).Id;
      var sPathDelete ="/TelefonosSet(Kunnr='" + sKunnr + "',Id='" + sId + "')";
          
        MessageBox.warning(sMessage, {
          actions: ["Borrar Telefono", "Cancelar"],
          emphasizedAction: "Cancelar",
          initialFocus: "Cancelar",
          onClose: function (sAction) {
            if (sAction === "Borrar Telefono") {
              //sap.m.MessageToast.show("Ok");
              that.onPressDeleteTel(sPathDelete);
            } else {
              sap.m.MessageToast.show("Acción Cancelada");
            }
          }
        });
    },

    onEditTelefono: function (oEvent) {      
      var Id = oEvent.getSource().getAggregation("cells")[1].getProperty("text"),
          Kunnr = oEvent.getSource().getAggregation("cells")[0].getProperty("text"),
          Telefono = oEvent.getSource().getAggregation("cells")[3].getProperty("text"),
          // Comentario = Nombre
          Comentario = oEvent.getSource().getAggregation("cells")[4].getProperty("text"),
          // Extension = Tipo contacto
          Extension = oEvent.getSource().getAggregation("cells")[5].getProperty("text"),
          oModel = new JSONModel({
            Id: Id,
            Kunnr: Kunnr,
            Telefono: Telefono,
            Comentario: Comentario,
            Extension: Extension
          }); 
      /* var oData = oEvent.getSource().getBindingContext().getObject();
      var oModel = new JSONModel({
            Id: oData.Id,
            Kunnr: oData.Kunnr,
            Telefono: oData.Telefono,
            Comentario: oData.Comentario,
            Extension: oData.Extension
        }); */
      var sPath = "/TelefonosSet(Kunnr='" + Kunnr + "',Id='" + Id + "')";
      this.oData = {
        Id: Id,
        Kunnr: Kunnr,
        Path: sPath
      }
      this.getView().setModel(oModel, "editarTel");

			this.openFragment("EditT", this.getModel(), true, null, {
				parent: this
      }, null);
    },

    onAddMail: function () {
      this.oData = {
        Kunnr: oKunnr
      }
      this.openFragment("AddM", this.getModel(), true, null, {
				parent: this
			}, null);
    },

    onEditMail: function (oEvent) {      
      var Id = oEvent.getSource().getAggregation("cells")[1].getProperty("text"),
          Kunnr = oEvent.getSource().getAggregation("cells")[0].getProperty("text"),
          Mail = oEvent.getSource().getAggregation("cells")[2].getProperty("text"),
          Comentario = oEvent.getSource().getAggregation("cells")[3].getProperty("text"),
          oModel = new JSONModel({
            Id: Id,
            Kunnr: Kunnr,
            Mail: Mail,
            Comentario: Comentario
          });

      var sPath = "/MailsSet(Kunnr='" + Kunnr + "',Id='" + Id + "')";
      this.oData = {
        Id: Id,
        Kunnr: Kunnr,
        Path: sPath
      }
      this.getView().setModel(oModel, "editarMails");

			this.openFragment("EditM", this.getModel(), true, null, {
				parent: this
      }, null);
    },


    onPressDeleteMail: function (sPath) {        
      var that = this;
      var oModel = this.getView().getModel(); 
      oModel.setUseBatch(false);
      //this.getView().getModel().remove(sPath, {
      oModel.remove(sPath, {
        success: function (oData, oResponse) {
          sap.m.MessageToast.show("Mail Eliminado");
          that.fetchMailsSet(oKunnr);
        },
        error: function (oError) {
          console.log(oError.responseText);
        }
      });
    },

    onDeleteMail: function (oEvent){
      var sPath = oEvent.getParameter("listItem").getBindingContextPath();
      var oPath = this.getModel("tabla");
      var sMessage = "Desea Borrar el mensaje seleccionado?";  
      var that = this;
      
      var sKunnr = oPath.getProperty(sPath).Kunnr,
          sId = oPath.getProperty(sPath).Id;
      var sPathDelete ="/MailsSet(Kunnr='" + sKunnr + "',Id='" + sId + "')";
          
        MessageBox.warning(sMessage, {
          actions: ["Borrar Mail", "Cancelar"],
          emphasizedAction: "Cancelar",
          initialFocus: "Cancelar",
          onClose: function (sAction) {
            if (sAction === "Borrar Mail") {
              //sap.m.MessageToast.show("Ok");
              that.onPressDeleteMail(sPathDelete);
            } else {
              sap.m.MessageToast.show("Accion Cancelada");
            }
          }
        });
    },

    onSelectFilter: function (oEvent) {
      var oViewModel = this.getModel("view");
      var sKey = oEvent.getSource().getSelectedKey();
            
			switch (sKey){
				case "Direccion":
					oViewModel.setProperty("/showContactoMail", false);
					oViewModel.setProperty("/showContactoTelefono", false);
					break;
				case "Telefono":
          oViewModel.setProperty("/showContactoMail", false);
					oViewModel.setProperty("/showContactoTelefono", true);
				break;
				case "Mail":
          oViewModel.setProperty("/showContactoMail", true);
					oViewModel.setProperty("/showContactoTelefono", false);
					break;
				default: break;
			}
    },

      //no es necesario
    /*onEditar: function () {

      var oModel = this.getView().getModel("view");

      oModel.setProperty("/editarBtnVisible", false);
      oModel.setProperty("/guardarBtnVisible", true);
      oModel.setProperty("/cancelarBtnVisible", true);
      oModel.setProperty("/agregarBtnVisible", true);
      oModel.setProperty("/inputsEnabled", true);
    }, 

    onCancelar: function () {

      var oModel = this.getView().getModel("view");

      oModel.setProperty("/editarBtnVisible", true);
      oModel.setProperty("/guardarBtnVisible", false);
      oModel.setProperty("/cancelarBtnVisible", false);
      oModel.setProperty("/agregarBtnVisible", false);
      oModel.setProperty("/inputsEnabled", false);
    }, 

    _agregarPanel: function(panel, group, adata) {
      var oPanelInterno = this.byId(group),
          oPanelTelefono = this.byId(panel);

      var oPanelInternoCopy = oPanelInterno.clone();

      oPanelInternoCopy.getContent().forEach((element, i) => {
        if (element.getMetadata().getElementName() != "sap.m.Button") element.setValue(adata[i]);
        else element.setVisible(true);
      });

      oPanelTelefono.addContent(oPanelInternoCopy);      
    },

    onAgregarTelefono:function () {
      this._agregarPanel("_pTelefono", "_pInterno1");
    },

    onAgregarMail : function() {
      this._agregarPanel("_pMail", "_pMailInterno");
    },

    onRemove: function(oEvent) {
      var oPanel = oEvent.getSource().getParent();

      oPanel.destroy();
    }
    */
  });
});
