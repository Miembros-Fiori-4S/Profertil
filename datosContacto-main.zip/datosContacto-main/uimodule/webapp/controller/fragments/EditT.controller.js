sap.ui.define(["../BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "sap/m/MessageBox"], function (BaseController,
	JSONModel, MessageToast, MessageBox) {
	"use strict";
	var oController;
	var aInputs;
	return BaseController.extend("profertil.datosClientes.controller.fragments.EditT", {
		/* =========================================================== */
		/* lifecycle methods */
		/* =========================================================== */
		/*** Called before the fragment is show* 
		 * @param {parent, fragment, function, string} Parent who created the fragment; Fragment this fragment, * 
     * callback fuction, type string which says if the view is Add User or Details* 
		@public*/

		onBeforeShow: function (parent, fragment, callback, data) {
			oController = this;
			this.parent = data.parent;
			this.fragment = fragment;
			this.callback = callback;
			this.data = data;

			this.fragment.attachBeforeOpen(this._onObjectMatched, this);

    },
    
		_onObjectMatched: function (oEvent) {

			this.parent.getView().getModel().metadataLoaded().then(function () {
				var sObjectPath = this.parent.getView().getModel().createKey("TelefonosSet", {
          Kunnr: this.parent.oData.Kunnr,
          Id: this.parent.oData.Id
        });
        this._bindView("/" + sObjectPath);
        
			}.bind(this));
		},

		_bindView: function (sObjectPath) {
			var oDataModel = this.parent.getModel();

			this.parent.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {

						});
					}
				}
			});
		},

		_onBindingChange: function () {
			var oView = this.parent.getView(),
				oElementBinding = oView.getElementBinding();

			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.parent.getRouter().getTargets().display("objectNotFound");
				return;
			}

    },
    
    updateTel: function(){
      var Telefono = this.fragmentById(this.parent, "_telefono").getValue(),
          Extension = this.fragmentById(this.parent, "_tContacto").getSelectedKey(),
          Comentario = this.fragmentById(this.parent, "_nombre").getValue(),
			    oEntity = {
            Id: this.parent.oData.Id,
            Kunnr: this.parent.oData.Kunnr,
            Telefono: Telefono,
            Comentario: Comentario,
            Extension: Extension
          };
			
			oController = this;
			var that = this;
			var oModel = this.parent.getView().getModel();
			
			this.fragment.setBusy(true);
			oModel.setUseBatch(false);
			oModel.update(this.parent.oData.Path, oEntity,{
				success: function (resultado) {
					oController.fragment.setBusy(false);
					oController.onClose();
				},
				error: function (error) {
					MessageToast.show(error);
					oController.fragment.setBusy(false);
				}
			});
		},

    onClose: function () {
        this.parent.fetchTelefonosSet(this.parent.oData.Kunnr);
				this.fragment.close();
				if (this.callback) this.callback.call(this.parent);
    }
      
	});
});