sap.ui.define(["../BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "sap/m/MessageBox"], function (BaseController,
	JSONModel, MessageToast, MessageBox) {
	"use strict";
	var oController;
	var aInputs;
	return BaseController.extend("profertil.datosClientes.controller.fragments.AddT", {
		/* =========================================================== */
		/* lifecycle methods */
		/* =========================================================== */
		/*** Called before the fragment is show* 
		 * @param {parent, fragment, function, string} Parent who created the fragment; Fragment this fragment, * callback fuction, type string which says if the view is Add User or Details* 
		@public*/

		onBeforeShow: function (parent, fragment, callback, data) {
			oController = this;
			this.parent = data.parent;
			this.fragment = fragment;
			this.callback = callback;
			this.data = data;

		//	this.fragment.attachBeforeOpen(this._onObjectMatched, this);

    },

     //      obtener datos teléfono      //
    _obtenerDatosTelefono: function (){

     var aTelefono = {
       //Kunnr: '1',
       //Kunnr = this.getView().getModel("tabla").getProperty("/Kunnr"),
       Kunnr: this.data.parent.oData.Kunnr,
       Comentario: this.fragmentById(this.parent, "_inombre").getValue(),
       Extension: this.fragmentById(this.parent, "_cbContacto").getSelectedKey(),
       Telefono: this.fragmentById(this.parent, "_iTelefono").getValue()
       };

      return aTelefono;
    },

    // evento btn .onAdd
    AgregarTelefono: function () {
      var oModel = this.parent.getModel();
      var oEntity = oController._obtenerDatosTelefono(),
          that = this;

      oModel.setUseBatch(false);
      oModel.create("/TelefonosSet", oEntity, {
        success: function (resultado) {
            MessageBox.success("Teléfono agregado.");
            that.onClose();
      }.bind(this),
					error: function (error) {
						MessageToast.show("Error: Algo salió mal");
						//oController.getView().setBusy(false);
					}
      });

    },

    onClose: function () {
        //	this._clear();
        this.parent.fetchTelefonosSet(this.parent.oData.Kunnr);
				this.fragment.close();
				if (this.callback) this.callback.call(this.parent);
    },

	});
});