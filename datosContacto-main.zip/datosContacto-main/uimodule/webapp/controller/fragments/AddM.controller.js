sap.ui.define(["../BaseController", "sap/ui/model/json/JSONModel", "sap/m/MessageToast", "sap/m/MessageBox"], function (BaseController,
	JSONModel, MessageToast, MessageBox) {
	"use strict";
	var oController;
	var aInputs;
	return BaseController.extend("profertil.datosClientes.controller.fragments.AddM", {
		/* =========================================================== */
		/* lifecycle methods */
		/* =========================================================== */
		/*** Called before the fragment is show* 
		 * @param {parent, fragment, function, string} Parent who created the fragment; Fragment this fragment, * callback fuction, type string which says if the view is Add User or Details* 
		@public*/

		onBeforeShow: function (parent, fragment, callback, data) {
			oController = this;
			this.parent = data.parent;
			this.fragment = fragment;
			this.callback = callback;
      this.data = data;

		//	this.fragment.attachBeforeOpen(this._onObjectMatched, this);

    },

    _obtenerDatos: function (){
     var aMail = {
       //Kunnr: '1',
       Kunnr: this.parent.oData.Kunnr,
       Comentario: this.fragmentById(this.parent, "tipoContacto").getSelectedKey(),
       Mail: this.fragmentById(this.parent, "_mail").getValue()
       };

      return aMail;
    },

    // evento btn .onAdd
    onAdd: function () {
      var oModel = this.parent.getModel();
      var oEntity = oController._obtenerDatos(),
          that = this;

      oModel.setUseBatch(false);

      oModel.create("/MailsSet", oEntity, {
        success: function (resultado) {
            MessageBox.success("Mail agregado.");
            that.onClose();
            oModel.setUseBatch(true);
      }.bind(this),
					error: function (error) {
						MessageToast.show("Error: Algo salió mal");
            //oController.getView().setBusy(false);
            oModel.setUseBatch(true);
					}
      });

    },
    
    onClose: function () {
      //	this._clear();
      this.parent.fetchMailsSet(this.parent.oData.Kunnr);
      this.fragment.close();
      if (this.callback) { 
        this.callback.call(this.parent);
      }
    }
      

	});
});