sap.ui.define([
	"profertil/ctesporzona/test/unit/controller/App.controller"
], function () {
	"use strict";
});
