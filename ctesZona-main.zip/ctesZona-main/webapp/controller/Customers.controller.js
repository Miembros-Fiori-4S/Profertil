/**
 * Customers Controller.
 *
 * Methods of Customers View.
 *
 * @file This files describes Customers View controller.
 * @author Tomas A. Sanchez
 * @since 03.22.2021
 */
/* eslint-disable no-warning-comments */
sap.ui.define(
  [
    "profertil/ctesporzona/controller/ValueHelp",
    "sap/ui/model/json/JSONModel",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
    "../model/formatter",
  ],
  function (Controller, JSONModel, Filter, FilterOperator, formatter) {
    "use strict";

    // Bind this shortcut
    var oController;

    return Controller.extend("profertil.ctesporzona.controller.Customers", {
      /**
       * Formmater JS split-code.
       * @memberOf profertil.view.Customers
       */
      formatter: formatter,

      /* =========================================================== */
      /* lifecycle methods                                           */
      /* =========================================================== */

      /**
       * Called when the remitos controller is instantiated.
       * @memberOf profertil.view.Customers
       */
        onInit: function () {
            oController = this;
            // The view model to be set
            var oViewModel;

            oViewModel = new JSONModel({
                showSelect: true,
                showSearch: false,
                tableSelectionMode: "None",
            });

            oController.setModel(oViewModel, "customersView");

            // Add the remitos page to the flp routing history
            this.addHistoryEntry(
            {
                title: this.getResourceBundle().getText("appTitle"),
                icon: "sap-icon://table-view",
                intent: "#Clientes-display",
            }, true);

        },

        /* =========================================================== */
        /* event handlers                                              */
        /* =========================================================== */

        /**
         * Triggered by Footer Main action.
         * Enables selection in table and search action.
         * @function
         * @param {sap.ui.base.Event} oEvent the button press event
         * @param {boolean} bActive the active state
         * @public
         */
        onSelectSearch: (_oEvent, bActive = true) => {
            oController._toggleTableSelection(bActive);
            oController._toggleDownloadButtons(bActive);
        },

        /**
         * Triggered by Footer Main action.
         * Disbles table selection and search state.
         * @function
         * @param {sap.ui.base.Event} oEvent the button press event
         * @public
         */
        // eslint-disable-next-line no-unused-vars
        onCancelSearch: (_oEvent) => {
            oController.onSelectSearch(null, false);
        },

        /**
         * Triggered before table rebind.
         *
         * Handles custom rebind options.
         * @function
         * @param {sap.ui.base.Event} oEvent the event of rebinding the table
         * @public
         */
        onBeforeRebindBalancesTable: function (oEvent) {
            var mBindingParams = oEvent.getParameter("bindingParams");
            var oSmtFilter = this.getView().byId("filterbar");

            //Kunnr Custom Filter
            var oMultiInput = oSmtFilter.getControlByKey("Kunnr"),
            aTokens = oMultiInput.getTokens();

            oController._filterTokens(mBindingParams, aTokens);
        },

        /* =========================================================== */
        /* Internal Methods                                            */
        /* =========================================================== */

        _filterTokens: function (mBindingParams, aTokens) {
            var aFilters = aTokens.map(
            (oToken) => new Filter("Kunnr", FilterOperator.EQ, oToken.getKey())
            );

            aFilters.forEach((oFilter) => mBindingParams.filters.push(oFilter));
        },

        /**
         * Enables or disable visibility of buttons by changing model property.
         * @function
         * @private
         * @param {boolean} bActive active select mode ?
         */
        _toggleDownloadButtons: (bActive = false) => {
            var oViewModel = oController.getModel("customersView");
            oViewModel.setProperty("/showSearch", bActive);
            oViewModel.setProperty("/showSelect", !bActive);
        },

        /**
         * Enables or disables multi-selection in the table.
         * @function
         * @private
         * @param {boolean} bActive active select mode ?
         */
        _toggleTableSelection: (bActive = false) => {
            var oViewModel = oController.getModel("customersView");
            oViewModel.setProperty(
            "/tableSelectionMode",
            bActive ? "MultiSelect" : "None"
            );
        },

        /* =========================================================== */
        /* End of Internal Methods                                     */
        /* =========================================================== */

    });
  }
);
