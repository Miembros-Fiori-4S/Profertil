sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel",
	"../model/formatter",
	"sap/ui/model/Filter",
	"sap/ui/model/FilterOperator"
], function (BaseController, JSONModel, formatter, Filter, FilterOperator) {
	"use strict";

	return BaseController.extend("profertil.listadorpcli.controller.Worklist", {

		formatter: formatter,

		/* =========================================================== */
		/* lifecycle methods                                           */
		/* =========================================================== */

		/**
		 * Called when the worklist controller is instantiated.
		 * @public
		 */
		onInit : function () {
			var oViewModel;			
			oViewModel = new JSONModel({});
            this.setModel(oViewModel, "worklistView");
            this.setRepoUrl();
            this.setInitialSortOrder();

        },

        onNewReclamo: function () {
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
            var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: "informePagoNA",
                        action: "display"
                    }})) || "";

            oCrossAppNavigator.toExternal({ target: { shellHash: hash } });

        },


        setInitialSortOrder: function() {
            var oSmartTable = this.getView().byId("stListado");            
            oSmartTable.applyVariant({
                sort: {
                    sortItems: [ { columnKey: "Id", operation:"Descending" } ]
                }
            });
        },

        
        onPress : function (oEvent) {
			// The source is the list item that got pressed
			this._showObject(oEvent.getSource());
        },
        
        onNavBack : function() {
			// eslint-disable-next-line sap-no-history-manipulation
			history.go(-1);
        },
        
        setRepoUrl: function () {
            var oModel = this.getManifestModel("AppModel");            
            this.getData("")
                .then(response => {
                    var repos = Object.keys(response).filter(repo => response[repo].repositoryName == "INFORME_PAGOS");
                    var root = repos[0] + "/root";
                    var url = this.getDMSUrl("/SDM_API/browser/" + root);
                    //this._dmsUrl = url;
                    oModel.setProperty("/url", url);
                    oModel.setProperty("/repoId", repos[0]);
                    oModel.setProperty("/rootId", response[repos[0]].rootFolderId);

                })
                .catch(function (oError) {
                    console.warn("Repository not found");
                });
                
        },

        _showObject : function (oItem) {
			this.getRouter().navTo("object", {
				objectId: oItem.getBindingContext().getProperty("Id")
			});
        },


	});
});