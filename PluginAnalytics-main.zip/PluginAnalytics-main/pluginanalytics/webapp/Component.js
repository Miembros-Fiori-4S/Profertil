sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
    "profertil/pluginanalytics/model/models",
    "profertil/pluginanalytics/lib/platform"
], function (UIComponent, Device, models, platformjs) {
    "use strict";

    return UIComponent.extend("profertil.pluginanalytics.Component", {


        metadata: {
            manifest: "json"
        },
        init: function () {

            var oPluginParameters = this.getComponentData().config; // obtain plugin parameters
            var oModel = this.getModel();
            oModel.setUseBatch(false);
            var componentPrev = ""; // ultimo component registrado, para calcular duración y navegación entre apps
            var prevTime;
            var oEntry;

            function getComponent() {

                /*
                    #Clientes-Seleccionar?sap-ui-app-id-hint=saas_approuter_profertil.seleccioncliente
                    Si el hash tiene un hint, retorna eso, por ejemplo: saas_approuter_profertil.seleccioncliente
                    Lo cual coincide con el componente de la app.
                    Si no, retorna el objeto semantico: Clientes-Seleccionar

                */
                var aParts = window.location.hash.split("?");
                var hash = aParts[0].replace("#", "");
                var params = aParts[1];
                var aParams = sap.ushell.Container.getService("URLParsing").parseParameters(params);

                if (aParams["sap-ui-app-id-hint"] && aParams["sap-ui-app-id-hint"][0]) {
                    return aParams["sap-ui-app-id-hint"][0]
                }
                return hash;
            }

            function logHashchange() {
                // primero loguea lo que esté pendiente del cambio anterior
                if (oEntry) {

                    // recalcular duración
                    var now = new Date().getTime();
                    oEntry.Duration =  now - prevTime;

                    // loguear
                    oModel.create("/LogNavSet", oEntry);

                    // mostrar en consola
                    if (oPluginParameters.consola) {
                        console.log(oEntry);
                    }
                }

                var component = getComponent();
                // luego actualiza la entrada para el siguiente logueo
                oEntry = {
                    Title: document.title,
                    Component: component,
                    ComponentPrev: componentPrev,
                    Duration: new Date().getTime(),
                    OsFamily: platform.os.family.toString(),
                    OsVersion: platform.os.version.toString(),
                    OsArchitecture: platform.os.architecture.toString(),
                    Os: platform.os.toString(),
                    Browser: platform.name,
                    BrowserVersion: platform.version.toString(),
                    Platform: platform.description
                }
                componentPrev = component;
                prevTime = new Date().getTime();


            }

            if (oPluginParameters.activo) {
                // loguear en cada cambio de página (hash)
                $(window).hashchange(logHashchange);

            }

            // bindear evento que loguea al salir del portal
            $(window).bind('beforeunload', function () {
                logHashchange();
            });



        }


    });
});
