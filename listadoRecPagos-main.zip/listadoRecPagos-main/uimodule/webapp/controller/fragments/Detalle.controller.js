sap.ui.define(
  [
    "../BaseController",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageToast",
    "sap/m/MessageBox",
  ],
  function (BaseController, JSONModel, MessageToast, MessageBox) {
    "use strict";
    var oController;
    return BaseController.extend(
      "profertil.listadoReclamos.controller.fragments.Detalle",
      {
        /* =========================================================== */
        /* lifecycle methods */
        /* =========================================================== */
        /*** Called before the fragment is show* 
		 * @param {parent, fragment, function, string} Parent who created the fragment; Fragment this fragment, * callback fuction, type string which says if the view is Add User or Details* 
		   @public*/

        onBeforeShow: function (parent, fragment, callback, data) {
          
          oController = this;
          this.parent = data.parent;
          this.fragment = fragment;
          this.callback = callback;
          this.data = data;

          this.fragment.attachBeforeOpen(this._onObjectMatched, this);
          
          this.parent.setModel(
            new JSONModel({
              _input2: false,
              _input3: false,
              _input4: false,
              _input5: false,
              _input6: false,
              _input7: false,
              _input8: false,
              _input9: false,
              resueltoVisible: false,
              pendienteVisible: false,
            }),
            "view"
          ); 

        },

        /**
         * Binds the view to the object path.
         * @function
         * @param {sap.ui.base.Event} oEvent pattern match event in route 'object'
         * @private
         */
      _onObjectMatched: function (oEvent) {
                
        this.fragment.setBusy(true);

        this.parent.getView().getModel().metadataLoaded().then(function () {
          var sObjectPath = this.parent.getView().getModel().createKey("InformeSet", {
            Id: this.parent.oData.getObject().Id
          });
          this._bindView("/" + sObjectPath);
        }.bind(this));

        this.campoVisibility();
      
		},

		_bindView: function (sObjectPath) {
      this.fragment.setBusy(true);

			var oDataModel = this.parent.getModel();
			this.parent.getView().bindElement({
				path: sObjectPath,
				events: {
					change: this._onBindingChange.bind(this),
					dataRequested: function () {
						oDataModel.metadataLoaded().then(function () {
							// Busy indicator on view should only be set if metadata is loaded,
							// otherwise there may be two busy indications next to each other on the
							// screen. This happens because route matched handler already calls '_bindView'
              // while metadata is loaded.
              
						});
					}
				}
      });
      
		},

		_onBindingChange: function () {
			var oView = this.parent.getView(),
				oElementBinding = oView.getElementBinding();

      
			// No data for the binding
			if (!oElementBinding.getBoundContext()) {
				this.parent.getRouter().getTargets().display("objectNotFound");
				return;
      }
      
      this.fragment.setBusy(false);
      
      this.handleButtonVisibility();

    },
    
		/* =========================================================== */
    /* event handlers */
    /* =========================================================== */
    onClose: function () {
      this.fragment.close();
      if (this.callback) {
        sap.m.MessageToast.show("CALLBACK !!!");
        this.callback.call(this.parent);
      }

      this.cambiarAPendiente();
    },

    cambiarAPendiente: function () {
     
      if (this.parent.oData.getObject().Estado === 'N'){
        var sResolucion = this.parent.oData.getProperty("Resolucion");
        var oModel = this.parent.getModel(),
            oEntity = {
              Estado: 'P',
              Resolucion: sResolucion
            };

        oModel.setUseBatch(false);
        oModel.update(this.parent.oData.getPath(), oEntity, {
          success: function (oData){
            oModel.setUseBatch(true);
            MessageToast.show("Leído");
          },
          error: function (oData){
            oModel.setUseBatch(true);
            MessageToast.show("Ha ocurrido un error");
          }
        })
      }

    },

     campoVisibility: function () {
      var oModel = this.parent.getModel("view");
        switch (this.parent.oData.getObject().Tipopago) {
          case 'Transferencia':
            oModel.setProperty("/_input2", true);

            oModel.setProperty("/_input3", false);
            oModel.setProperty("/_input4", false);
            oModel.setProperty("/_input5", false);
            oModel.setProperty("/_input6", false);
            oModel.setProperty("/_input7", false);
            oModel.setProperty("/_input9", false);
            oModel.setProperty("/_input8", false);
            break;
          case 'Depósito':
            oModel.setProperty("/_input3", true);
            oModel.setProperty("/_input4", true);

            oModel.setProperty("/_input2", false);
            oModel.setProperty("/_input5", false);
            oModel.setProperty("/_input6", false);
            oModel.setProperty("/_input7", false);
            oModel.setProperty("/_input9", false);
            oModel.setProperty("/_input8", false);
            break;
          case 'Cheque':
            oModel.setProperty("/_input4", true);

            oModel.setProperty("/_input2", false);
            oModel.setProperty("/_input3", false);
            oModel.setProperty("/_input5", false);
            oModel.setProperty("/_input6", false);
            oModel.setProperty("/_input7", false);
            oModel.setProperty("/_input9", false);
            oModel.setProperty("/_input8", false);
            break;
          case 'Cupón tarjeta':
            oModel.setProperty("/_input5", true);
            oModel.setProperty("/_input9", true);

            oModel.setProperty("/_input2", false);
            oModel.setProperty("/_input3", false);
            oModel.setProperty("/_input4", false);
            oModel.setProperty("/_input6", false);
            oModel.setProperty("/_input7", false);
            oModel.setProperty("/_input8", false);
            break;
          case 'Retención':
            oModel.setProperty("/_input6", true);
            oModel.setProperty("/_input7", true);

            oModel.setProperty("/_input2", false);
            oModel.setProperty("/_input3", false);
            oModel.setProperty("/_input4", false);
            oModel.setProperty("/_input5", false);
            oModel.setProperty("/_input9", false);
            oModel.setProperty("/_input8", false);
            break;
          case 'Factura como':
            oModel.setProperty("/_input8", true);
            
            oModel.setProperty("/_input2", false);
            oModel.setProperty("/_input3", false);
            oModel.setProperty("/_input4", false);
            oModel.setProperty("/_input5", false);
            oModel.setProperty("/_input6", false);
            oModel.setProperty("/_input7", false);
            oModel.setProperty("/_input9", false);
            break;
          default:
            break;
        }
      },

      handleButtonVisibility: function () {
        var oModel = this.parent.getModel("view");
          switch (this.parent.oData.getObject().Estado) {
            case 'R':
              oModel.setProperty("/resueltoVisible",false);
              oModel.setProperty("/pendienteVisible",true);
              break;
            case 'N':
              oModel.setProperty("/resueltoVisible",true);
              oModel.setProperty("/pendienteVisible",false);
              break;
            case 'P':
              oModel.setProperty("/resueltoVisible",true);
              oModel.setProperty("/pendienteVisible",false);
              break;
            default:
              break;
          }
      },

      onResuelto: function () {
        this.cambiarAResuelto();
        this.onClose();
      },

      onPendiente: function () {
        this.cambiarAP();
        this.onClose();
      },

      cambiarAResuelto: function () {
        //var Id = this.parent.oData.getProperty("Id");
        var sResolucion = this.parent.oData.getProperty("Resolucion");
        var oModel = this.parent.getModel(),
            oEntity = {
              Estado: "R",
              Resolucion: sResolucion
            };

        oModel.setUseBatch(false);
        var that = this;
        oModel.update(this.parent.oData.getPath(), oEntity, {
          success: function (oData){
            oModel.setUseBatch(true);
            MessageToast.show("Resuelto");
            that.updateListado();
          },
          error: function (oData){
            oModel.setUseBatch(true);
            MessageToast.show("Ha ocurrido un error");
          }
        })
      
    },

    cambiarAP: function () {
      var sResolucion = this.parent.oData.getProperty("Resolucion");
      var oModel = this.parent.getModel(),
          oEntity = {
            Estado: 'P',
            Resolucion: sResolucion
          };
          
      if (this.parent.oData.getObject().Estado === 'R'){
        oModel.setUseBatch(false);
        var that = this;
        oModel.update(this.parent.oData.getPath(), oEntity, {
          success: function (oData){
            oModel.setUseBatch(true);
            MessageToast.show("Pendiente");
            that.updateListado();
          },
          error: function (oData){
            oModel.setUseBatch(true);
            MessageToast.show("Ha ocurrido un error");
          }
        })
      }
    },

    updateListado: function () {
      this.parent.handlechangeEstado();
    }


  });
});
