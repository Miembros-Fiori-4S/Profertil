sap.ui.define(
  [
    "profertil/listadoReclamos/controller/BaseController",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator",
  ],
  function (Controller, Filter, FilterOperator) {
    "use strict";
    var oController;

    return Controller.extend("profertil.listadoReclamos.controller.Main", {
      
      onInit: function () {
        oController = this;
      },

      onDetalle: function (oEvent) {
        var oBinding = oEvent.getSource().getBindingContext();
        this.oData = oBinding;
            
      /*  this.getModel().read("/InformeSet", {
          success: function (result) {},
        }); */

        this.openFragment(
          "Detalle",
          null,
          true,
          this.onFragmentCallback,
          {
            Id: this.oData,
            parent: this
          }
        );

      },

      onBeforeRebindTable: function (oEvent) {
        var mBindingParams = oEvent.getParameter("bindingParams");
        var oSmtFilter = this.getView().byId("smartFilterBar");

        //Custom Filter
        var sEstado = oSmtFilter.getControlByKey("Estado").getSelectedKey(),
        //  sEstado = oInput.getValue(),
          sZona = oSmtFilter.getControlByKey("Zona").getSelectedKey();
        //  sZona = oInput.getValue();
        
        if (sEstado) {
          var oEstadoFilter = new Filter("Estado", FilterOperator.EQ, sEstado);
          mBindingParams.filters.push(oEstadoFilter);
        }
        
        if (sZona) {
          var oZonaFilter = new Filter("Zona", FilterOperator.EQ, sZona);
          mBindingParams.filters.push(oZonaFilter);
        }
        
      },

      handlechangeEstado: function (oEvent) {
        console.log("--->>> Update Listado");
        if (this.getView().byId("stListado")) {
          this.getView().byId("stListado").rebindTable();
        }
        //this.getView().getModel().refresh(true);
        //"table0"
        var oTable = this.byId("table0");
        oTable.getBinding("items").refresh(true);
        //oTable.getBinding("rows").refresh();

      },

      handlechangeZona: function (oEvent) {
        if (this.getView().byId("stListado")) {
          this.getView().byId("stListado").rebindTable();
        }
      },



    });
  }
);
