sap.ui.define([], function () {
	"use strict";
	return {

    toNumber: function (fValue) {
      fValue = parseFloat(fValue);
      return Intl.NumberFormat().format(fValue.toFixed(2));
    
    }, 
    
    highlightEstado: function (sEstado) {
			switch (sEstado) {
			case "N":
				return "Error";
			case "P":
				return "Warning";
			case "R":
				return "Success";
			default:
				return "None";
			}
    },

    infoLabel: function (sStatus) {
			switch (sStatus) {
			case "No leído":
				return 2;
			case "Pendiente":
				return 1;
			case "Resuelto":
        return 7;
			default:
				return 5; 
			}
    },
    
    formatName: function (str) {
			var sReturn = str;
			try {
				sReturn = str.replace(
					/\w\S*/g,
					function (txt) {
						return txt.charAt(0).toUpperCase() + txt.substr(1).toLowerCase();
					}
				);
			} finally {
				return sReturn;
			}
		}
  };
});
