sap.ui.define([
  "profertil/ListadoDeFacturasDistribuidor/controller/BaseController"
], function(Controller) {
  "use strict";

  return Controller.extend("profertil.ListadoDeFacturasDistribuidor.controller.AppView", {});
});
