sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "sap/ui/model/Filter",
    "sap/ui/model/json/JSONModel",
    "sap/m/MessageBox"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
	function (Controller, formatter, Filter, JSONModel, MessageBox) {
		"use strict";

		return Controller.extend("profertil.notifview.controller.List", {

            formatter: formatter,

			onInit: function () {

                var oViewModel = null;
                oViewModel = new JSONModel({
                    isAdmin: false, //this._isAdmin(),
                    kunnr: "", 
                    name1: ""
                });
                this.getView().setModel(oViewModel, "viewModel");

                var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("RouteList").attachPatternMatched(this._onObjectMatched, this);
                
                this.setName();

            },

            setName: function () {
                var bIsAdmin = this.getView().getModel("viewModel").getProperty("/isAdmin");
                if (bIsAdmin) {

                } else {

                    var sPath = "/getClientData";
                    var oModel = this.getOwnerComponent().getModel("pendliq");
                    var that = this;
                    oModel.read(sPath, {
                        success: function (oData, oResponse) {
                            that.getView().getModel("viewModel").setProperty("/kunnr", oData.kunnr);
                            that.getView().getModel("viewModel").setProperty("/name1", oData.name1);
                        },
                        error: function (oError) {
                            console.log("--->>>error reading getClientData");
                        }
                    });
                }
            },

            onItemClose: function (oEvent) { 
                var that = this;
                var oItem = oEvent.getSource().getBindingContext();
                var sTipo = oItem.getProperty("tipo");
                if ( sTipo === '8' || sTipo === '4') {
                    MessageBox.information("Este tipo de Notificaciones no se pueden Eliminar.\nSon de importancia alta.\nSe actualizará automaticamente");
                    return;
                }
                MessageBox.warning(
                    "Desea Eliminar la notificacion?. \nNo la podra ver mas.", {
                        icon: MessageBox.Icon.INFORMATION,
                        title: "Eliminar Notificacion",
                        actions: ["Eliminar Notificacion", "Cancelar"],
                        
                        initialFocus: "Cancelar",
                        onClose: function (oAction) { 
                            if (oAction === "Eliminar Notificacion") {
                                //that.suspenderNotificacion(oItem);
                                that.deleteNotificacion(oItem).then(function () {
                                    sap.m.MessageToast.show("Se ha eliminado la Notificacion");
                                    that.onPressRefresh();
                                });
                            } 
                        }
                    }
                );
            },

            suspenderNotificacion: function (oItem) {
                var oItem = oEvent.getSource().getBindingContext();
                var sKunnr = oItem.getProperty("kunnr");
                var sPosicion = oItem.getProperty("posicion");
                var oData = {
                    kunnr: sKunnr,
                    posicion: sPosicion,
                    suspendida: "S"
                };
                var that = this;
                this.updateData(oData).then(function () {
                    that.onPressRefresh();
                });

            },

            onListItemPress: function (oEvent) {
                //var oItem = oEvent.getSource().getBindingContext();
                //this.marcarComoNoLeido(oItem);  // lo marca como NO leido

            },

            marcarComoLeido: function(oItem) {
                var sKunnr = oItem.getProperty("kunnr");
                var sPosicion = oItem.getProperty("posicion");
                var sLeido = oItem.getProperty("leido");
                if (sLeido === "S") {
                    return; // ya esta leido
                } else {
                    sLeido = "S";
                }
    
                var oData = {
                    kunnr: sKunnr,
                    posicion: sPosicion,
                    leido: sLeido
                };
                var that = this;
                this.updateData(oData).then(function () {
                    that.onPressRefresh();
                });
    
            },

            marcarComoNoLeido: function(oItem) {
                var sKunnr = oItem.getProperty("kunnr");
                var sPosicion = oItem.getProperty("posicion");
                var sLeido = oItem.getProperty("leido");
                if (sLeido === "N") {
                    return; // ya esta NO leido
                } else {
                    sLeido = "N";
                }
    
                var oData = {
                    kunnr: sKunnr,
                    posicion: sPosicion,
                    leido: sLeido
                };
                var that = this;
                this.updateData(oData).then(function () {
                    that.onPressRefresh();
                });
    
            },

            onPressDetail: function (oEvent) {
                var oItem = oEvent.getSource().getBindingContext();
                this.marcarComoLeido(oItem);  // lo marca como leido
                this.executeAction(oItem);
    
            },

            executeAction: function (oItem) {
                //var sKunnr = oItem.getProperty("kunnr");
                //var sPosicion = oItem.getProperty("posicion");
                var sTitulo = oItem.getProperty("titulo");
                var sLinkApp = oItem.getProperty("linkapp");
                var sLink = oItem.getProperty("link");
                var sLinkRepo = oItem.getProperty("linkrepo");
                var sLinkPdf = oItem.getProperty("linkpdf");
                var sLinkHtml = oItem.getProperty("linkhtml");
    
                if (sLink) {
                    this.navigateToExternalLink(sLink);
                }
                if (sLinkApp) {
                    this.navigateToApp(sLinkApp);
                }
                if (sLinkRepo) {
                    this.repoFileDownload(sLinkRepo);
                }
                if (sLinkPdf) {
                    this.pdfOdataDownload(sLinkPdf);
                }
                if (sLinkHtml) {
                    this.displayFormattedText(sTitulo, sLinkHtml);
                }
    
                if (sLinkApp === "" && sLink === "" && sLinkRepo === "" && sLinkPdf === "" && sLinkHtml === "") {
                    //sap.m.MessageToast.show("No hay mas detalles disponibles");
                    var sLinkHtml = "<h5>No hay mas detalles disponibles.</h5><p>Gracias.</p>";
                    this.displayFormattedText("Notificacion", sLinkHtml);
                }
    
            },

            onPressCerrarText: function () {
                this._getDialog3().close();
            },

            /**
             * Acciones 
             */
            navigateToApp: function (sLinkApp) {
                //sLinkkApp = "Orden-Display"
                var aLink = sLinkApp.split("-");  
                if (aLink.length !== 2) {
                    return;
                }
                var sSemanticObject = aLink[0];
                var sAction = aLink[1];
    
                var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation"); 
                var hash = (oCrossAppNavigator && oCrossAppNavigator.hrefForExternal({
                    target: {
                        semanticObject: sSemanticObject,
                        action: sAction
                    }
                })) || ""; 
    
                oCrossAppNavigator.toExternal({
                    target: {
                        shellHash: hash
                    }
                }); 
    
            },
    
            navigateToExternalLink: function (sLink) {
                sap.m.URLHelper.redirect(sLink, true);
            },
    
            pdfOdataDownload: function (sLink) {
                var sUrlPdf = this.getRelativeUrl(sLink);
                sap.m.URLHelper.redirect(sUrlPdf, true);
            },
    
            repoFileDownload: function (sTextoExt) {
                var aFile = [];
                aFile = sTextoExt.split("/");
                var sRepo = aFile[0];
                var sFile = aFile[1];
                this.setRepoUrl(sRepo, sFile);
                sap.m.MessageToast.show("Descarga de archivo iniciada....");
    
            },
    
            displayFormattedText: function (sTitulo, sLinkText) {
                var oModel = new JSONModel({
                    titulo: sTitulo,
                    HTML: sLinkText
                });
                sap.ui.getCore().setModel(oModel, "FormattedText");
                this._getDialog3().open();
            },

            deleteNotificacion: function (oItem) {
                var oModel = this.getView().getModel();
                this.setUseBatchFalse(oModel);
                var oData = oItem.getObject();
                var sPath = "/NotificacionSet(kunnr='" + oData.kunnr + "',posicion='" + oData.posicion + "')";
                return new Promise( function (resolve, reject) {
                    oModel.remove(sPath, {
                        success: function () {
                            resolve();
                        },
                        error: function () {
                            reject();
                        }
                    });
                });

            },

            updateData: function (oData) {
                var oModel = this.getView().getModel();
                this.setUseBatchFalse(oModel);
                var that = this;
                return new Promise( function (resolve, reject) {
                    var sPath = "/NotificacionSet(kunnr='" + oData.kunnr + "',posicion='" + oData.posicion + "')";
                    oModel.update(sPath, oData, {
                        success: function (oData, oResponse) {
                            resolve();
                        },
                        error: function () {
                            console.log("Error actualizando datos");
                            reject();
                        }
                    });
                });

            },

            setUseBatchFalse(oModel) {
                oModel.setUseBatch(false);
            },

            onPressRefresh: function () {
                this.getView().getModel().refresh();
                //sap.m.MessageToast.show("Notificacion Actualizada");
            },

            //-----
            getRelativeUrl: function (sPath) {
                var sComponent = this.getOwnerComponent().getManifest()["sap.app"]["id"];
                return jQuery.sap.getModulePath(sComponent) + sPath;
            },

            getDMSUrl: function (sPath) {
                var sComponent = this.getOwnerComponent().getManifest()["sap.app"]["id"];
                return jQuery.sap.getModulePath(sComponent) + sPath;
            },

            getData: function (path) {
                var url = this.getDMSUrl("/SDM_API/browser");
                var fullUrl = path ? url + "/" + path : url;

                return $.get({ 
                    url: fullUrl
                });
            },

            setRepoUrl: function (sRepoName, sFileName) {
                var that = this;
                this.getData("")
                    .then(response => {
                        var repos = Object.keys(response).filter(repo => response[repo].repositoryName == sRepoName);
                        var root = repos[0] + "/root"
                        var url = this.getDMSUrl("/SDM_API/browser/" + root);
                        that.repoReadData(url, sFileName);
    
                    });
            },

            repoReadData: function (sUrl, sFileName) {
                var that = this;
                this.readRepository(sUrl).then(response => {
                    var objectId = "";
                    objectId = that.getObjectId(response, sFileName);
                    that.windowOpen(sUrl, objectId, sFileName);
                });
    
            },

            readRepository: function (sUrl) {
                return $.get({
                    url: sUrl
                });
            },

            getObjectId: function (oResponse, objectName) {
                for (var i = 0; i < oResponse.objects.length; i++) {
                    var oFolderContent = {};
                    oFolderContent = oResponse.objects[i].object.properties;
                    if (oFolderContent["cmis:name"].value === objectName) {
                        return oFolderContent["cmis:objectId"].value;
                    }
                }
                return "";
            },
            
            windowOpen: function (sUrl, sObject, sName) {
                var sObjectUri = sUrl + "?objectId=" + sObject + "&cmisSelector=content&download=attachment&filename=" + sName;
                this.navigateToExternalLink(sObjectUri);
    
            },


            _getDialog3: function () {
                if (!this._oDialog3) {
                    this._oDialog3 = sap.ui.xmlfragment("profertil.notifview.view.FormattedText", this);
                }           
                return this._oDialog3;
            },

            _buildFilter: function () {

            },

            _onObjectMatched: function (oEvent) {
                //var aFilter = this._buildFilter();
                //this.byId("listID").getBinding("items").filter(aFilter); 
            }
                

            
		});
	});
