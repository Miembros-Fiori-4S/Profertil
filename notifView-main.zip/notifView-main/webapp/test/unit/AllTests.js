sap.ui.define([
	"profertil/notifview/test/unit/controller/Main.controller"
], function () {
	"use strict";
});
