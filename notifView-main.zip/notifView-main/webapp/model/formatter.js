sap.ui.define(
    [],
    function () {
        "use strict";
    
        return {

            formatCloseBtn: function (sValue) {

                if (sValue === 'S' || sValue === 'X') {
                    return true;
                }
                return false;

            },

            formatPriority: function (sValue) {

                if(sValue === '1') {
                    return 'High';
                } else if (sValue === '2') {
                    return 'Medium';
                } else if (sValue === '3') {
                    return 'Low';
                }
                return 'Low';

            },

            formatAuthor: function (sValue) {
                if (sValue === "") {
                    sValue = "Profertil";
                }
                return sValue;
            },
    
            formatTitulo: function (sValue, sTitulo) {
                if(sValue === 'N') {
                    sTitulo = "* " + sTitulo;
                } else {
    
                }
                return sTitulo;
    
            },

            formatBtnType: function (sValue) {
                if(sValue === '1') {
                    return 'Reject';
                } else if (sValue === '2') {
                    return 'Accept';
                } else if (sValue === '3') {
                    return 'Accept';
                }
                return 'Default';
            },

            formatUnread: function (sValue) {

                if (sValue === 'S' || sValue === 'X') {
                    return false;
                }
                return true;

            }


        } // return {

    } // function () {

); // sap.ui.define(