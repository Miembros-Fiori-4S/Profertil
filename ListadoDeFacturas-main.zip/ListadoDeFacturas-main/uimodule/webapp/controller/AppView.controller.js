sap.ui.define([
  "profertil/ListadoDeFacturas/controller/BaseController",
  "sap/ui/model/json/JSONModel",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/m/MessageBox",
  "sap/m/PDFViewer",
  "../model/formatter",
  "sap/m/SearchField",
], function(Controller, JSONModel, Filter, FilterOperator, MessageBox, SearchField) {
  "use strict";
  var oController;
  var PDFM = true;
  return Controller.extend("profertil.ListadoDeFacturas.controller.AppView", {

     onInit: function () {
        var oViewModel, iOriginalBusyDelay;

        // eslint-disable-next-line no-unused-vars
        oController = this;

        // keeps the search state
        this._aTableSearchState = [];

        // Model used to manipulate control states
       oViewModel = new JSONModel({
                  facturasTableTitle: this.getResourceBundle().getText(
            "facturasTableTitle"
          ),
          showStatus: true,
          showDownload: false,
          showSelectDownloads: true,
          tableSelectionMode: "None",
          dToday: new Date(),
          tableBusyDelay: 0,
          isAdmin: oController._isAdmin(),
          total: 0,
        });
        this.setModel(oViewModel, "facturasView");

        // Add the remitos page to the flp routing history
        this.addHistoryEntry(
          {
            title: this.getResourceBundle().getText("facturasViewTitle"),
            icon: "sap-icon://table-view",
            intent: `#facturas-${oController._isAdmin() ? "admin" : "display"}`,
          },
          true
        );

        var oTable = this.byId("TablaFactura");

        //Modelo Destinatario
        this._getDestinatarios();

        // Put down worklist table's original value for busy indicator delay,
        // so it can be restored later on. Busy handling on the table is
        // taken care of by the table itself.
        iOriginalBusyDelay = oTable.getBusyIndicatorDelay();

        // Make sure, busy indication is showing immediately so there is no
        // break after the busy indication for loading the view's meta data is
        // ended (see promise 'oWhenMetadataIsLoaded' in AppController)
        oTable.attachEventOnce("updateFinished", function () {
          // Restore original busy indicator delay for worklist's table
          oViewModel.setProperty("/tableBusyDelay", iOriginalBusyDelay);
        });
        if (oController._isAdmin()){
          MessageBox.information("Para Iniciar filtre por N° de Cliente");
        }
      },

      _isAdmin: function () {
        return window.location.href.toLowerCase().includes("-admin");
        // return true;
      },

      onDownloadNegocio: function (oEvent){
      var oModel = this.getView().getModel("relatedDocs");
      var ruta = oModel.sServiceUrl;
      var oTabla = oEvent.getSource().getBindingContext().getObject();
      var sPath = ruta + "/PrinterSet(TipoDoc='CON',Documento='" + oTabla.AcNegocio + "')/$value";
      var o = window.open(sPath, "_blank");
      if (o == null) {
        MessageBox.show("Ducumento no encontrado");
      }
      },

    onPress: function (oEvent) {
      if (PDFM == true){
        if (sap.ushell && sap.ushell.Container && sap.ushell.Container.getService) {
        var nroFactura =  oEvent.getSource().getBindingContext().getObject().Factura;
          var sPath = `DocumentosRel-display?&/Documento/FAC,${nroFactura}`;
          var hash = sap.ushell.Container.getService("CrossApplicationNavigation").hrefForExternal({
          target: {
          shellHash: sPath
          }
        });
        var id = window.location.href.substring(window.location.href.indexOf("true&") + 5, window.location.href.lastIndexOf("&sap-startup"));
        var url = window.location.href.replace(id, "sap-ui-app-id=profertil.RelatedsDocs").split("#")[0] + hash ;
        //var url = urlH.replace("cp.portal/ui5appruntime.html", "site");
        sap.m.URLHelper.redirect(url, true);
      }
      }
    },

      formatRowHighlight: function (oEvent) {
        var today = new Date();
        if (oEvent >= today){
          return "Success";
        }
        else {
          return "Error";
        }
      },


      onGroupButtonPressed: function () {
      if (!this._oDialog) {
        this._oDialog = sap.ui.xmlfragment("profertil.ListadoDeFacturas.view.fragments.GroupingDialog");
        this.getView().addDependent(this._oDialog);
      }
      this._oDialog.attachConfirm(this.onGroupDialogConfirm);
      this._oDialog.open();
    },
     onGroupDialogConfirm: function (oEvent) {
      var
      oControllers = this.getParent(),
        oTable = oControllers.byId("TablaFactura"),
        mParams = oEvent.getParameters();
      oControllers.getController().handleSortDialogConfirmWork(oTable, mParams);
    },
    handleSortDialogConfirmWork: function (oTable, mParams) {
      var
        sPath,
        bDescending,
        aSorters = [],
        oBinding = oTable.getBinding("items");
      sPath = mParams.sortItem.getKey();
      bDescending = mParams.sortDescending;
      aSorters.push(new sap.ui.model.Sorter(sPath, bDescending, function (oContext) {
        var name = oContext.getProperty(sPath);
        return {
          key: name,
          text: name
        };
      }));
      oBinding.sort(aSorters);
    },
    cargarModelos: function () {
      var oTable = this.byId("TablaFactura");
      var itemsTable = oTable.getItems();
      var aData = [];
      itemsTable.forEach((item2) => {
        // Se obtienen todas las filas de la tabla
        if (!(item2 instanceof sap.m.GroupHeaderListItem)) {
          aData.push(item2.getBindingContext().getObject());
        }
      });
      itemsTable.forEach((item) => {
        // Se toman todas las cabeceras de los grupos
        if (item instanceof sap.m.GroupHeaderListItem) {
          // valorAgrupado = Titulo de la cabecera
          var valorAgrupado = item.getTitle();
          var sum = 0;
          aData.forEach((valor) => {
            var sorter = oTable.getBinding("items").sSortParams.replace("$orderby=", '').replace(/%(.*)/g, '');
            // se controla que el item seleccionado pertenece al grupo en el que se esta trabajando
            if (valor[sorter] === valorAgrupado) {
              // Se suma al valor total del campo seleccionado (en este caso, saldo)
              sum += parseFloat(valor.Fkimg);
            }
          });
          // se setea en la cabecera del grupo el titulo junto al subtotal de los campos seleccionados
          item.setTitle(valorAgrupado + " - Total Facturado: " + sum);
        }
      });
    },



          /**
       * Triggered by the table's 'updateFinished' event: after new table
       * data is available, this handler method updates the table counter.
       * This should only happen if the update was successful, which is
       * why this handler is attached to 'updateFinished' and not to the
       * table's list binding's 'dataReceived' method.
       * @param {sap.ui.base.Event} oEvent the update finished event
       * @public
       */
      onTableUpdateFinished: function (oEvent) {
        /**
         * Convenience function.
         *
         * Determines if is a GroupHeaderList Item or not
         *
         * @function
         * @private
         * @param {object} oItem a Table item
         * @returns {boolean} if is a GroupHeader
         */
        const isGroupHeader = (oItem) => {
          return oItem instanceof sap.m.GroupHeaderListItem;
        };

        // The sap.m.Table
        var oTable = oEvent.getSource(),
          // All table items
          aItems = oTable.getItems(),
          // Entites objects
          aEntities = aItems
            // Filter Group Headers
            .filter((oItem) => !isGroupHeader(oItem))
            // Retrieve entity
            .map((oItem) => oItem.getBindingContext().getObject()),
          // All Group Headers Items
          aGroupHeaders = aItems.filter((oItem) => isGroupHeader(oItem));

        // The current sort property that bindings are ordered by.
        var sProperty = oController._getSortProperty(oTable);

        // Count total
        oController._adjustTotalCounter(aEntities);

        // Set titles for all headers
        if (aGroupHeaders.length > 0)
          oController._adjustGroupHeaders(aGroupHeaders, aEntities, sProperty);
      },

      /**
       * Convenience Method for obtaining sort property.
       *
       * Obtains current ordered by property in table.
       *
       * @function
       * @private
       * @param {sap.m.Table} oTable the table from where obtain sort property
       * @returns {string} the ordered by property
       */
      _getSortProperty: (oTable) => {
        var sSortParams = oTable.getBinding("items").sSortParams;
        return sSortParams
          ? sSortParams.replace("$orderby=", "").replace(/%(.*)/g, "")
          : undefined;
      },

      /**
       *  Sets total counter.
       *
       *  Obtains total tns and sets its property in view model.
       * @function
       * @private
       * @param {*} aEntities
       */
      _adjustTotalCounter: function (aEntities) {
        var iTns = oController._getTotalTns(aEntities),
          oViewModel = oController.getModel();
        oViewModel.setProperty("/total", iTns);
      },
        onGroup: () => {
        oController.openFragment(
          // Fragment name must be in /view/fragments/<name> and controller /controller/fragments/<name>
          "GroupingDialog",
          // Model to be set,
          null,
          // Always update model when openning
          true,
          // Callback function
          undefined,
          // Data passed,
          oController.byId("TablaFactura")
        );
      },
      /**
       * Convenience method for setting Group Header Titles.
       *
       * Sets group header titles with total.
       *
       * @param {array} aGroupHeaders the array of all Group Headers
       * @param {array} aEntities the array of all entities entries
       * @param {string} sProperty the current ordered by property
       */
      _adjustGroupHeaders: function (aGroupHeaders, aEntities = [], sProperty) {
        aGroupHeaders.forEach((oGroupHeader) => {
          // Current Group
          var sGroupValue = oController._obtainGroupValue(oGroupHeader),
            // Entities in current group
            aGroupEntities = aEntities.filter(
              (oEntity) => oEntity[sProperty] === sGroupValue
            );

          var iSubTotal = oController._getTotalTns(aGroupEntities);

          oGroupHeader.setTitle(
            `${sGroupValue} - Toneladas: ${oController.formatter.toLocaleNumber(
              iSubTotal
            )} tns`
          );
        });
      },

      /**
       * Obtains Group Property Value
       *
       * @function
       * @private
       * @param {sap.m.GroupHeaderListItem} oGroupHeader the group header item
       * @returns {string} the title value
       */
      _obtainGroupValue: function (oGroupHeader) {
        var sTitle = oGroupHeader.getTitle(),
          iIndex = sTitle.indexOf("-"),
          sValue = iIndex > 0 ? sTitle.substr(0, iIndex) : sTitle;
        return oController.formatter.removeLabel(sValue);
      },

      /**
       * @function
       * @private
       * @param {array} aEntities the object entities of Remitos
       * @return {number}
       */
      _getTotalTns: function (aEntities = []) {
        return oController.formatter.sumList(aEntities, "Fkimg");
      },

      onBeforeRebindTable: function (oEvent) {
        //var today = new Date();
        var oCompensadas;
        this.getView().byId("valueHelpDestinatario").setRequired(true);
        //var dd = today.getDate();
        //var mm = today.getMonth()+1; //January is 0!
        //var yyyy = today.getFullYear();
        //var fechaHoy = ( dd+'/'+mm+'/'+yyyy);
        var mBindingParams = oEvent.getParameter("bindingParams");
        var oSmtFilter = this.getView().byId("smartFilterBar");

        //Werks Custom Filter
        var oComboBox = oSmtFilter.getControlByKey("Estado");
        var sWerks = oComboBox.getSelectedKeys();
        if(sWerks.length > 1) {
          sWerks = ["C"];
        }
        if (sWerks == "C") {
          oCompensadas = "C"
          var FiltroCom = new Filter(
          "Compensada",
          FilterOperator.EQ,
          oCompensadas
          );
          mBindingParams.filters.push(FiltroCom);
        }
        else if (sWerks == "S"){
          oCompensadas = "S"
          var FiltroSin = new Filter(
            "Compensada",
            FilterOperator.EQ,
            oCompensadas
            );
          mBindingParams.filters.push(FiltroSin);
        }

        //AcNegocio Custom Filter
        var oInput = oSmtFilter.getControlByKey("AcNegocio"),
          sAcNegocio = oInput.getValue();
        if (sAcNegocio) {
          var oNegocioFilter = new Filter(
            "AcNegocio",
            FilterOperator.EQ,
            sAcNegocio
          );
          mBindingParams.filters.push(oNegocioFilter);
        }

        // Kunag Custom Filter
        oInput = oSmtFilter.getControlByKey("Kunag");
        var sKunagText = oInput.getValue();
        var sKunag = [];
        
        if(sKunagText === "" || sKunagText === null || sKunagText === undefined) {
          sKunag = "";
        } else {
          var sKunagFilter = this.oDestinatariosModel.getData().filter((oKunag) => sKunagText === oKunag.name);
          sKunag = sKunagFilter[0].kunnr;
          // sKunagFilter.forEach((aKunag) => )
        }
        // if (sAcNegocio && oController._isAdmin()) {
         var oKunagFilter = new Filter("Kunag", FilterOperator.EQ, sKunag);
         mBindingParams.filters.push(oKunagFilter);
        // }

        //Kunnr custom filter
        var oInput = oSmtFilter.getControlByKey("Kunnr"),
          sKunnr = oInput.getValue();
        if (sKunnr) {
          var oKunnrFilter = new Filter(
            "Kunnr",
            FilterOperator.EQ,
            sKunnr
          );
          // mBindingParams.filters.push(oKunnrFilter);
        }
      },

      //Datos ValueHelp Destinatario
      _getDestinatarios: async function() {
        this.getView().getModel().read("/DestinatarioSet", {
          success: function(oData) {
            this.oDestinatariosModel = new sap.ui.model.json.JSONModel(oData.results);
          }.bind(this),
          error: function(oError) {
            console.log(oError);
          }
        })
      },

      //Value Help Destinatario
      onValueHelpRequested: function() {
        this._oBasicSearchField = new SearchField();
        sap.ui.core.Fragment.load({
          name: "profertil.ListadoDeFacturas.view.fragments.DestinatarioValueHelp",
          controller: this
        }).then(function name(oFragment) {
          this._oVHD = oFragment;
          this._oValueHelpDialog = sap.ui.xmlfragment("profertil.ListadoDeFacturas.view.fragments.DestinatarioValueHelp", this);
          this.getView().addDependent(this._oValueHelpDialog);
          this._oValueHelpDialog.getTableAsync().then(function (oTable) {
            let columnas = {
              "cols": [
                        { "label": "Nombre Destinatario", "template": "name", "width": "20%"} ]
            };

          oTable.setModel(new sap.ui.model.json.JSONModel(columnas), "columns");
          oTable.setModel(this.oDestinatariosModel);
          oTable.bindAggregation("rows", "/");

          this._oValueHelpDialog.update();
        }.bind(this));

        this._oValueHelpDialog.open();
        }.bind(this));
      },

      onValueHelpCancelPress: function () {
        this._oValueHelpDialog.close();
      },

      onValueHelpOkPress: function(oEvent) {
        var oFilterDestinatario = this.getView().byId("valueHelpDestinatario");
        let aTokens = oEvent.getParameter("tokens");
        oFilterDestinatario.setValue(aTokens[0].getProperty("key").trim());
        this._oValueHelpDialog.close();
      },

      onFilterBarSearch: function (oEvent) {
        var that = this;
        var aSelectionSet = oEvent.getParameter("selectionSet");
  
        var aFilters = aSelectionSet.reduce(function (aResult, oControl) {
          if (oControl.getValue()) {
            aResult.push(new Filter({
              path: oControl.getName(),
              operator: FilterOperator.Contains,
              value1: oControl.getValue()
            }));
          }
  
          return aResult;
        }, []);
        
        if(aSelectionSet[0]._sPrevSuggValue === undefined || aSelectionSet[0]._sPrevSuggValue === null) {
          aSelectionSet[0]._sPrevSuggValue = "";
        }
        
        // if (aSelectionSet[1]._sPrevSuggValue === undefined || aSelectionSet[1]._sPrevSuggValue === null) {
        //   aSelectionSet[1]._sPrevSuggValue = "";
        // }

        aFilters.push(new Filter({
          filters: [
            // new Filter({ path: "kunnr", operator: FilterOperator.Contains, value1: aSelectionSet[0]._sPrevSuggValue}),
            new Filter({ path: "name", operator: FilterOperator.Contains, value1: aSelectionSet[0]._sPrevSuggValue })
          ],
          and: false
        }));

        if(aFilters[0].oValue1 === null || aFilters[0].oValue1 === undefined){
          this._getDestinatarios().then(function (oTable) {
            that._oValueHelpDialog.getTable().setModel(that.oDestinatariosModel);
          });
        } else {
          this._oValueHelpDialog.getTable().getBinding().filter(aFilters);
        }
      },

      _filterTable: function (oFilter) {
        var oVHD = this._oVHD;
  
        oVHD.getTableAsync().then(function (oTable) {
          if (oTable.bindRows) {
            oTable.getBinding("rows").filter(oFilter);
          }
          if (oTable.bindItems) {
            oTable.getBinding("items").filter(oFilter);
          }
          // This method must be called after binding update of the table.
          oVHD.update();
        });
      },

      _descargarPDF: function(sEntrega){
          var factura = "FAC";
          ////var oModel = new sap.ui.model.odata.ODataModel("/sap/opu/odata/sap/ZCV_FACTURAS_SRV");
          var oModel = this.getView().getModel("relatedDocs");
          var sServiceUrl = oModel.sServiceUrl;
          ////var sSource = sServiceUrl + "/PrinterSet(TipoDoc='CON',Documento='" + factura + "')/$value";
          var sSource= `${sServiceUrl}/PrinterSet(TipoDoc='${factura}',Documento='${sEntrega}')/$value`;
          $.get({
            url: sSource,
            success: function () {
              window.open(sSource, "_blank");
            }
        }).fail(function () {
          MessageBox.show("Ducumento no encontrado");
        });
    },
       onDisplayXlbnr: (oEvent) => {
        // The id of 'Factura'
        var factura =  oEvent.getSource().getBindingContext().getObject().Factura;
        // Download PDF based on 'Factura' ID
        oController._descargarPDF(factura);
      },
      onPDFMAS: function(){
        PDFM = false;
        this.byId("pDFMAS").setVisible(false);
        this.byId("descargar").setVisible(true);
        this.byId("cancelar").setVisible(true);
        this.byId("TablaFactura").setMode("MultiSelect");
      },
      onDescargar: () => {
        // Obtain table
        var oTable = oController.byId("TablaFactura");
        var aItems = oTable.getSelectedItems();

        aItems.forEach((oItem, iDelay) =>
          setTimeout(() => {
            oController._descargarPDF(
               oItem.getBindingContext().getObject().Factura
            );
          }, iDelay * 2000
          )
        );
      },
      onCancelar: function(){
        PDFM = true;
        this.byId("pDFMAS").setVisible(true);
        this.byId("descargar").setVisible(false);
        this.byId("cancelar").setVisible(false);
        this.byId("TablaFactura").setMode("SingleSelectMaster");
      }
  });
});