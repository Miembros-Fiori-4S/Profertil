sap.ui.define([], function () {
	"use strict";
  return {
      dateFormat: (dDate) => {
  return dDate ? dDate.toLocaleDateString() : "";
  },
    sumList: function (aList, sProperty) {
      return aList.reduce(function (a, b) {
        return a + parseFloat(b[sProperty]);
      }, 0);
    },
    toMandatory: (bMandatory = false) => {
      return bMandatory
        ? sap.ui.comp.smartfilterbar.MandatoryType.mandatory
        : sap.ui.comp.smartfilterbar.MandatoryType.auto;
    },
    removeLabel: (str) => {
      try {
        return /:(.+)/.exec(str)[1].trim();
      } catch (err) {
        return str.trim();
      }
    },
        toLocaleNumber: Intl.NumberFormat().format,

    toNumber: function (fValue) {
      fValue = parseFloat(fValue);
      return Intl.NumberFormat().format(fValue.toFixed(2));
    },
  };
});
