sap.ui.define([], function () {
	"use strict";
	return {

        formatStatus: function (sValue) {
            if (sValue === 'Abierto') {
                return "Warning";
            }
            return "Success";
        },
        
        statusRow: function (sValue, sValue2) {
            
            if (sValue2 === "") {
                return "Warning";  // no tiene factura
            }

            if (sValue === 'X') {
                return "Error";   // tiene factura y tiene mora
            }

			return "Success"; // tiene factura y no tiene mora
			
        },

        convertToFloat: function (sValue) {
            return parseFloat(sValue);
        },

        convertToFloat2: function (sValue) {
            return parseFloat(sValue).toFixed(2);
        },

        setGraphColor: function (sValue1, sValue2) {

            var fResultado = 0;
            var iPorcentaje = 8;
            var fPorcentaje = 0;
            if (parseFloat(sValue2) <= 6){
                return "Error";
            } else {
                fPorcentaje = (sValue1 * iPorcentaje)/100;
                if (parseFloat(sValue2) <= parseFloat(fPorcentaje)) {
                    return "Error";
                }
            }
            
            return "Good"
        },

        formatVencido: function (sVencido) {
            if (sVencido === 'X'){
                return "Error";
            }
            return "Success";
        },

        formatCompensado: function (sValue) {
            if (sValue) {
                if (sValue === "S") {
                    return "Pagada";
                } else {
                    return "No Pagada";
                }
            }
            return "No Facturado";
        },

        formatCompensadoState: function (sValue) {
            if (sValue) {
                if (sValue === "S") {
                    return "Success";
                } else {
                    return "Error";
                }               
            }
            return "Warning";
        },

        formatCompensadoIcon: function (sValue) {
            if (sValue) {
                if (sValue === "S") {
                    return "sap-icon://message-success";
                } else {
                    return "sap-icon://message-error";
                }               
            }
            return "sap-icon://message-warning";
        },

        formatHighlight: function (sValue) {
            var dDate = new Date();
            dDate.setMonth(dDate.getMonth()-11);
            if (dDate >= sValue) {
                return "Error";
            }
            return "Success";
        }
        
	};
});