sap.ui.define([
	"profertil/pendret1/test/unit/controller/MainView.controller"
], function () {
	"use strict";
});
