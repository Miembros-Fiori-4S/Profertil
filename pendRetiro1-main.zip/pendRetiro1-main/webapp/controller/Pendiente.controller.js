sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "../model/formatter",
    "sap/ui/model/json/JSONModel",
    "sap/ui/core/Fragment",
    "sap/ui/model/Filter",
    "sap/ui/model/FilterOperator"
], 
function (Controller, formatter, JSONModel, Fragment, Filter, FilterOperator) {
	"use strict";
	return Controller.extend("profertil.pendret1.controller.Pendiente", {
        
        formatter: formatter, 
        
        onInit: function () {
            var oModel = new JSONModel({
                isAdmin: this._isAdmin(),
                kunnr: "",
                name1: ""
            });
            this.getView().setModel(oModel, "viewModel");
            this.setIgnorePersonalization();
            this.setName();

        },

        setIgnorePersonalization: function () {
            var oSmartTable = this.byId("smItems");
            //oSmartTable.setIgnoredFields("kkber,kkbtx,klmeng");
            if (this._isAdmin()) {
                oSmartTable.setIgnoreFromPersonalisation("posnr,kondm,gbstk,gbstktxt,bzirk,kkber,kkbtx,klmeng,mora,vencido,bstdk_e");
            } else {
                oSmartTable.setIgnoreFromPersonalisation("kunnr,name1,matnr,posnr,werks,kondm,gbstk,bzirk,bztxt,netpr,kkber,kkbtx,klmeng,mora,vencido,bstdk_e,facturado");
            }

        },

        setName: function () {
            if (this._isAdmin()) {
                
            } else {
                var oModel = this.getOwnerComponent().getModel();
                var sPath = '/PendienteSet?$top=1';
                var that = this;
                oModel.read(sPath, {
                    success: function (oData) {
                        that.getView().getModel("viewModel").setProperty("/name1", oData.results[0].name1);
                        that.getView().getModel("viewModel").setProperty("/kunnr", oData.results[0].kunnr);
                    },
                    error: function () {
                        that.getView().getModel("viewModel").setProperty("/name1","");
                        that.getView().getModel("viewModel").setProperty("/kunnr","");
                    }
                });
                                
            }
            
        },
        
        onNegocioPress: function (oEvent) {
            var sVbeln = oEvent.getSource().getBindingContext().getProperty("vbeln");
            var sPosnr = oEvent.getSource().getBindingContext().getProperty("posnr");
            
            var oRouter = sap.ui.core.UIComponent.getRouterFor(this);
			oRouter.navTo("Negocio", {
                vbeln: sVbeln,
                posnr: sPosnr
			});

        },

        onUpdateFinished: function (oEvent) {
            var aFilters = this.byId("tableData").getBinding("items").aApplicationFilters;
            var sHeaderText = "";
            //var fSaldo = 0;
            var oSmtable = this.byId("smItems");
            
            if (aFilters.length === 0) {
                sHeaderText = this.getView().getModel("i18n").getResourceBundle().getText("pendRetTxt");
                oSmtable.setHeader(sHeaderText);
            } else {
                this._calcularSaldo(aFilters);
            }
            
        },

        sumSaldo: function (oData) {
            var sum = 0;
            oData.forEach((item) => {
                sum += parseFloat(item.saldo); 
            });
            this.setSaldo(sum);

        },

        setSaldo: function (fSaldo) {
            var sHeaderText = "";
            var oSmtable = this.byId("smItems");
            var fSaldo2 = fSaldo.toFixed(2);
            var sTitle = this.getView().getModel("i18n").getResourceBundle().getText("pendRetTxt");
            sHeaderText = sTitle + " : " + fSaldo2 + " tn";
            oSmtable.setHeader(sHeaderText);

        },

        onBeforeRebindTable: function (oEvent) {

        },

        _calcularSaldo: function (aFilters) {
            var oModel = this.getView().getModel();
            var sPath = "/PendienteSet";
            var that = this;
            oModel.read(sPath, {
                success: function (oData, response) {
                    that.sumSaldo(oData.results);
                },
                error: function (oError) {
                    that.setSaldo(0);
                },
                filters: aFilters
            });

        },

        _isAdmin: function () {
            return !window.location.href.includes("-display");
        }


    });

});
