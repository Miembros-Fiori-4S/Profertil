sap.ui.define([
    "sap/ui/core/mvc/Controller",
    "sap/ui/core/routing/History",
    "../model/formatter"
    ],
	
	function (Controller, History, formatter) {
		"use strict";

		return Controller.extend("profertil.pendret1.controller.DetalleNegocio", {
            formatter: formatter,
            
            onInit: function () {

                var oViewModel = new sap.ui.model.json.JSONModel({
                    vbeln: ""
                });
                this.getView().setModel(oViewModel, "viewModel");

                const oRouter = sap.ui.core.UIComponent.getRouterFor(this);
                oRouter.getRoute("Negocio").attachMatched(this._onRouteMatched, this);

            },

            openPDF: function (sTipo, sDocnumber) {
                var oModel = this.getView().getModel("relatedDocs");
                var sServiceUrl = oModel.sServiceUrl;
                var sPath = "/PrinterSet(TipoDoc='" + sTipo + "',Documento='" + sDocnumber + "')/$value";
                var sSource = sServiceUrl + sPath;
                sap.m.URLHelper.redirect(sSource, true); 
                
            },

            onPressAcuerdo: function (oEvent) {
                var sDocnumber = oEvent.getSource().getBindingContext().getProperty("vbeln");
                this.openPDF("CON", sDocnumber);

            }, 

            onPressRemito: function (oEvent) {
                var sDocnumber = oEvent.getSource().getBindingContext().getProperty("vbeln_e");
                this.openPDF("REM", sDocnumber);

            },
            
            onPressFactura: function (oEvent) {
                
            },

            _onRouteMatched: function (oEvent) {
                
                var sVbeln = oEvent.getParameter("arguments").vbeln;
                var sPosnr = oEvent.getParameter("arguments").posnr;
                
                this.getView().getModel("viewModel").setProperty("/vbeln", sVbeln);
                
                var oModel = this.getView().getModel();
                oModel.metadataLoaded().then( function() {
                    var sObjectPath = oModel.createKey("PendienteSet", {
                        vbeln : sVbeln,
                        posnr: sPosnr
                    });
                    this._bindView("/" + sObjectPath);
                }.bind(this));
                this._rebindTables();

            },

            onBeforRebindF: function (oEvent) {

                var aFilter = [];
                var sVbeln = this.getView().getModel("viewModel").getProperty("/vbeln");  
                var sPosnr = this.getView().getModel("viewModel").getProperty("/posnr");               
                var oBinding = oEvent.getParameter("bindingParams");
                
                var oFilter = new sap.ui.model.Filter("vbeln", sap.ui.model.FilterOperator.EQ, sVbeln);
                oBinding.filters.push(oFilter);
                var oFilter = new sap.ui.model.Filter("posnr", sap.ui.model.FilterOperator.EQ, sPosnr);
                oBinding.filters.push(oFilter);        
            
            },

            _rebindTables: function () {
                var oSmartTable = null;
                oSmartTable = this.byId("smFacturas");
                if (oSmartTable) { 
                    oSmartTable.rebindTable();
                }

            },

            _bindView : function (sObjectPath) {
                
                var oDataModel = this.getView().getModel();
                var that = this;
                this.getView().bindElement({
                    path: sObjectPath,
                    events: {
                        dataRequested: function () {
                            oDataModel.metadataLoaded().then(function () {
                                that.getView().setBusy(true);
                            });
                        },
                        dataReceived: function () {
                            that.getView().setBusy(false);
                        }
                    }
                });
                
            },
            

        });
        
    });