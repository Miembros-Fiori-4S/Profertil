sap.ui.define([
  "profertil/movimientos/controller/BaseController",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox"
], function (Controller, Filter, FilterOperator, JSONModel, MessageBox) {
    "use strict";

    return Controller.extend("profertil.movimientos.controller.MainView", {
      onInit: function() {
        var uiModel = new JSONModel({
          showTotales: false
        });

        this.getView().setModel(uiModel, "UI");
      },

      onBeforeRebindTable: function (oEvent) {
        var mBindingParams = oEvent.getParameter("bindingParams");

        this._updateTotals();
        
        this._addFilters(mBindingParams.filters);
      },

      _addFilters: function (arr, { fecha } = {}) {
        var smartFilterBar = this.getView().byId("smartFilterBar");

        var dateFilter = [ smartFilterBar.getControlByKey("customFechaMov").getFrom(), smartFilterBar.getControlByKey("customFechaMov").getTo() ];
        var materialFilter = smartFilterBar.getControlByKey("customMaterial").getSelectedKey();
        var almacenFilter = smartFilterBar.getControlByKey("customAlmacen").getSelectedKey();
        var centroFilter = smartFilterBar.getControlByKey("customCentro").getSelectedKey();
        
        if (dateFilter[0]) arr.push(new Filter({ path: fecha ? fecha : "FechaEntrada", operator: FilterOperator.BT, value1: dateFilter[0], value2: dateFilter[1]}));
        if (materialFilter) arr.push(new Filter({ path: "Material", operator: FilterOperator.EQ, value1: materialFilter }));
        if (almacenFilter) arr.push(new Filter({ path: "Almacen", operator: FilterOperator.EQ, value1: almacenFilter }));
        if (centroFilter) arr.push(new Filter({ path: "Centro", operator: FilterOperator.EQ, value1: centroFilter }));
        
      },

      _updateTotals: function() {
        var filters = [];

        this._addFilters(filters, { fecha: "Fecha" });

        var hBox = this.byId("totalHBox");

        if (filters.length > 0) {
          this.getView().getModel().read("/TotalSet", {
            filters: filters,
            success: function(data) {
              var totals = data.results[0];

              if (totals) this.getView().getModel("UI").setData({ showTotales: true });
              this.getView().setModel(new JSONModel(totals), "Totales");
            }.bind(this),
            error: function(err) {
              MessageBox.error("Hubo un error al traer los datos de los totales.");
              this.getView().getModel("UI").setData({ showTotales: false });
            }.bind(this)
          })
        } else {
          this.getView().getModel("UI").setData({ showTotales: false });
          this.getView().getModel("Totales").setData(null);
        }
      },

      formatDate: function(date) {
        var oDate = new Date(date);

        let day = oDate.getDate();
        let month = oDate.getMonth() + 1;
        let year = oDate.getFullYear();

        day = day < 10 ? `0${day}` : day;
        month = month < 10 ? `0${month}` : month;

        return `${day}/${month}/${year}`;
      },

      formatTonStatus: function(ton) {
        if (parseFloat(ton) < 0) return 'Error';
      },
      
      formatTotal: function(str) {
        if (str.indexOf("-") != -1) return - (parseFloat(str));

        return parseFloat(str).toString();
      },

      getTipoMov: function(cod) {
        switch (cod) {
          case '202':
          case '501':
          case '511':
          case '602':
          case '922':
            return 'Entrada';
          case '309':
          case '343':
          case '344':
            return 'Ent/Sal';
          case '502':
          case '601':
          case '921':
            return 'Salida';
          default:
            return cod;
        }
      }
    });
});
