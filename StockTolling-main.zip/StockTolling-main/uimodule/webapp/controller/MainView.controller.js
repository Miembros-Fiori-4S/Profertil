sap.ui.define([
  "profertil/stock/controller/BaseController",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/export/library",
	"sap/ui/export/Spreadsheet",
  "sap/m/MessageBox"
], function (Controller, Filter, FilterOperator, exportLibrary, Spreadsheet, MessageBox) {
  "use strict";

  var EdmType = exportLibrary.EdmType;

  return Controller.extend("profertil.stock.controller.MainView", {
    onInit: function () {
      this._filterTable();
    },

    onTabSelect: function () {
      this.byId("materialCB").setSelectedKey(null);
      this.byId("materialCB").setValue(null);
      
      this._filterTable();
    },

    onSearch: function () {
      var plantFilter = this.byId("plantaCB").getSelectedKeys();
      if (plantFilter.length === 0) {
        MessageBox.information("Filtro por Planta obligatorio para realizar busqueda");
      } else {
        this._filterTable();
      };
      // this._filterTable();
    },

    onPlantChange: function (oEvent) {
      // var key = oEvent.getSource().getSelectedKey();
      // var almacenCB = this.byId("almacenCB")
      // var oBinding = almacenCB.getBinding("items");

      // almacenCB.setSelectedKey();
      // almacenCB.setValue();

      // oBinding.filter([new Filter({ path: "Key", operator: FilterOperator.EQ, value1: key })])
    },

    onMaterialChange: function (oEvent) {
      // var key = oEvent.getSource().getSelectedKey();
      // var materialCB = this.byId("materialCB")
      // var oBinding = materialCB.getBinding("items");

      // // almacenCB.setSelectedKey();
      // // almacenCB.setValue();

      // // oBinding.filter([new Filter({ path: "Matnr", operator: FilterOperator.EQ, value1: key })]);
      // var oBinding = this.byId("stockTable").getBinding("items");
      // var filters = [];

      // this._addFilters(filters);
      // // this._filterByMaterial(filters);

      // oBinding.filter(filters);
    },

    onResetFilters: function () {
      var filters = [
        this.byId("plantaCB"),
        this.byId("almacenCB"),
        this.byId("materialCB")
      ];

      filters.forEach(filter => {
        filter.setSelectedKey();
        filter.setValue();
      });

      this._filterTable();
    },

    onExport: function() {
			var aCols, oRowBinding, oSettings, oSheet, oTable;

			if (!this._oTable) {
				this._oTable = this.byId('detailsTable');
			}

			oTable = this._oTable;
			oRowBinding = oTable.getBinding('items');
			aCols = this.createColumnConfig();

			oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: 'Level'
				},
				dataSource: oRowBinding,
				fileName: 'cupos.xlsx',
				worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function() {
				oSheet.destroy();
			});
    },

    onVigenciasButtonPress: function() {
      if (!this._oDialog) {
        this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "profertil.stock.view.Vigencias", this);
        this.getView().addDependent(this._oDialog);
      }

      this._oDialog.open();
    },

    onConfirmarVigencia: function(oEvent) {
      var that = this;
      var table = this.byId("validityTable");
      var items = table.getBinding("items").getCurrentContexts().map(item => {
        var { TipoCarga, CargaTexto, Valor } = item.getObject();

        return { TipoCarga, CargaTexto, Valor: parseInt(Valor) };
      });
      
      var oModel = this.getView().getModel();
      var arrayOfPromises = [];

      oModel.setUseBatch(false);

      items.forEach(item => {
        var createVigencia = oModel.create("/VigenciaSet", item, { groupId: "vigencia-" + item.TipoCarga })
        arrayOfPromises.push(createVigencia);
      });

      Promise.all(arrayOfPromises).then(function(promiseResolve) {
        that.onCloseDialog();
        MessageBox.success("Se actualizan vigencias");
        // oModel.submitChanges({
        //   success: function (oData) {
        //     that.onCloseDialog();
        //     MessageBox.success("Se actualizan vigencias");
            
        //   },
        //   error: function (oError) {
        //     that.onCloseDialog();
        //     MessageBox.error("Error al actualizar vigencias");
        //   }
        // });
      }.bind(this))
      .catch(function(err) {
        that.onCloseDialog();
        MessageBox.error("Error al actualizar vigencias");
      }.bind(this));
    },

		createColumnConfig: function() {
			var aCols = [];

			aCols.push({
				label: 'Cupo',
				property: 'Vbeln',
				type: EdmType.String
			});

			aCols.push({
				label: 'Fecha',
				type: EdmType.Date,
				property: 'Fecha'
			});

			aCols.push({
				property: 'Reserva',
        type: EdmType.String,
        label: 'Carta de Porte'
			});

			aCols.push({
				property: 'Destinatario',
				type: EdmType.String
			});

			aCols.push({
				property: 'Ton',
				type: EdmType.String
			});

			aCols.push({
				property: 'MaterialTexto',
        type: EdmType.String,
        label: 'Material Texto'
			});

			aCols.push({
				property: 'Material',
				type: EdmType.String
			});

			aCols.push({
				property: 'Incoterm',
				type: EdmType.String
			});

			return aCols;
		},

    onPressCupos: function (oEvent) {
      var item = oEvent.getSource().getParent().getParent().getBindingContext().getObject();

      if (!this._oDialog) {
        this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "profertil.stock.view.Cupos", this);
        this.getView().addDependent(this._oDialog);
      }

      this._oDialog.open();

      this._bindCuposTable(item);
    },

    onCloseDialog: function () {
      this._oDialog.close();
      this._oDialog.destroy();

      this._oDialog = null;
    },


    setMaterialData: function (filters) {
      var materialFilter = this.byId("materialCB");
      var oBinding = materialFilter.getBinding("items");

      oBinding.filter(filters);
    },

    _filterTable: function (init) {
      var oBinding = this.byId("stockTable").getBinding("items");
      var filters = [];

      this._addFilters(filters);

      var materialFilter = this.byId("materialCB").getSelectedKey();

      if (materialFilter) filters.push(new Filter({ path: "Matnr", operator: FilterOperator.EQ, value1: materialFilter }))
      else this._filterByMaterial(filters);

      // this._filterByMaterial(filters);

      oBinding.filter(filters);
    },

    _filterByMaterial: function (arr) {
      var iconBar = this.byId("iconTabBar");
      var selectedItem = iconBar.getSelectedKey();

      var filters = [];

      switch (selectedItem) {
        case 'materiales':
          filters.push(new Filter({ path: "Matnr", operator: FilterOperator.BT, value1: "000000000000001000", value2: "000000000000001099" }));
          filters.push(new Filter({ path: "Matnr", operator: FilterOperator.EQ, value1: "000000000000000072"}));
          break;
        case 'embalajes':
          filters.push(new Filter({ path: "Matnr", operator: FilterOperator.BT, value1: "000000000000001100", value2: "000000000000001199" }));
          break;
        default:
          break;
      }

      if (filters.length) {
        arr.push(...filters);
        this.setMaterialData(filters);
      }
    },

    _addFilters: function (arr) {
      var plantFilter = this.byId("plantaCB").getSelectedKeys();
      var warehouseFilter = this.byId("almacenCB").getSelectedKey();
      var materialFilter = this.byId("materialCB").getSelectedKey();
      var statusFilter = this.byId("statusCB").getSelectedKey();

      if (plantFilter) {
        plantFilter.forEach(aPlanta => {
          arr.push(new Filter({ path: "Planta", operator: FilterOperator.EQ, value1: aPlanta }));
        });
        // arr.push(new Filter({ path: "Planta", operator: FilterOperator.EQ, value1: plantFilter }));
      }
      if (warehouseFilter) arr.push(new Filter({ path: "Almacen", operator: FilterOperator.EQ, value1: warehouseFilter }));
      if (statusFilter) arr.push(new Filter({ path: "Status", operator: FilterOperator.EQ, value1: statusFilter }))
      
      if (materialFilter) arr.push(new Filter({ path: "Matnr", operator: FilterOperator.EQ, value1: materialFilter }))
      else this._filterByMaterial(arr);
    },

    _filterCupos: function({ Matnr, Planta, Almacen }) {
      var aFilters = [
        new Filter({ path: "Planta", operator: FilterOperator.EQ, value1: Planta }),
        new Filter({ path: "Almacen", operator: FilterOperator.EQ, value1: Almacen }),
        new Filter({ path: "Material", operator: FilterOperator.EQ, value1: Matnr })
      ]      

      var oTable = this.byId("detailsTable");

      var oBinding = oTable.getBinding("items");

      oBinding.filter(aFilters);
    },

    _bindCuposTable: function (item) {
      this._filterCupos(item);
    },

    formatDate: function(date) {
      var oDate = new Date(date);

      let day = oDate.getUTCDate();
      let month = oDate.getUTCMonth() + 1;
      let year = oDate.getUTCFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    formatMaterial: function(matnr, text) {
      return parseInt(matnr) + ' ' + text;
    },

    parseNumber: function(str) {
      return parseInt(str);
    },

    formatFloat: function(num) {
      var iconBar = this.byId("iconTabBar");
      var selectedItem = iconBar.getSelectedKey();

      switch (selectedItem) {
        case 'materiales':
          return parseFloat(num).toFixed(2);
        case 'embalajes':
          return parseInt(num);
        default:
          break;
      }
    },

    formatStatus: function(status) {
      switch (status) {
        case '1':
          return 'Success';
        case '2':
          return 'Warning';
        case '3':
          return 'Error';
      }
    },

    getStatusText: function(status) {
      switch (status) {
        case '1':
          return 'Ok';
        case '2':
          return 'Alerta de stock'
        case '3':
          return 'Stock insuficiente';
      }
    }
  });
});
