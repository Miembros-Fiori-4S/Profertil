
sap.ui.define([
  "sap/ui/core/mvc/Controller",
  "sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
  "sap/ui/core/Fragment",
  "sap/m/MessageBox",
  "sap/m/PDFViewer"
],
	/**
	 * @param {typeof sap.ui.core.mvc.Controller} Controller
	 */
  function (Controller, Filter, FilterOperator, Fragment, MessageBox, PDFViewer) {
    "use strict";

    return Controller.extend("profertil.compensaciones.controller.MainView", {
      onInit: function () {
        this._pdfViewer = new PDFViewer();
        this.getView().addDependent(this._pdfViewer);
        //   var oFilter = this.getView().byId("filterbar"),
        //   that = this;


        // oFilter.addEventDelegate({
        //   "onAfterRendering": function (oEvent) {
        //     var oResourceBundle = that.getOwnerComponent().getModel("i18n").getResourceBundle();
        //     var oButton = oEvent.srcControl._oSearchButton;
        //     oButton.setText(oResourceBundle.getText("Buscar Compensaciones"));
        //   }
        // });
      },

      onPdfDocumento: function (oEvent) {
        var oTabla = oEvent.getSource().getBindingContext().getObject();
        var ruta = this.getView().getModel().sServiceUrl;
        // eslint-disable-next-line camelcase
        var lv_path = ruta + "/PdfSet('" + oTabla.IDComp + oTabla.Fecha + oTabla.Kunnr + "')/$value";
        // window.open(lv_path);

        this._pdfViewer.setSource(lv_path);
        this._pdfViewer.setTitle("Compensacion");
        this._pdfViewer.setShowDownloadButton(false);
        this._pdfViewer.open();
        
      },

      // onBeforeRebindTable: function (oEvent) {
      //   var oBindingParams = oEvent.getParameter("bindingParams");
      //   if (this.getView().byId("FechaDesdeID").getDateValue()) {
      //     var y = this.getView().byId("FechaDesdeID").getDateValue().getFullYear().toString();
      //     var m = (this.getView().byId("FechaDesdeID").getDateValue().getMonth() + 1).toString();
      //     var d = this.getView().byId("FechaDesdeID").getDateValue().getDate().toString();
      //     (d.length == 1) && (d = '0' + d);
      //     (m.length == 1) && (m = '0' + m);

      //     var fechaDesde = y + m + d;
      //     oBindingParams.filters.push(new Filter("FechaDesde", FilterOperator.EQ, fechaDesde));
      //   }
      //   if (this.getView().byId("FechaHastaID").getDateValue()) {
      //     var anio = this.getView().byId("FechaHastaID").getDateValue().getFullYear().toString();
      //     var mes = (this.getView().byId("FechaHastaID").getDateValue().getMonth() + 1).toString();
      //     var dia = this.getView().byId("FechaHastaID").getDateValue().getDate().toString();
      //     (dia.length == 1) && (dia = '0' + dia);
      //     (mes.length == 1) && (mes = '0' + mes);

      //     var fechaHasta = anio + mes + dia;
      //     oBindingParams.filters.push(new Filter("FechaHasta", FilterOperator.EQ, fechaHasta));
      //   }
      // },


    });
  });
