sap.ui.define([
  "profertil/listadoDatosMaestros/controller/BaseController",
  "sap/ui/model/json/JSONModel",
	"sap/ui/model/Filter",
  "sap/ui/model/FilterOperator",
	"sap/ui/export/library",
	"sap/ui/export/Spreadsheet",
  "sap/ui/model/odata/v2/ODataModel"
],
function (Controller, JSONModel, Filter, FilterOperator, library, Spreadsheet, ODataModel) {
    "use strict";
    var oController;

    return Controller.extend("profertil.listadoDatosMaestros.controller.MainView", {
      
      onInit: function () {
        oController = this;

        // busy al hacer operaciones sobre el odata que va a SAP
              this.getView().getModel().attachRequestSent(function () {
                  sap.ui.core.BusyIndicator.show(0);
              });
              this.getView().getModel().attachRequestCompleted(function () {
                  sap.ui.core.BusyIndicator.hide();
              });

        this.oSelectZona = this.byId("_zonas");


        this.createFiltradosModel();
        this.getView().setModel(
          new JSONModel({
            showProvincias: false,
          }),
            "view"
        );

      },

      getCurrentFiltersMail: function () {
        var oFiltros = this.getView().getModel("filtrados").getData();
        var aFilters = [];

        if (oFiltros.aBrsch["sPath"]) {
          aFilters.push(oFiltros.aBrsch);
        }
        if (oFiltros.aBzirk["sPath"]) {
          aFilters.push(oFiltros.aBzirk);
        }
        if (oFiltros.aOrt01["sPath"]) {
          aFilters.push(oFiltros.aOrt01);
        }
        if (oFiltros.aRegio["sPath"]) {
          aFilters.push(oFiltros.aRegio);
        }
        if (oFiltros.aLand1["sPath"]) {
          aFilters.push(oFiltros.aLand1);
        }
        if (oFiltros.aMail["sPath"]) {
          aFilters.push(oFiltros.aMail);
        }
        return aFilters;

      },

      getCurrentFiltersTel: function () {
        var oFiltros = this.getView().getModel("filtrados").getData();
        var aFilters = [];

        if (oFiltros.aBrsch["sPath"]) {
          aFilters.push(oFiltros.aBrsch);
        }
        if (oFiltros.aBzirk["sPath"]) {
          aFilters.push(oFiltros.aBzirk);
        }
        if (oFiltros.aOrt01["sPath"]) {
          aFilters.push(oFiltros.aOrt01);
        }
        if (oFiltros.aRegio["sPath"]) {
          aFilters.push(oFiltros.aRegio);
        }
        if (oFiltros.aLand1["sPath"]) {
          aFilters.push(oFiltros.aLand1);
        }
        if (oFiltros.aTel["sPath"]) {
          aFilters.push(oFiltros.aTel);
        }
        return aFilters;

      },

      applyMailsFilter: function () {
        var aFilters = [];
        aFilters = this.getCurrentFiltersMail();
        var oTable = this.byId("tableMails");
        oTable.getBinding("items").filter(aFilters);

      },

      applyTelsFilter: function () {
        var aFilters = [];
        aFilters = this.getCurrentFiltersTel();
        var oTable = this.byId("tableTelefono");
        oTable.getBinding("items").filter(aFilters);

      },

      onUpdateFinishedMails: function (oEvent) {       
        var sText = this.getResourceBundle().getText("btnMail");
        var sTotal = oEvent.getParameter("total").toString();
        sText = sText + " (" + sTotal + ")";
        this.byId("btn_mails_xls").setText(sText);

      },

      onUpdateFinishedTel: function (oEvent) {
        var sText = this.getResourceBundle().getText("btnTel");
        var sTotal = oEvent.getParameter("total").toString();
        sText = sText + " (" + sTotal + ")";
        this.byId("btn_tel_xls").setText(sText);

      },

      onSearchBrsch: function (oEvent) {
        var sBrsch = oEvent.getSource().getSelectedKey();
        var oFilter = new Filter("Brsch", FilterOperator.EQ, sBrsch);

        if (sBrsch){
          this.getView().getModel("filtrados").setProperty("/aBrsch", oFilter);
        } else {
          this.getView().getModel("filtrados").setProperty("/aBrsch", []);
        }

        this.applyMailsFilter();
        this.applyTelsFilter();
        

      },

      onSearchBzirk: function (oEvent) {
        var sBzirk = oEvent.getSource().getSelectedKey();
        var oFilter = new Filter("Bzirk", FilterOperator.EQ, sBzirk);

        if (sBzirk){
          this.getView().getModel("filtrados").setProperty("/aBzirk", oFilter);
        } else {
          this.getView().getModel("filtrados").setProperty("/aBzirk", []);
        }
        
        this.applyMailsFilter();
        this.applyTelsFilter();

      },

      onSearchCiudad: function (oEvent) {
        var sOrt01 = oEvent.getSource().getValue();
        var oFilter = new Filter("Ort01", FilterOperator.Contains, sOrt01);
        this.getView().getModel("filtrados").setProperty("/aOrt01", oFilter);
        
        this.applyMailsFilter();
        this.applyTelsFilter();

      },

      onSearchLand1: function (oEvent){
        var sLand1 = oEvent.getSource().getSelectedKey();
        var oFilter = new Filter("Land1", FilterOperator.Contains, sLand1);
        this.getView().getModel("filtrados").setProperty("/aLand1", oFilter);
        
        this.applyMailsFilter();
        this.applyTelsFilter();

        var oViewModel = this.getModel("view");
        oViewModel.setProperty("/showProvincias", true);
        
        var oFilter = new Filter("Key", FilterOperator.EQ, sLand1);
        var sProv = this.byId("_provincias").getBinding("items");
        sProv.filter([oFilter]);

      },

      onSearchProvincia: function (oEvent) {
        var sRegio = oEvent.getSource().getSelectedKey();
        var oFilter = new Filter("Regio", FilterOperator.EQ, sRegio);

        if (sRegio){
          this.getView().getModel("filtrados").setProperty("/aRegio", oFilter);
        } else {
          this.getView().getModel("filtrados").setProperty("/aRegio", []);
        }

        this.applyMailsFilter();
        this.applyTelsFilter();

      },

      onSearchTipoM: function (oEvent) {
        var sMail = oEvent.getSource().getSelectedKey();
        var oFilter = new Filter("IdMail", FilterOperator.EQ, sMail);

        if (sMail){
          this.getView().getModel("filtrados").setProperty("/aMail", oFilter);
        } else {
          this.getView().getModel("filtrados").setProperty("/aMail", []);
        }

        this.applyMailsFilter();
        
      },

      onSearchTipoT: function (oEvent) {
        var sTel = oEvent.getSource().getSelectedKey();
        var oFilter = new Filter("Extension", FilterOperator.EQ, sTel);

        if (sTel){
          this.getView().getModel("filtrados").setProperty("/aTel", oFilter);
        } else {
          this.getView().getModel("filtrados").setProperty("/aTel", []);
        }

        this.applyTelsFilter();

      },

      createFiltradosModel: function () {
        var oModel = new JSONModel({
          aBrsch: [],
          aBzirk: [],
          aLand1: [],
          aOrt01: [],
          aRegio: [],
          aMail: [],
          aTel: []
        });
        this.getView().setModel(oModel, "filtrados");

      },
  
    //  Descarga de mails (Excel)  
    createColumnMails: function() {
			var aCols = [];

			aCols.push({
				label: 'N° Cliente',
				property: 'Kunnr',
				type: sap.ui.export.EdmType.Number
			});

			aCols.push({
				label: 'Cliente',
				type: sap.ui.export.EdmType.String,
				property: 'Name1'
			});

			aCols.push({
				label: 'Tipo Cliente',
				type: sap.ui.export.EdmType.String,
				property: 'Brsch'
			});

			aCols.push({
				label: 'Zona',
				property: 'Bzirk',
				type: sap.ui.export.EdmType.String,
			});

			aCols.push({
				label: 'Ciudad',
				type: sap.ui.export.EdmType.String,
				property: 'Ort01'
			});

			aCols.push({
				label: 'Provincia',
				type: sap.ui.export.EdmType.String,
				property: 'Bezei'
			});
			aCols.push({
				label: 'Mail',
				type: sap.ui.export.EdmType.String,
				property: 'Mail'
			});

			aCols.push({
				label: 'Tipo de contacto',
				type: sap.ui.export.EdmType.String,
				property: 'IdMail'
			});
			return aCols;
    },

    onExportMails: function() {
      var aCols, oRowBinding, oSettings, oSheet, oTable;
      var oTable = null;
			
			this._oTable = this.byId('tableMails');

			oTable = this._oTable;
			oRowBinding = oTable.getBinding('items');
      aCols = this.createColumnMails();
      
      if (!oRowBinding.aKeys.length) {
        sap.m.MessageToast.show("No hay datos para descargar");
        return;
      }

			oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: 'Level'
				},
				dataSource: oRowBinding,
				fileName: 'Datos clientes.xlsx',
			//	worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function() {
				oSheet.destroy();
			});
    },

    onExportMailsCsv: function (aData) {

      if (!aData.length) {
        sap.m.MessageToast.show("No hay datos para descargar");
        return;
      }

      jQuery.sap.require("sap.ui.core.util.Export");
      jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");

      var aMails = aData.map( oEntity => oEntity.Mail);
      var aMailsUnicos = [...new Set(aMails)];
      var sMail =  aMailsUnicos.reduce( (a, b) => `${a};${b}`);
      var oModel = new sap.ui.model.json.JSONModel([
        {
            Mail: sMail
        }
      ]);

      var oExport = new sap.ui.core.util.Export({
        // Type that will be used to generate the content. Own  ExportType's can be created to support other formats
        exportType: new sap.ui.core.util.ExportTypeCSV({
            separatorChar: ";",
            fileExtension: "csv",
            //fileName: "datossss.txt"
            sheetName: "datos"
        }),

        // Pass in the model created above
        models: oModel,

        // binding information for the rows aggregation
        rows: {
            path: "/"
        },

        // column definitions with column name and binding info for the content
        columns: [
            {
                //name: "First name",
                template: {
                    content: {
                        path: "Mail"
                    }
                }
            }
        ]
      });

      oExport.generate().done(function(sContent) {
          //console.log(sContent);
      }).always(function() {
          this.destroy();
      });

      oExport.saveFile().always(function() {
          this.destroy();
      });


    },

    onExportporcoma2: function () {
      var aFilters = [];
      aFilters = this.getCurrentFiltersMail();
      var that = this;
      this.getView().getModel().read("/ClientesSet", {
        success: function (oData) {
          that.onExportMailsCsv(oData.results);
        },
        error: function (oError) {
          console.log("No se encotnraron datos");
        },
        urlParameters: {"$select": "Mail"},
        filters: aFilters
      });

    },

    onExportporcoma: function () {
      jQuery.sap.require("sap.ui.core.util.Export");
      jQuery.sap.require("sap.ui.core.util.ExportTypeCSV");

      var oTable = this.byId("tableMails");
      var aItems  = oTable.getItems(),
          aEntities = aItems.map( oItem => oItem.getBindingContext().getObject());
      var aMails = aEntities.map( oEntity => oEntity.Mail);
      //console.info(aMails);
      var aMailsUnicos = [...new Set(aMails)];
      var sMail =  aMailsUnicos.reduce( (a, b) => `${a};${b}`);
      var oModel = new sap.ui.model.json.JSONModel([
        {
            Mail: sMail
        }
      ]);

      var oExport = new sap.ui.core.util.Export({
    // Type that will be used to generate the content. Own  ExportType's can be created to support other formats
        exportType: new sap.ui.core.util.ExportTypeCSV({
            separatorChar: ";",
            fileExtension: "csv",
            //fileName: "datossss.txt"
            sheetName: "datos"
        }),

        // Pass in the model created above
        models: oModel,

        // binding information for the rows aggregation
        rows: {
            path: "/"
        },

        // column definitions with column name and binding info for the content
        columns: [
            {
                //name: "First name",
                template: {
                    content: {
                        path: "Mail"
                    }
                }
            }
        ]
    });

    oExport.generate().done(function(sContent) {
        //console.log(sContent);
    }).always(function() {
        this.destroy();
    });

    oExport.saveFile().always(function() {
        this.destroy();
    });

  },
    
  //  Descarga de teléfonos  //
    createColumnTelefonos: function() {
			var aCols = [];

			aCols.push({
				label: 'N° Cliente',
				property: 'Kunnr',
				type: sap.ui.export.EdmType.String
			});

			aCols.push({
				label: 'Cliente',
				type: sap.ui.export.EdmType.String,
				property: 'Name1'
			});

			aCols.push({
				label: 'Tipo Cliente',
				type: sap.ui.export.EdmType.String,
				property: 'Brsch'
			});

			aCols.push({
				label: 'Zona',
				property: 'Bzirk',
				type: sap.ui.export.EdmType.String
			});

			aCols.push({
				label: 'Ciudad',
				type: sap.ui.export.EdmType.String,
				property: 'Ort01'
			});

			aCols.push({
				label: 'Provincia',
				type: sap.ui.export.EdmType.String,
				property: 'Bezei'
			});
			aCols.push({
				label: 'Nombre',
				type: sap.ui.export.EdmType.String,
				property: 'Nombre'
			});

			aCols.push({
				label: 'Telefono',
				type: sap.ui.export.EdmType.Number,
				property: 'Telefono'
      });

			aCols.push({
				label: 'Tipo de contacto',
				type: sap.ui.export.EdmType.String,
				property: 'Extension'
			});
			return aCols;
    },

    onExportTelefonos: function() {
      var aCols, oRowBinding, oSettings, oSheet, oTable;
      var oTable = null;
			this._oTable = this.byId("tableTelefono");

			oTable = this._oTable;
			oRowBinding = oTable.getBinding("items");
			aCols = this.createColumnTelefonos();

      if (!oRowBinding.aKeys.length) {
        sap.m.MessageToast.show("No hay datos para descargar");
        return;
      }

			oSettings = {
				workbook: {
					columns: aCols,
					hierarchyLevel: "Level"
				},
				dataSource: oRowBinding,
				fileName: 'Datos tel clientes.xlsx',
			//	worker: false // We need to disable worker because we are using a MockServer as OData Service
			};

			oSheet = new Spreadsheet(oSettings);
			oSheet.build().finally(function() {
				oSheet.destroy();
      });
      
    },



    //---------------------------------//
    // old functions
    //---------------------------------//
    onFiltrarM: function (){
      this.getView().byId("tableMails").getBinding("items").filter(this.getAllFiltersM());

    },

    onFiltrarT: function (){
      this.getView().byId("tableTelefono").getBinding("items").filter(this.getAllFiltersT());

    },

    getAllFiltersT: function () {
			var filtBzirk = this.getView().getModel("filtrados").getProperty("/aBzirk");
      var filtBrsch = this.getView().getModel("filtrados").getProperty("/aBrsch");
      var filtTel = this.getView().getModel("filtrados").getProperty("/aTel");
      var filtRegio = this.getView().getModel("filtrados").getProperty("/aRegio");
      var filtOrt01 = this.getView().getModel("filtrados").getProperty("/aOrt01");

      var a = [];
      if (filtBrsch.sPath) a.push(filtBrsch);
      if (filtBzirk.sPath) a.push(filtBzirk);
      if (filtOrt01.sPath) a.push(filtOrt01);
      if (filtRegio.sPath) a.push(filtRegio);
      if (filtTel.sPath) a.push(filtTel);

      return a;
    },

    getAllFiltersM: function () {
			var filtBzirk = this.getView().getModel("filtrados").getProperty("/aBzirk");
      var filtBrsch = this.getView().getModel("filtrados").getProperty("/aBrsch");
      var filtMail = this.getView().getModel("filtrados").getProperty("/aMail");
      var filtRegio = this.getView().getModel("filtrados").getProperty("/aRegio");
      var filtOrt01 = this.getView().getModel("filtrados").getProperty("/aOrt01");

      var a = [];
      if (filtBrsch.sPath) a.push(filtBrsch);
      if (filtBzirk.sPath) a.push(filtBzirk);
      if (filtOrt01.sPath) a.push(filtOrt01);
      if (filtMail.sPath) a.push(filtMail);
      if (filtRegio.sPath) a.push(filtRegio);

      return a;
    }



    });
});
