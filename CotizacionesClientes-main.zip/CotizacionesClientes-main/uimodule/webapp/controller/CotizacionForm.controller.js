sap.ui.define([
  "profertil/cotizacionesclientes/controller/BaseController",
  "sap/ui/core/Fragment",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox"
], function (Controller, Fragment, JSONModel, MessageBox) {
  "use strict";

  return Controller.extend("profertil.cotizacionesclientes.controller.CotizacionForm", {
    onInit: function () {
      var UIModel = new JSONModel({
        editView: false,
        compButton: false
      });

      this.getView().setModel(UIModel, "UI");

      this.getRouter().getRoute("form").attachPatternMatched(this._onObjectMatched, this);
    },

    onNavBackBtnPress: function () {
      this.onNavBack();
    },

    handleEditPress: function () {
      this._showEditView();
    },

    handleCancelPress: function () {
      this._showForm("VIEW");
    },

    handleConvertPress: function () {
      this._showConvertView();
    },

    handleSavePress: function () {
      var bError = this._onSubmitCheck();

      if (bError) {
        return MessageBox.error("Por favor, complete todos los campos.");
      }

      var data = this._getFormData(this._convert);
      if (data){
        this._saveData(data);
      }
    },

    handleChange: function (oEvent) {
      var oField = oEvent.oSource;

      this._onChangeCheck(oField);
    },

     onSelectDeliveryType: function (oEvent) {
      if (oEvent.getParameter("newValue") === "DEL") {
        this.byId("localidad-field").setEnabled(true);
      } else {
        this.byId("localidad-field").setEnabled(false);
        this.byId("localidad-field").setValue("");
      }
    },

    onPressComposicion: function () {
      var json = this.getView().getModel("Composicion").getJSON();
      this._prevComp = JSON.parse(json);
      // this._prevComp = { ...this.getView().getModel("Composicion").getData() };

      if (!this._oDialog) {
        this._oDialog = sap.ui.xmlfragment(this.getView().getId(), "profertil.cotizacionesclientes.view.Composicion", this);
        this.getView().addDependent(this._oDialog);
      }

      this._oDialog.open();

      this._bindComposicionTable();
    },

    onCloseComposicionDialog: function () {
      var oModel = this.getView().getModel("Composicion");
      var data = oModel.getData().Components;

      var sum = 0;

      for (var i = 0; i < data.length; i++) {
        sum += parseFloat(data[i].Porcentaje);
      }

      if (sum != 100) return MessageBox.error("Los campos de porcentaje deben sumar 100.");

      this._oDialog.close();
    },

    onCancelComposicionDialog: function () {
      this.byId("comp-table").unbindItems();

      var oModel = this.getView().getModel("Composicion");

      oModel.setData(this._prevComp);

      this.getView().setModel(oModel, "Composicion");

      this._prevComp = null;

      this._oDialog.close();
    },

    onPressAddComposicion: function (oEvent) {
      var oModel = this.getView().getModel("Composicion");
      var oComponents = oModel.getProperty("/Components");

      var modelComponents = oModel.getData().Components;
      var lastIndex = modelComponents.length - 1;

      if(modelComponents[lastIndex].Producto === '' || modelComponents[lastIndex].Porcentaje === 0) return;

      oComponents.push({
        Cotizacion: this.getView().getBindingContext().getObject().Id,
        Producto: '',
        ProductoTexto: '',
        Porcentaje: 0
      });

      this._bindComposicionTable();
    },

    onPressDeleteComposicion: function (oEvent) {
      var path = oEvent.oSource.getParent().getBindingContext("Composicion").getPath();
      var strIndex = path.lastIndexOf("/");
      var pathIndex = parseInt(path.substring(strIndex + 1));

      this.getView().getModel("Composicion").getData().Components.splice(pathIndex, 1);

      this._bindComposicionTable();
    },

    onChangeFechaInicio: function (oEvent) {
      var fechaFinInput = this.byId("fechafin-field");
      var fecha = oEvent.getSource().getDateValue();

      fechaFinInput.setMinDate(fecha);

      this.handleChange(oEvent);
    },

    formatDateStr: function (date) {
      var oDate = new Date(date);

      let day = oDate.getDate();
      let month = oDate.getMonth() + 1;
      let year = oDate.getFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    formatKey: function (key) {
      return Number(key);
    },

    // _activateClientCB: function (key) {
    //   var clientCB = this.getView().byId("cliente-field");
    //   clientCB.setEnabled(true);

    //   var oItemTemplate = new sap.ui.core.Item({
    //     key: '{Key}',
    //     text: '{Value}'
    //   });

    //   clientCB.bindAggregation("items", {
    //     path: "/ZonaSet('" + key + "')/ClienteSet",
    //     template: oItemTemplate,
    //     templateShareable: true
    //   });
    // },

    _showForm: function (mode) {
      var fragmentName;
      var oModel = this.getView().getModel("UI");

      oModel.setProperty("/editView", mode !== "VIEW")

      switch (mode) {
        case "VIEW":
          fragmentName = "Display";
          break;
        case "EDIT":
          fragmentName = "Edit";
          break;
        case "CONVERT":
          fragmentName = "Convert";
          break;
      }

      this._showFormFragment(fragmentName);
    },

    _getFormFragment: function (sFragmentName) {
      var pFormFragment = this._formFragment,
        oView = this.getView();

      if (pFormFragment) {
        pFormFragment.destroy();
        this._formFragment = null;
      }

      pFormFragment = Fragment.load({
        id: this.getView().getId(),
        name: "profertil.cotizacionesclientes.view." + sFragmentName,
        controller: this
      });

      return pFormFragment;
    },

    _showFormFragment: function (sFragmentName) {
      var oPage = this.byId("form-page");

      oPage.removeAllContent();

      this._getFormFragment(sFragmentName)
        .then((oVBox) => {
          this._formFragment = oVBox;
          oPage.insertContent(oVBox);
        }).then(() => {
          var dataModel = this.getView().getModel("Cotizacion");
          var uiModel = this.getView().getModel("UI");

          if (sFragmentName === "Edit") {

            // this._activateClientCB(zonaKey);
            this._setValidityDate();
          } else if (sFragmentName === "Convert") {
            uiModel.setProperty("/compButton", dataModel.getData().Producto == 81 || dataModel.getData().Producto == 82);
          }
        });
    },

    _showEditView: function() {
      this._setTempModel();

      this.getView().getModel("UI").setProperty("/editView", true);

      this._convert = false;

      this._showForm("EDIT");

         // poner 2 decimales      
        var oDataModel = this.getView().getModel();
        var oObject = this.getView().getBindingContext().getObject();
        var sPath = this.getView().getBindingContext().sPath;
        if (oDataModel && oObject) {
          var precio = oObject.Precio;
          oDataModel.setProperty(sPath + "/Precio", parseFloat(precio).toFixed(2));
          var cantidad = oObject.Cantidad;
          oDataModel.setProperty(sPath + "/Cantidad", parseFloat(cantidad).toFixed(2));
        }
    },

    _showConvertView: function() {
      this._setTempModel();

      this.getView().getModel("UI").setProperty("/editView", true);

      this._convert = true;

      this._showForm("CONVERT");
    },

    _setTempModel: function() {
      var data = this.getView().getBindingContext().getObject();

      var jsonModel = new JSONModel({ ...data });
      
      this.getView().setModel(jsonModel, "Cotizacion");
    },

    _bindComposicionTable: function () {
      var oTable = this.byId("comp-table");

      var material = this.getView().getModel("Cotizacion").getData().Producto;

      // oTable.unbindItems();
      oTable.bindItems("Composicion>/Components",
        new sap.m.ColumnListItem({
          cells: [
            new sap.m.ComboBox({
              items: {
                path: '/ComponenteSet',
                filters: [
                  new sap.ui.model.Filter({ path: 'Material', operator: 'Contains', value1: material }),
                  new sap.ui.model.Filter({ path: 'Zona', operator: 'EQ', value1: 'SN' })
                ],
                template: new sap.ui.core.Item({
                  key: '{Id}',
                  text: '{Descripcion}'
                })
              },
              width: '100%',
              selectedKey: { path: 'Composicion>Producto' },
              value: { path: 'Composicion>ProductoTexto' }
            }),
            new sap.m.Input({
              type: 'Number',
              value: { path: 'Composicion>Porcentaje' }
            }),
            new sap.m.Button({
              type: 'Reject',
              icon: 'sap-icon://delete',
              press: this.onPressDeleteComposicion.bind(this)
            })
          ]
        })
      );
    },

    _onObjectMatched: function (oEvent) {
      var id = oEvent.getParameter("arguments").objectId;

      if (id) {
        this._id = id;
      }

      this._showForm("VIEW");

      this._bindView(this._id);
    },

    _getNextDayOfWeek: function (date, dayOfWeek) {
      var resultDate = new Date(date.getTime());

      resultDate.setDate(date.getDate() + (7 + dayOfWeek - date.getDay()) % 7);

      return resultDate;
    },

    _setValidityDate() {
      var dataModel = this.getView().getModel("Cotizacion");

      var today = new Date(),
      vEndDate = this._getNextDayOfWeek(today, 4);

      dataModel.setProperty("/Vigencia", vEndDate);
    },

    _formatDate(date) {
      let day = date.getDate();
      let month = date.getMonth() + 1;
      let year = date.getFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    _getFormData: function(convert) {
      var data = this.getView().getModel("Cotizacion").getData();
      var object = { ...data }

      var centroTexto = object.CentroTexto.replace(/(^.* - )/, "");
      var financiado = object.Financiado === "SI";

      object.CentroTexto = centroTexto;
      object.Financiado = financiado;

      if (financiado && !parseFloat(object.TasaInteres)){
        MessageBox.error("Complete el Interés de la financiación");
        return null;
      }

      if (convert) {
        var oCompModel = this.getView().getModel("Composicion");

        object.Estado = "NEG";
        object.EstadoTexto = "Negocio";

        object.ComposicionSet = oCompModel ? oCompModel.getData().Components : []
      }
      
      if (!(object.ComposicionSet.length > 0)) delete object.ComposicionSet;
      delete object.__metadata;

      return (object);
    },

    _saveData: function (oData) {
      var message;
      var oModel = this.getView().getModel();

      this.getView().setBusy(true);

      oModel.setUseBatch(false);

      oModel.create("/CotizacionSet", oData, {
        success: function () {
          this.getView().setBusy(false);

          MessageBox.success("La cotización se ha actualizado con éxito.", {
            onClose: (oAction) => {
              if (oAction == "OK") this.onNavBack();
            }
          });
        }.bind(this),
        error: function () {
          this.getView().setBusy(false);

          MessageBox.error("Se ha producido un error.");
        }.bind(this)
      });
    },

    _onSubmitCheck: function () {
      var oForm = this.byId("data-form").getFormContainers()[0].getFormElements();

      var bError = false;

      oForm.forEach(field => {  
        if (field.getFields()[0].getId().indexOf("comentarios-field")) {
          return;
        }    

        if (typeof field.getFields()[0].getValue === "function" && field.getVisible()) {
          if (this.byId("envio-field")) {
            if (field.getFields()[0].getId().indexOf("localidad-field") && this.byId("envio-field").getSelectedKey() == "FOT") {
              return;
            }    
          }
        
          if (!field.getFields()[0].getValue() || field.getFields()[0].getValue().length < 1) {
            field.getFields()[0].setValueState("Error");

            bError = true;
          } else {
            field.getFields()[0].setValueState("None");
          }
        }
      });

      return bError;
    },

    _onChangeCheck: function (oField) {
      if (typeof oField.getValue === "function") {
        if (!oField.getValue() || oField.getValue().length < 1) {
          oField.setValueState("Error");
        } else {
          oField.setValueState("None");
        }
      }
    },

    _bindView: function (id) {
      var data;
      var oView = this.getView();

      var sObjectPath = this.getModel().createKey("CotizacionSet", {
        Id: id
      });

      oView.bindElement("/" + sObjectPath);

      var compModel = {
        Components: []
      };

      var jsonModel = new JSONModel(compModel);

      this.getView().setModel(jsonModel, "Composicion");
    }
  });
});