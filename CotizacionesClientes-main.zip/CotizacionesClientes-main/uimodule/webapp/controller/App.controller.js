sap.ui.define([
	"./BaseController",
	"sap/ui/model/json/JSONModel"
], function (BaseController, JSONModel) {
	"use strict";

	return BaseController.extend("profertil.cotizacionesclientes.controller.App", {

		onInit: function () {
		}

	});

});