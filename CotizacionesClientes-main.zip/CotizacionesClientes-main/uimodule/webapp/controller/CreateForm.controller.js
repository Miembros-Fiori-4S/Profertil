sap.ui.define([
  "profertil/cotizacionesclientes/controller/BaseController",
  "sap/ui/core/Fragment",
  "sap/ui/model/json/JSONModel",
  "sap/m/MessageBox"
], function (Controller, Fragment, JSONModel, MessageBox) {
  "use strict";

  return Controller.extend("profertil.cotizacionesclientes.controller.CreateForm", {
    onInit: function () {
      this.getRouter().getRoute("create").attachPatternMatched(this._onObjectMatched, this);
    },

    onNavBackBtnPress: function () {
      this.onNavBack();
    },

    handleCancelPress: function () {
      this.onNavBack();
    },

    handleSavePress: function () {
      var bError = this._onSubmitCheck();

      if (bError) {
        return MessageBox.error("Por favor, complete todos los campos.");
      }

      var data = this.getView().getModel("Cotizacion").getData();

      var centroTexto = data.CentroTexto.replace(/(^.* - )/, "");

      data.CentroTexto = centroTexto;

      this._saveData(data);
    },

    handleChange: function (oEvent) {
      var oField = oEvent.oSource;

      this._onChangeCheck(oField);
    },

    onSelectZona: function (oEvent) {
      var key = oEvent.oSource.getSelectedKey();

      this._activateClientCB(key);

      this.handleChange(oEvent);
    },

    onChangeFechaInicio: function (oEvent) {
      var fechaFinInput = this.byId("fechafin-field");
      var fecha = oEvent.getSource().getDateValue();

      fechaFinInput.setMinDate(fecha);

      this.handleChange(oEvent);
    },

    formatDateStr: function (date) {
      var oDate = new Date(date);

      let day = oDate.getDate();
      let month = oDate.getMonth() + 1;
      let year = oDate.getFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    formatKey: function (key) {
      return Number(key);
    },

    _activateClientCB: function (key) {
      // var rol = this.getView().byId("cliente-field");
      // rol.setEnabled(true);

      // var oItemTemplate = new sap.ui.core.Item({
      //   key: '{Key}',
      //   text: '{Value}'
      // });

      // rol.bindAggregation("items", {
      //   path: "/ZonaSet('" + key + "')/ClienteSet",
      //   template: oItemTemplate,
      //   templateShareable: true
      // });
    },

    _onObjectMatched: function (oEvent) {
      var dataModel = new JSONModel({
        Estado: 'COT',
        EstadoTexto: 'Cotización'
      });

      this.getView().setModel(dataModel, "Cotizacion");

      this._setValidityDate();
    },

    _getNextDayOfWeek: function (date, dayOfWeek) {
      var resultDate = new Date(date.getTime());

      resultDate.setDate(date.getDate() + (7 + dayOfWeek - date.getDay()) % 7);

      return resultDate;
    },

    _setValidityDate() {
      var dataModel = this.getView().getModel("Cotizacion");

      var today = new Date(),
      vEndDate = this._getNextDayOfWeek(today, 4);

      dataModel.setProperty("/Fecha", today);
      dataModel.setProperty("/Vigencia", vEndDate);
    },

    _formatDate(date) {
      let day = date.getDate();
      let month = date.getMonth() + 1;
      let year = date.getFullYear();

      day = day < 10 ? `0${day}` : day;
      month = month < 10 ? `0${month}` : month;

      return `${day}/${month}/${year}`;
    },

    _saveData: function (oData) {
      var oModel = this.getView().getModel();

      this.getView().setBusy(true);

      oModel.setUseBatch(false);

      oModel.create("/CotizacionSet", oData, {
        success: function () {
          this.getView().setBusy(false);

          MessageBox.success("La cotización se ha generado con éxito.", {
            onClose: (oAction) => {
              if (oAction == "OK") this.onNavBack();
            }
          });
        }.bind(this),
        error: function () {
          this.getView().setBusy(false);

          MessageBox.error("Se ha producido un error.");
        }.bind(this)
      });
    },

    _onSubmitCheck: function () {
      var oForm = this.byId("data-form").getFormContainers()[0].getFormElements();

      var bError = false;

      oForm.forEach(field => {
        if (field.getFields()[0].getId().indexOf("comentarios-field")) {
          return;
        }    

        if (field.getFields()[0].getId().indexOf("localidad-field") && this.byId("envio-field").getSelectedKey() == "FOT") {
          return;
        }   

        if (typeof field.getFields()[0].getValue === "function" && field.getVisible()) {
          if (!field.getFields()[0].getValue() || field.getFields()[0].getValue().length < 1) {
            field.getFields()[0].setValueState("Error");

            bError = true;
          } else {
            field.getFields()[0].setValueState("None");
          }
        }
      });

      return bError;
    },

    _onChangeCheck: function (oField) {
      if (typeof oField.getValue === "function") {
        if (!oField.getValue() || oField.getValue().length < 1) {
          oField.setValueState("Error");
        } else {
          oField.setValueState("None");
        }
      }
    }
  });
});