sap.ui.define([
  "sap/ui/core/UIComponent",
  "sap/ui/Device",
  "profertil/cotizacionesclientes/model/models",
  "sap/m/MessageBox"
], function (UIComponent, Device, models) {
  "use strict";

  return UIComponent.extend("profertil.cotizacionesclientes.Component", {

    metadata: {
      manifest: "json"
    },

    /**
     * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
     * @public
     * @override
     */
    init: function () {

      // validacion por fecha 
      // No se puede ingresar a Cotizaciones y Vencidas: desde la una de la tarde del jueves hasta el mediodia del viernes - SOLO APP CLIENTES

      var fecha = new Date();
      if ((fecha.getDay() === 4 & fecha.getHours() > 13) || // jueves pasadas las 13
        (fecha.getDay() === 5 & fecha.getHours() < 12)) { // viernes hasta las 12
        sap.m.MessageBox.error("Estimado cliente, esta funcionalidad no está disponible entre las 13:00 del jueves y 12:00 del viernes.",
          {
            onClose: () => {
              // volver al launchpad
              var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
              oCrossAppNavigator.toExternal({
                target: {
                  semanticObject: "#"
                }
              });
            }
          });


        return;
      }


      // call the base component's init function
      UIComponent.prototype.init.apply(this, arguments);

      // enable routing
      this.getRouter().initialize();

      // set the device model
      this.setModel(models.createDeviceModel(), "device");

      // TODO QUITAR
      // setear el ID de cliente en header from
      // sap._sesionProfertil = { cliente: "100541" };
      // var o = XMLHttpRequest.prototype.open;
      // XMLHttpRequest.prototype.open = function () {
      //     var r = o.apply(this, arguments);
      //     if (arguments[1].indexOf("sap/opu/odata/sap") >= 0) {
      //         this.setRequestHeader("from", sap._sesionProfertil.cliente);
      //     }
      //     return r;
      // };



    }
  });
});
