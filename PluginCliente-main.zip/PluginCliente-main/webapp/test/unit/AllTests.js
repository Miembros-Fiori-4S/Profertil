sap.ui.define([
	"profertil./pluginclientes/test/unit/controller/View1.controller"
], function () {
	"use strict";
});
