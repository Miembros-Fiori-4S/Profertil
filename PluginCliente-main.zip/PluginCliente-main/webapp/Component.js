sap.ui.define([
    "sap/ui/core/UIComponent",
    "sap/ui/Device",
], function (UIComponent, Device) {
    "use strict";

    var _oController;
    return UIComponent.extend("profertil.pluginclientes.Component", {

        metadata: {
            manifest: "json"
        },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
        _getRenderer: function () {
            var that = this,
                oDeferred = new jQuery.Deferred(),
                oRenderer;

            that._oShellContainer = jQuery.sap.getObject("sap.ushell.Container");
            if (!that._oShellContainer) {
                oDeferred.reject(
                    "Illegal state: shell container not available; this component must be executed in a unified shell runtime context.");
            } else {
                oRenderer = that._oShellContainer.getRenderer();
                if (oRenderer) {
                    oDeferred.resolve(oRenderer);
                } else {
                    // renderer not initialized yet, listen to rendererCreated event
                    that._onRendererCreated = function (oEvent) {
                        oRenderer = oEvent.getParameter("renderer");
                        if (oRenderer) {
                            oDeferred.resolve(oRenderer);
                        } else {
                            oDeferred.reject("Illegal state: shell renderer not available after recieving 'rendererLoaded' event.");
                        }
                    };
                    that._oShellContainer.attachRendererCreatedEvent(that._onRendererCreated);
                }
            }
            return oDeferred.promise();
        },

		/**
		 * The component is initialized by UI5 automatically during the startup of the app and calls the init method once.
		 * @public
		 * @override
		 */
        init: function () {
            // call the base component's init function
            UIComponent.prototype.init.apply(this, arguments);


            _oController = this;
            // _oModel = this.getModel();

            _oController = this;
            var fgetService = sap.ushell && sap.ushell.Container && sap.ushell.Container.getService;
            this.oCrossAppNavigator = fgetService && fgetService("CrossApplicationNavigation");

            this._getRenderer().fail(function (sErrorMessage) {
                console.log("Error loading renderer");
            });

            // guardar referencia a los textos
            this.oTextos = this.getModel("i18n").getResourceBundle();

            // llamada inicial
            this._getRenderer().done(async function () {
                this.obtenerCliente();
            }.bind(this));

            //llamada en cada regreso al launchpad
            $(window).hashchange(function () {
                if (window.location.hash === "#Shell-home" || window.location.hash === "#") {
                    this.obtenerCliente();
                }
            }.bind(this));
        },

        formatterQuitarCeros: function (str) {
            return str.replace(/^0+/, '');
        },

        obtenerCliente: function () {

            // setear el ID de cliente en header from
            var o = XMLHttpRequest.prototype.open;
            XMLHttpRequest.prototype.open = function () {
                var r = o.apply(this, arguments);
                if (arguments[1].indexOf("sap/opu/odata/sap") > 0) {
                    var cliente = jQuery.sap.storage.get("profertil.sesion.cliente");
                    if (cliente) {
                        this.setRequestHeader("from", cliente);
                    }
                }
                return r;
            };


            this.getModel().read("/ClienteSet('1')", {
                success: function (oData) {
                    this.agregarToolbarCliente(oData);
                }.bind(this),
                error: function (oError) {
                    console.log(oError);
                }.bind(this)
            });
        },

        agregarToolbarCliente: function (oData) {

            var oText = sap.ui.getCore().byId("idTextClienteSeleccionado");
            var sText = "";

            // Quitar ceros
            if (oData.ClienteId) {
                var clienteId = _oController.formatterQuitarCeros(oData.ClienteId);
                sText = clienteId + " - " + oData.ClienteNombre + " - " + oData.RolDescripcion + "/" + oData.SegmentoDescripcion;
            } else {
                sText = this.oTextos.getText("sin_seleccionar");
            }

            if (oText) {
                // modificar sin regenerar la toolbar
                oText.setText(sText);
                return;
            }

            var oRenderer = sap.ushell.Container.getRenderer("fiori2");
            var oAddSubHeaderProperties = {
                controlType: "sap.m.Toolbar",
                oControlProperties: {
                    design: sap.m.ToolbarDesign.Info,
                    content: [
                        new sap.m.ToolbarSpacer(),

                        new sap.m.Text("idTextClienteSeleccionado", {
                            text: sText
                        }),
                        new sap.m.Button({
                            text: this.oTextos.getText("boton_cambiar_cliente"),
                            tooltip: this.oTextos.getText("boton_cambiar_cliente_tooltip"),
                            type: "Emphasized",
                            press: _oController.navToSeleccionCliente,
                            visible: oData.Rol === "1" // solo para rol profertil
                        }),

                        new sap.m.ToolbarSpacer()
                    ]
                },
                bIsVisible: true,
                // bCurrentState: false,
                aStates: ["home"] // solo en launchpad
            };

            oRenderer.addShellSubHeader(oAddSubHeaderProperties);
        },

        navToSeleccionCliente: function () {
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
            oCrossAppNavigator.toExternal({
                target: {
                    semanticObject: "Clientes",
                    action: "Seleccionar"
                }
            });
        },
        navToLaunchpad: function () {
            // volver al launchpad
            var oCrossAppNavigator = sap.ushell.Container.getService("CrossApplicationNavigation");
            oCrossAppNavigator.toExternal({
                target: {
                    semanticObject: "#"
                }
            });
        }

    });
});